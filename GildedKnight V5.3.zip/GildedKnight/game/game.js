"use strict";
(() => {
  const W = 960,
    H = 540,
    RS = 1.25,
    GROUND = 470,
    WORLD = 1800,
    DT = 1 / 60;
  let layerScale = RS;
  const GRAV = 2300,
    JUMPV = 900,
    PARRY_WIN = 0.28,
    RONIN_DEFLECT_WIN = 0.58,
    BEAM_H = 78;
  const HERO_SRC = "assets/hero.jpg",
    BOSS_SRC = "assets/boss.jpg",
    ART1_SRC = "assets/art1.png",
    ART2_SRC = "assets/art2.png",
    SHADOW_SRC = "assets/shadow.png",
    RONIN_SRC = "assets/red_ronin.jpg",
    REGAL_SRC = "assets/metal_regal.jpg",
    WIZARD_SRC = "assets/wizard.jpg",
    KILLNUX_SRC = "assets/killnux_portrait.png",
    SHOGUN_SRC = "assets/infernal_shogun.jpg",
    SHOGUN_P2_SRC = "assets/shogun_phase2.jpg",
    ART_MENU_SRC = "assets/artorias_menu.png";
  const DEMON_FACE_SRC = "assets/demon_face_pixel.png";
  let heroType = "knight",
    heroType2 = "killnux",
    gameMode = "solo",
    activePlayerIndex = 0;
  const $ = (id) => document.getElementById(id);
  const cv = $("c"),
    ctx = cv.getContext("2d");
  cv.width = W * RS;
  cv.height = H * RS;
  const stage = $("stage");
  function fit() {
    stage.style.setProperty("--u", (stage.clientWidth / W).toFixed(4));
  }
  addEventListener("resize", fit);
  fit();

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const rnd = (a, b) => a + Math.random() * (b - a);
  const ease = (t) => t * t * (3 - 2 * t);
  const easeOut = (t) => 1 - (1 - t) * (1 - t);
  const TAU = Math.PI * 2;

  /* ================= PROFILE, RELICS, SHOP & VIDEO ================= */
  const RARITIES = [
    { id: "common", name: "Common", chance: 50, color: "Grey" },
    { id: "rare", name: "Rare", chance: 30, color: "Blue" },
    { id: "mythic", name: "Mythic", chance: 15, color: "Purple" },
    { id: "legendary", name: "Legendary", chance: 4, color: "Yellow" },
    { id: "anis", name: "Anis", chance: 1, color: "Red" },
  ];
  const RELICS = [
    {
      id: "attack",
      name: "Dull Fang",
      effect: "Attack damage +5%",
      rarity: "common",
      dropChance: 10,
      mods: { attack: 0.05 },
    },
    {
      id: "stamina",
      name: "Pale Current",
      effect: "Maximum stamina +10",
      rarity: "common",
      dropChance: 10,
      mods: { stamina: 10 },
    },
    {
      id: "defense",
      name: "Stone Veil",
      effect: "Defense +5%",
      rarity: "common",
      dropChance: 10,
      mods: { defense: 0.05 },
    },
    {
      id: "health",
      name: "Grey Heart",
      effect: "Maximum health +20",
      rarity: "common",
      dropChance: 10,
      mods: { health: 20 },
    },
    {
      id: "cooldown",
      name: "Quiet Hourglass",
      effect: "Skill recovery +5%",
      rarity: "common",
      dropChance: 10,
      mods: { cooldown: 0.05 },
    },
    {
      id: "skill_attack",
      name: "Ashen Sigil",
      effect: "Skill attack power +5%",
      rarity: "common",
      mods: { skillAttack: 0.05 },
    },
    {
      id: "stamina_recovery",
      name: "Wind Coil",
      effect: "Stamina recovery +5%",
      rarity: "common",
      mods: { staminaRecovery: 0.05 },
    },
    {
      id: "healing",
      name: "Pilgrim Chalice",
      effect: "Flask healing +5%",
      rarity: "common",
      mods: { healing: 0.05 },
    },
    {
      id: "rare_attack",
      name: "Azure Fang",
      effect: "Attack damage +15%",
      rarity: "rare",
      dropChance: 6,
      mods: { attack: 0.15 },
    },
    {
      id: "rare_defense",
      name: "Tideguard Veil",
      effect: "Defense +15%",
      rarity: "rare",
      dropChance: 6,
      mods: { defense: 0.15 },
    },
    {
      id: "rare_health",
      name: "Blue Heart",
      effect: "Maximum health +40",
      rarity: "rare",
      dropChance: 6,
      mods: { health: 40 },
    },
    {
      id: "rare_cooldown",
      name: "Swift Sapphire",
      effect: "Skill recovery +15%",
      rarity: "rare",
      dropChance: 6,
      mods: { cooldown: 0.15 },
    },
    {
      id: "rare_stamina",
      name: "Storm Current",
      effect: "Maximum stamina +30",
      rarity: "rare",
      dropChance: 6,
      mods: { stamina: 30 },
    },
    {
      id: "rare_skill_attack",
      name: "Azure Sigil",
      effect: "Skill attack power +15%",
      rarity: "rare",
      mods: { skillAttack: 0.15 },
    },
    {
      id: "rare_stamina_recovery",
      name: "Tempest Coil",
      effect: "Stamina recovery +15%",
      rarity: "rare",
      mods: { staminaRecovery: 0.15 },
    },
    {
      id: "rare_healing",
      name: "Moon Chalice",
      effect: "Flask healing +15%",
      rarity: "rare",
      mods: { healing: 0.15 },
    },
    {
      id: "mythic_attack",
      name: "Abyssal Claw",
      effect: "Attack damage +30%",
      rarity: "mythic",
      dropChance: 3,
      mods: { attack: 0.3 },
    },
    {
      id: "mythic_defense",
      name: "Violet Bastion",
      effect: "Defense +30%",
      rarity: "mythic",
      dropChance: 3,
      mods: { defense: 0.3 },
    },
    {
      id: "mythic_cooldown",
      name: "Chronomancer Shard",
      effect: "Skill recovery +30%",
      rarity: "mythic",
      dropChance: 3,
      mods: { cooldown: 0.3 },
    },
    {
      id: "mythic_health",
      name: "Amethyst Heart",
      effect: "Maximum health +80",
      rarity: "mythic",
      dropChance: 3,
      mods: { health: 80 },
    },
    {
      id: "mythic_stamina",
      name: "Astral Current",
      effect: "Maximum stamina +70",
      rarity: "mythic",
      dropChance: 3,
      mods: { stamina: 70 },
    },
    {
      id: "mythic_skill_attack",
      name: "Arcane Sigil",
      effect: "Skill attack power +30%",
      rarity: "mythic",
      mods: { skillAttack: 0.3 },
    },
    {
      id: "mythic_stamina_recovery",
      name: "Astral Coil",
      effect: "Stamina recovery +30%",
      rarity: "mythic",
      mods: { staminaRecovery: 0.3 },
    },
    {
      id: "mythic_healing",
      name: "Amethyst Chalice",
      effect: "Flask healing +30%",
      rarity: "mythic",
      mods: { healing: 0.3 },
    },
    {
      id: "legendary_attack",
      name: "Sunlord Fang",
      effect: "Attack damage +50%",
      rarity: "legendary",
      dropChance: 0.8,
      mods: { attack: 0.5 },
    },
    {
      id: "legendary_defense",
      name: "Golden Aegis",
      effect: "Defense +50%",
      rarity: "legendary",
      dropChance: 0.8,
      mods: { defense: 0.5 },
    },
    {
      id: "legendary_cooldown",
      name: "Eternal Hourglass",
      effect: "Skill recovery +50%",
      rarity: "legendary",
      dropChance: 0.8,
      mods: { cooldown: 0.5 },
    },
    {
      id: "legendary_health",
      name: "Radiant Heart",
      effect: "Maximum health +120",
      rarity: "legendary",
      dropChance: 0.8,
      mods: { health: 120 },
    },
    {
      id: "legendary_stamina",
      name: "Lion Current",
      effect: "Maximum stamina +100",
      rarity: "legendary",
      dropChance: 0.8,
      mods: { stamina: 100 },
    },
    {
      id: "legendary_skill_attack",
      name: "Solar Sigil",
      effect: "Skill attack power +50%",
      rarity: "legendary",
      mods: { skillAttack: 0.5 },
    },
    {
      id: "legendary_stamina_recovery",
      name: "Golden Coil",
      effect: "Stamina recovery +50%",
      rarity: "legendary",
      mods: { staminaRecovery: 0.5 },
    },
    {
      id: "legendary_healing",
      name: "Grail of Grace",
      effect: "Flask healing +50%",
      rarity: "legendary",
      mods: { healing: 0.5 },
    },
    {
      id: "anis_attack",
      name: "Anis Bloodfang",
      effect: "Attack damage +100%",
      rarity: "anis",
      dropChance: 0.2,
      mods: { attack: 1 },
    },
    {
      id: "anis_defense",
      name: "Anis Absolute",
      effect: "Defense +100%",
      rarity: "anis",
      dropChance: 0.2,
      mods: { defense: 1 },
    },
    {
      id: "anis_cooldown",
      name: "Anis Eternity",
      effect: "Skill recovery +100%",
      rarity: "anis",
      dropChance: 0.2,
      mods: { cooldown: 1 },
    },
    {
      id: "anis_health",
      name: "Anis Bloodheart",
      effect: "Maximum health +200",
      rarity: "anis",
      dropChance: 0.2,
      mods: { health: 200 },
    },
    {
      id: "anis_stamina",
      name: "Anis Red Current",
      effect: "Maximum stamina +150",
      rarity: "anis",
      dropChance: 0.2,
      mods: { stamina: 150 },
    },
    {
      id: "anis_skill_attack",
      name: "Bloodmoon Sigil",
      effect: "Skill attack power +100%",
      rarity: "anis",
      mods: { skillAttack: 1 },
    },
    {
      id: "anis_stamina_recovery",
      name: "Anis Vortex",
      effect: "Stamina recovery +100%",
      rarity: "anis",
      mods: { staminaRecovery: 1 },
    },
    {
      id: "anis_healing",
      name: "Crimson Grail",
      effect: "Flask healing +100%",
      rarity: "anis",
      mods: { healing: 1 },
    },
    {
      id: "hardy_relic",
      name: "Hardy Relic",
      effect: "All eight Anis powers in one relic",
      rarity: "anis",
      dropChance: 0.01,
      hardy: true,
      mods: {
        attack: 1,
        defense: 1,
        cooldown: 1,
        health: 200,
        stamina: 150,
        skillAttack: 1,
        staminaRecovery: 1,
        healing: 1,
      },
    },
  ];
  let profile = {
      coins: 0,
      inventory: {},
      slots: [null, null, null],
      resolution: "1280x720",
      graphics: "high",
      hero: "knight",
      consoleKey: "Backquote",
    },
    selectedRelic = null,
    spinLocked = false;
  function loadProfile() {
    try {
      const x = JSON.parse(localStorage.getItem("gilded_profile_v1") || "null");
      if (x && typeof x === "object")
        profile = {
          ...profile,
          ...x,
          inventory: { ...(x.inventory || {}) },
          slots: Array.isArray(x.slots)
            ? x.slots.slice(0, 3)
            : [null, null, null],
        };
    } catch (e) {}
    while (profile.slots.length < 3) profile.slots.push(null);
    profile.coins = Math.max(0, Math.floor(+profile.coins || 0));
    if (!["low", "medium", "high"].includes(profile.graphics))
      profile.graphics = "high";
    const validRes = [
      "800x600",
      "1152x864",
      "1280x1024",
      "1280x720",
      "1600x900",
      "1680x1050",
      "1280x800",
      "1920x1080",
    ];
    if (typeof profile.resolution === "number")
      profile.resolution = profile.resolution > 1 ? "1600x900" : "1280x720";
    if (!validRes.includes(profile.resolution)) profile.resolution = "1280x720";
    if (typeof profile.consoleKey !== "string")
      profile.consoleKey = "Backquote";
    if (["knight", "shadow", "ronin", "regal", "wizard", "killnux"].includes(profile.hero))
      heroType = profile.hero;
  }
  function saveProfile() {
    try {
      localStorage.setItem("gilded_profile_v1", JSON.stringify(profile));
    } catch (e) {}
  }
  function relicById(id) {
    return RELICS.find((r) => r.id === id);
  }
  function rarityById(id) {
    return RARITIES.find((r) => r.id === id) || RARITIES[0];
  }
  function equippedCount(id) {
    return profile.slots.filter((x) => x === id).length;
  }
  function buildBonuses() {
    const out = {
      attack: 0,
      stamina: 0,
      defense: 0,
      health: 0,
      cooldown: 0,
      skillAttack: 0,
      staminaRecovery: 0,
      healing: 0,
    };
    for (const id of profile.slots) {
      const r = relicById(id);
      if (!r) continue;
      for (const k in r.mods) out[k] += r.mods[k] || 0;
    }
    return out;
  }
  function qualityFactor() {
    return profile.graphics === "low"
      ? 0.2
      : profile.graphics === "medium"
        ? 0.55
        : 1;
  }
  function applyVideoSettings() {
    const m = /^(\d+)x(\d+)$/.exec(profile.resolution) || ["", 1280, 720],
      rw = +m[1],
      rh = +m[2],
      requestedFactor =
        profile.graphics === "low"
          ? 0.5
          : profile.graphics === "medium"
            ? 0.75
            : 1,
      renderFactor = Math.max(requestedFactor, 480 / rw),
      internalW = Math.round(rw * renderFactor),
      internalH = Math.round(rh * renderFactor);
    cv.width = internalW;
    cv.height = internalH;
    layerScale =
      profile.graphics === "low"
        ? 0.45
        : profile.graphics === "medium"
          ? 0.8
          : 1.25;
    stage.style.setProperty("--aspect", String(rw / rh));
    stage.classList.remove("quality-low", "quality-medium", "quality-high");
    stage.classList.add("quality-" + profile.graphics);
    stage.classList.add("res-changing");
    setTimeout(() => stage.classList.remove("res-changing"), 320);
    fit();
    if ($("resolutionScale")) $("resolutionScale").value = profile.resolution;
    if ($("graphicsMode")) $("graphicsMode").value = profile.graphics;
    if ($("renderInfo"))
      $("renderInfo").textContent =
        "Display " +
        rw +
        " × " +
        rh +
        " · Internal render " +
        internalW +
        " × " +
        internalH +
        " (" +
        Math.round(renderFactor * 100) +
        "%)";
  }
  function updateCoinLabels() {
    if ($("menuCoins")) $("menuCoins").textContent = profile.coins + " COINS";
    if ($("shopCoins")) $("shopCoins").textContent = profile.coins;
  }
  function toast(msg) {
    const d = document.createElement("div");
    d.className = "relic-toast";
    d.textContent = msg;
    stage.appendChild(d);
    setTimeout(() => d.remove(), 1600);
  }
  function heroDisplayName() {
    return heroType === "shadow"
      ? "Shadow"
      : heroType === "ronin"
        ? "Crimson Ronin"
        : heroType === "regal"
          ? "Metal Regal"
          : heroType === "wizard"
            ? "The Arcane Wizard"
            : heroType === "killnux"
              ? "Killnux"
              : "The Gilded Knight";
  }
  function hideFrontScreens() {
    ["title", "bossSelect", "loadout", "shop", "multiplayerLobby"].forEach(
      (id) => $(id) && $(id).classList.add("hide"),
    );
  }
  function showFrontScreen(id) {
    hideFrontScreens();
    $(id).classList.remove("hide");
    phase = "title";
    updateCoinLabels();
    if (id === "loadout") renderLoadout();
    if (id === "shop") renderShop();
    if (id === "bossSelect" && $("bossHeroName"))
      $("bossHeroName").textContent = heroDisplayName();
  }
  function relicShape(r) {
    if (!r) return "shard";
    if (r.hardy) return "hardy";
    const m = r.mods || {};
    return m.skillAttack
      ? "sigil"
      : m.staminaRecovery
        ? "coil"
        : m.healing
          ? "chalice"
          : m.attack
            ? "shard"
            : m.defense
              ? "bastion"
              : m.health
                ? "heart"
                : m.cooldown
                  ? "hourglass"
                  : "current";
  }
  function crystalHTML(r) {
    return (
      '<span class="crystal rarity-' +
      (r ? r.rarity : "common") +
      " shape-" +
      relicShape(r) +
      '"><i></i></span>'
    );
  }
  function relicDropChance(r) {
    if (r.hardy) return "0.01%";
    const q = rarityById(r.rarity),
      n = RELICS.filter((x) => x.rarity === r.rarity && !x.hardy).length,
      v = q.chance / n;
    return Math.round(v * 1000) / 1000 + "%";
  }
  function renderLoadout() {
    const slots = $("relicSlots"),
      inv = $("relicInventory");
    if (!slots || !inv) return;
    slots.innerHTML = "";
    inv.innerHTML = "";
    profile.slots.forEach((id, i) => {
      const r = relicById(id),
        b = document.createElement("button");
      b.className = "relic-slot" + (r ? " filled rarity-" + r.rarity : "");
      b.innerHTML = r
        ? crystalHTML(r) +
          "<b>" +
          r.name +
          "</b><small>" +
          rarityById(r.rarity).name +
          "</small>"
        : "CASE " + (i + 1) + "<b>EMPTY</b>";
      b.onclick = () => {
        if (r) {
          profile.slots[i] = null;
          saveProfile();
          renderLoadout();
          return;
        }
        if (!selectedRelic) return;
        const owned = profile.inventory[selectedRelic] || 0,
          used = equippedCount(selectedRelic);
        if (used >= owned) {
          toast("No unequipped copy available");
          return;
        }
        profile.slots[i] = selectedRelic;
        saveProfile();
        renderLoadout();
      };
      slots.appendChild(b);
    });
    let any = false;
    for (const r of RELICS) {
      const n = profile.inventory[r.id] || 0;
      if (!n) continue;
      any = true;
      const used = equippedCount(r.id),
        b = document.createElement("button");
      b.className =
        "inv-relic rarity-" +
        r.rarity +
        (selectedRelic === r.id ? " selected" : "");
      b.innerHTML =
        crystalHTML(r) +
        "<span><b>" +
        r.name +
        "</b> <i>" +
        rarityById(r.rarity).name +
        "</i><br>" +
        r.effect +
        " · equipped " +
        used +
        "</span><strong>x" +
        n +
        "</strong>";
      b.onclick = () => {
        selectedRelic = r.id;
        renderLoadout();
      };
      inv.appendChild(b);
    }
    if (!any)
      inv.innerHTML =
        '<div class="empty-state">No relics yet. Visit the Relic Shop after earning coins.</div>';
    const q = buildBonuses();
    $("buildStats").innerHTML = [
      ["ATK", "+" + Math.round(q.attack * 100) + "%"],
      ["SKL", "+" + Math.round(q.skillAttack * 100) + "%"],
      ["STA", "+" + q.stamina],
      ["ST-R", "+" + Math.round(q.staminaRecovery * 100) + "%"],
      ["DEF", "+" + Math.round(q.defense * 100) + "%"],
      ["HP", "+" + q.health],
      ["HEAL", "+" + Math.round(q.healing * 100) + "%"],
      ["REC", "+" + Math.round(q.cooldown * 100) + "%"],
    ]
      .map(
        (x) => '<div class="build-stat">' + x[0] + "<b>" + x[1] + "</b></div>",
      )
      .join("");
  }
  function renderShop() {
    updateCoinLabels();
    const list = $("shopRelicList"),
      inv = $("shopInventory");
    if (!list || !inv) return;
    const listTop = list.scrollTop,
      invTop = inv.scrollTop;
    list.innerHTML = RARITIES.map(
      (q) =>
        '<div class="rarity-heading rarity-' +
        q.id +
        '"><b>' +
        q.name.toUpperCase() +
        "</b><span>" +
        q.chance +
        "% TOTAL</span></div>" +
        RELICS.filter((r) => r.rarity === q.id)
          .sort((a, b) => Number(!!b.hardy) - Number(!!a.hardy))
          .map(
            (r) =>
              '<div class="shop-relic rarity-' +
              r.rarity +
              '">' +
              crystalHTML(r) +
              "<span><b>" +
              r.name +
              "</b><br>" +
              r.effect +
              '</span><span class="chance">' +
              relicDropChance(r) +
              "</span></div>",
          )
          .join(""),
    ).join("");
    inv.innerHTML = "";
    let any = false;
    for (const r of RELICS) {
      const n = profile.inventory[r.id] || 0;
      if (!n) continue;
      any = true;
      const row = document.createElement("div");
      row.className = "shop-relic rarity-" + r.rarity;
      row.innerHTML =
        crystalHTML(r) +
        "<span><b>" +
        r.name +
        "</b> <i>" +
        rarityById(r.rarity).name +
        "</i><br>Owned x" +
        n +
        " · equipped " +
        equippedCount(r.id) +
        "</span>";
      if (r.rarity === "common") {
        const b = document.createElement("button");
        b.className = "sell-btn";
        b.textContent = "SELL +40";
        b.onclick = () => sellRelic(r.id);
        row.appendChild(b);
      } else {
        const badge = document.createElement("span");
        badge.className = "keep-badge";
        badge.textContent = rarityById(r.rarity).name;
        row.appendChild(badge);
      }
      inv.appendChild(row);
    }
    if (!any)
      inv.innerHTML =
        '<div class="empty-state">Your collection is empty.</div>';
    $("spinRelic").disabled = profile.coins < 100 || spinLocked;
    requestAnimationFrame(() => {
      list.scrollTop = listTop;
      inv.scrollTop = invTop;
    });
  }
  function rollRelic() {
    const hardy = RELICS.find((r) => r.hardy);
    if (hardy && Math.random() < 0.0001) return hardy;
    let roll = Math.random() * 100,
      rarity = "common",
      sum = 0;
    for (const q of RARITIES) {
      sum += q.chance;
      if (roll < sum) {
        rarity = q.id;
        break;
      }
    }
    const pool = RELICS.filter((r) => r.rarity === rarity && !r.hardy);
    return pool[Math.floor(Math.random() * pool.length)];
  }
  function spinRelic() {
    if (spinLocked) return;
    if (profile.coins < 100) {
      toast("You need 100 coins");
      return;
    }
    profile.coins -= 100;
    spinLocked = true;
    saveProfile();
    renderShop();
    const crystal = $("spinCrystal");
    crystal.className = "spin-crystal spinning";
    $("spinResult").textContent = "The crystal is turning…";
    setTimeout(() => {
      const r = rollRelic(),
        q = rarityById(r.rarity);
      profile.inventory[r.id] = (profile.inventory[r.id] || 0) + 1;
      spinLocked = false;
      saveProfile();
      $("spinResult").innerHTML =
        '<strong class="rarity-text-' +
        r.rarity +
        '">' +
        q.name.toUpperCase() +
        "</strong><br><b>" +
        r.name +
        "</b><br>" +
        r.effect;
      crystal.className =
        "spin-crystal rarity-" + r.rarity + " spin-shape-" + relicShape(r);
      renderShop();
      toast(q.name + " relic acquired: " + r.name);
    }, 850);
  }
  function sellRelic(id) {
    const r = relicById(id);
    if (!r || r.rarity !== "common") {
      toast("Only Common relics can be sold right now");
      return;
    }
    const n = profile.inventory[id] || 0,
      used = equippedCount(id);
    if (n <= used) {
      toast("Unequip this relic before selling it");
      return;
    }
    profile.inventory[id] = n - 1;
    profile.coins += 40;
    saveProfile();
    renderShop();
    toast("Common relic sold for 40 coins");
  }
  function awardCoins(n) {
    profile.coins += n;
    saveProfile();
    updateCoinLabels();
  }
  loadProfile();

  const imgHero = new Image(),
    imgBoss = new Image();
  const imgArt = new Image();
  imgArt.src = ART1_SRC;
  const imgShadowHero = new Image();
  imgShadowHero.src = SHADOW_SRC;
  const imgRoninHero = new Image();
  imgRoninHero.src = RONIN_SRC;
  const imgRegalHero = new Image();
  imgRegalHero.src = REGAL_SRC;
  const imgWizardHero = new Image();
  imgWizardHero.src = WIZARD_SRC;
  const imgKillnuxHero = new Image();
  imgKillnuxHero.src = KILLNUX_SRC;
  const imgShogun = new Image();
  imgShogun.src = SHOGUN_SRC;
  const imgShogunP2 = new Image();
  imgShogunP2.src = SHOGUN_P2_SRC;
  const imgDemonFace = new Image();
  imgDemonFace.src = DEMON_FACE_SRC;
  imgHero.src = HERO_SRC;
  imgBoss.src = BOSS_SRC;
  if ($("cSent")) {
    $("cSent").style.backgroundImage = "url('" + BOSS_SRC + "')";
    $("cArt").style.backgroundImage = "url('" + ART_MENU_SRC + "')";
    $("cShogun").style.backgroundImage = "url('" + SHOGUN_SRC + "')";
  }
  if ($("cShadow")) {
    $("cShadow").style.backgroundImage = "url('" + SHADOW_SRC + "')";
    $("cKnight").style.backgroundImage = "url('" + HERO_SRC + "')";
    $("cRonin").style.backgroundImage = "url('" + RONIN_SRC + "')";
    $("cRegal").style.backgroundImage = "url('" + REGAL_SRC + "')";
    $("cWizard").style.backgroundImage = "url('" + WIZARD_SRC + "')";
    $("cKillnux").style.backgroundImage = "url('" + KILLNUX_SRC + "')";
  }

  /* ================= AUDIO ================= */
  let AC = null,
    muted = false;
  function ac() {
    if (!AC) {
      try {
        AC = new (window.AudioContext || window.webkitAudioContext)();
      } catch (e) {
        AC = null;
      }
      if (AC) initAudioGraph(AC);
    }
    if (AC && AC.state === "suspended") AC.resume();
    return AC;
  }
  function tone(f, d, type, v, slide, delay) {
    const a = AC;
    if (!a || muted) return;
    const t = a.currentTime + (delay || 0);
    const o = a.createOscillator(),
      g = a.createGain();
    o.type = type || "sine";
    o.frequency.setValueAtTime(f, t);
    if (slide)
      o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d);
    g.gain.setValueAtTime(v || 0.12, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g);
    g.connect(sfxBus || a.destination);
    o.start(t);
    o.stop(t + d + 0.03);
  }
  function noise(d, v, f, kind, slide, delay) {
    const a = AC;
    if (!a || muted) return;
    const t = a.currentTime + (delay || 0);
    const s = a.createBufferSource();
    s.buffer = getNoise(a);
    s.loop = true;
    const fl = a.createBiquadFilter();
    fl.type = kind || "lowpass";
    fl.frequency.setValueAtTime(f || 1000, t);
    if (slide)
      fl.frequency.exponentialRampToValueAtTime(Math.max(40, f + slide), t + d);
    const g = a.createGain();
    g.gain.setValueAtTime(v || 0.2, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(fl);
    fl.connect(g);
    g.connect(sfxBus || a.destination);
    s.start(t);
    s.stop(t + d + 0.03);
  }
  function sfx(n) {
    if (!AC || muted) return;
    switch (n) {
      case "swing":
        noise(0.16, 0.16, 2600, "bandpass", -1800);
        break;
      case "bswing":
        noise(0.28, 0.24, 900, "bandpass", -500);
        tone(90, 0.25, "sawtooth", 0.05, -40);
        break;
      case "hit":
        noise(0.12, 0.3, 1800, "lowpass", -1200);
        tone(160, 0.12, "square", 0.09, -90);
        break;
      case "hurt":
        noise(0.25, 0.35, 900, "lowpass", -600);
        tone(110, 0.3, "sawtooth", 0.12, -70);
        break;
      case "parry":
        tone(1500, 0.5, "triangle", 0.16, -300);
        tone(2300, 0.35, "sine", 0.1, -600);
        noise(0.08, 0.25, 4000, "highpass");
        tone(200, 0.2, "square", 0.08, -100);
        break;
      case "boom":
        noise(1.1, 0.55, 500, "lowpass", -380);
        tone(70, 0.9, "sine", 0.4, -45);
        break;
      case "charge":
        tone(110, 1.1, "sawtooth", 0.06, 520);
        tone(220, 1.1, "sine", 0.07, 700);
        break;
      case "beam":
        noise(0.6, 0.4, 3000, "bandpass", -2000);
        tone(180, 0.5, "sawtooth", 0.18, -80);
        tone(360, 0.5, "square", 0.06, -120);
        break;
      case "heal":
        tone(520, 0.5, "sine", 0.11, 260);
        tone(780, 0.5, "sine", 0.08, 300, 0.1);
        tone(1040, 0.5, "sine", 0.06, 200, 0.2);
        break;
      case "dodge":
        noise(0.2, 0.12, 1200, "bandpass", -700);
        break;
      case "jump":
        tone(200, 0.12, "sine", 0.05, 120);
        break;
      case "roar":
        noise(1.2, 0.4, 500, "lowpass", -300);
        tone(60, 1.2, "sawtooth", 0.18, 30);
        break;
      case "demonRoar":
        noise(2.0, 0.55, 620, "lowpass", -480);
        noise(1.4, 0.24, 1700, "bandpass", -1200, 0.12);
        tone(46, 1.9, "sawtooth", 0.26, 24);
        tone(72, 1.3, "square", 0.08, -30, 0.18);
        break;
      case "crack":
        noise(0.48, 0.42, 850, "lowpass", -650);
        tone(48, 0.55, "sine", 0.28, -18);
        break;
      case "knife":
        noise(0.13, 0.18, 3400, "highpass", -1800);
        tone(640, 0.12, "sawtooth", 0.05, -280);
        break;
      case "die":
        tone(300, 1.6, "sawtooth", 0.12, -250);
        noise(1.6, 0.3, 800, "lowpass", -700);
        break;
      case "win":
        tone(392, 1, "triangle", 0.1);
        tone(523, 1.2, "triangle", 0.1, 0, 0.25);
        tone(659, 1.6, "triangle", 0.1, 0, 0.5);
        break;
      case "plunge":
        noise(0.35, 0.2, 1500, "lowpass", -1000);
        break;
      case "skill1":
        tone(700, 0.05, "triangle", 0.05, 200);
        tone(1500, 0.3, "triangle", 0.13, 900);
        noise(0.22, 0.22, 4500, "highpass", -2200);
        tone(2600, 0.18, "sine", 0.07, -400, 0.04);
        break;
      case "skill2":
        noise(0.7, 0.5, 400, "lowpass", -260);
        tone(55, 1.1, "sawtooth", 0.4, -35);
        tone(140, 0.5, "square", 0.16, -90, 0.03);
        noise(0.3, 0.3, 3000, "bandpass", -2000, 0.02);
        break;
      case "shot":
        noise(0.09, 0.16, 3200, "bandpass", -1200);
        tone(1100, 0.08, "triangle", 0.07, 500);
        break;
      case "skill2rain":
        tone(500, 0.5, "triangle", 0.1, 700);
        noise(0.4, 0.22, 5000, "highpass");
        tone(900, 0.4, "sine", 0.07, 1200, 0.08);
        break;
      case "block":
        tone(240, 0.2, "square", 0.1, -110);
        noise(0.1, 0.25, 2500, "bandpass");
        tone(900, 0.15, "triangle", 0.05, -300);
        break;
    }
  }
  $("mute").addEventListener("click", () => {
    muted = !muted;
    $("mute").textContent = muted ? "🔇" : "🔊";
    applyVolumes();
  });

  /* ================= MUSIC: synthesized solo piano ================= */
  // Everything below is original: a small piano synth plus original compositions.
  const audioCfg = { music: 0.8, sfx: 0.9 };
  let sfxBus = null,
    MG = null;
  const noiseCache = new WeakMap();
  function getNoise(a) {
    let b = noiseCache.get(a);
    if (!b) {
      b = a.createBuffer(1, a.sampleRate, a.sampleRate);
      const d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      noiseCache.set(a, b);
    }
    return b;
  }
  function makeIR(a) {
    const secs = 3.6,
      len = Math.floor(a.sampleRate * secs),
      ir = a.createBuffer(2, len, a.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = ir.getChannelData(ch);
      let y = 0;
      for (let i = 0; i < len; i++) {
        const t = i / len,
          n = Math.random() * 2 - 1;
        y += (n - y) * (0.75 - 0.6 * t);
        d[i] = y * Math.pow(1 - t, 2.4) * (i < 400 ? i / 400 : 1);
      }
    }
    return ir;
  }
  function buildMusicGraph(a) {
    const comp = a.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 12;
    comp.ratio.value = 3.5;
    comp.attack.value = 0.012;
    comp.release.value = 0.35;
    comp.connect(a.destination);
    const bus = a.createGain();
    bus.connect(comp);
    const conv = a.createConvolver();
    conv.buffer = makeIR(a);
    const send = a.createGain();
    send.gain.value = 0.5;
    send.connect(conv);
    const wet = a.createGain();
    wet.gain.value = 0.9;
    conv.connect(wet);
    wet.connect(bus);
    return { bus, send };
  }
  function initAudioGraph(a) {
    sfxBus = a.createGain();
    sfxBus.connect(a.destination);
    MG = buildMusicGraph(a);
    applyVolumes();
  }
  function applyVolumes() {
    if (!AC || !MG) return;
    const t = AC.currentTime;
    MG.bus.gain.setTargetAtTime(muted ? 0 : audioCfg.music, t, 0.05);
    sfxBus.gain.setTargetAtTime(muted ? 0 : audioCfg.sfx, t, 0.05);
  }

  /* --- piano voice --- */
  const waveCache = new WeakMap();
  function pianoWave(a, midi) {
    let m = waveCache.get(a);
    if (!m) {
      m = {};
      waveCache.set(a, m);
    }
    const reg = clamp(Math.floor((midi - 24) / 12), 0, 7);
    if (!m[reg]) {
      const n = 16,
        re = new Float32Array(n + 1),
        im = new Float32Array(n + 1);
      for (let h = 1; h <= n; h++)
        im[h] =
          (1 / Math.pow(h, 1.05)) *
          Math.exp(-h * (0.1 + reg * 0.045)) *
          (h % 2 === 0 ? 0.85 : 1) *
          (h === 3 ? 1.1 : 1);
      m[reg] = a.createPeriodicWave(re, im);
    }
    return m[reg];
  }
  function pianoNote(a, dest, midi, when, durS, vel, pedal) {
    const f = 440 * Math.pow(2, (midi - 69) / 12);
    const nat = clamp(6.4 - (midi - 30) * 0.062, 1.4, 6.2);
    const total = Math.min(nat, Math.max(0.35, durS + pedal));
    const peak = vel * clamp(0.17 - (midi - 40) * 0.0009, 0.08, 0.17);
    const t = Math.max(when, a.currentTime),
      g = a.createGain(),
      lp = a.createBiquadFilter();
    lp.type = "lowpass";
    lp.Q.value = 0.5;
    lp.frequency.setValueAtTime(Math.min(15000, f * (4 + vel * 10)), t);
    lp.frequency.exponentialRampToValueAtTime(
      Math.max(400, f * 2.2),
      t + Math.min(1.2, total),
    );
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + 0.006);
    g.gain.exponentialRampToValueAtTime(
      peak * 0.5,
      t + Math.min(0.35, total * 0.4),
    );
    g.gain.exponentialRampToValueAtTime(0.0001, t + total);
    const w = pianoWave(a, midi);
    for (const dt of [-1.8, 1.8]) {
      const o = a.createOscillator();
      o.setPeriodicWave(w);
      o.frequency.value = f;
      o.detune.value = dt;
      o.connect(lp);
      o.start(t);
      o.stop(t + total + 0.05);
    }
    lp.connect(g);
    g.connect(dest);
    const ns = a.createBufferSource();
    ns.buffer = getNoise(a);
    const nf = a.createBiquadFilter();
    nf.type = "bandpass";
    nf.frequency.value = Math.min(5000, f * 3);
    nf.Q.value = 0.8;
    const ng = a.createGain();
    ng.gain.setValueAtTime(vel * 0.035, t);
    ng.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);
    ns.connect(nf);
    nf.connect(ng);
    ng.connect(dest);
    ns.start(t);
    ns.stop(t + 0.06);
  }

  /* --- notes and chords --- */
  const NOTE_SEMI = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
  function nn(s) {
    const m = /^([A-G])([#b]?)(\d)$/.exec(s);
    return (
      NOTE_SEMI[m[1]] +
      (m[2] === "#" ? 1 : m[2] === "b" ? -1 : 0) +
      (parseInt(m[3], 10) + 1) * 12
    );
  }
  // b = bass, a = left-hand arpeggio notes, t = triad, ra = right-hand arpeggio notes
  const CH = {
    Dm: {
      b: 38,
      a: [45, 50, 53, 57, 62],
      t: [62, 65, 69],
      ra: [57, 62, 65, 69, 74],
    },
    Bb: { b: 34, a: [41, 46, 50, 53, 58], t: [58, 62, 65] },
    Gm: { b: 43, a: [50, 55, 58, 62, 67], t: [58, 62, 67] },
    A: { b: 33, a: [45, 52, 57, 61, 64], t: [57, 61, 64] },
    F: {
      b: 41,
      a: [48, 53, 57, 60, 65],
      t: [57, 60, 65],
      ra: [53, 57, 60, 65, 69],
    },
    C: {
      b: 36,
      a: [48, 52, 55, 60, 64],
      t: [60, 64, 67],
      ra: [55, 60, 64, 67, 72],
    },
    Am: {
      b: 33,
      a: [45, 52, 57, 60, 64],
      t: [57, 60, 64],
      ra: [57, 60, 64, 69, 72],
    },
    G: {
      b: 43,
      a: [50, 55, 59, 62, 67],
      t: [59, 62, 67],
      ra: [55, 59, 62, 67, 71],
    },
    E: {
      b: 40,
      a: [40, 47, 52, 56, 59],
      t: [56, 59, 64],
      ra: [56, 59, 64, 68, 71],
    },
    D: { b: 38, a: [50, 54, 57, 62, 66], t: [62, 66, 69] },
    Bm: { b: 35, a: [47, 54, 59, 62, 66], t: [59, 62, 66] },
  };
  const melBars = (arr) =>
    arr.map((bar) => bar.map((m) => [m[0], nn(m[1]), m[2]]));

  /* Title theme: slow, sparse and mournful (D minor) */
  const TITLE_A = ["Dm", "Bb", "Gm", "A", "Dm", "F", "Bb", "A"];
  const TITLE_B = ["Gm", "Dm", "Bb", "F", "Gm", "A", "Dm", "Dm"];
  const MEL_TA = melBars([
    [
      [0, "A4", 3],
      [3, "G4", 1],
    ],
    [
      [0, "F4", 2],
      [2, "G4", 1],
      [3, "A4", 1],
    ],
    [
      [0, "Bb4", 3],
      [3, "A4", 1],
    ],
    [
      [0, "G4", 2],
      [2, "E4", 2],
    ],
    [
      [0, "D5", 3],
      [3, "C5", 1],
    ],
    [
      [0, "A4", 2],
      [2, "C5", 2],
    ],
    [
      [0, "D5", 2],
      [2, "C5", 1],
      [3, "Bb4", 1],
    ],
    [
      [0, "C#5", 2],
      [2, "A4", 2],
    ],
  ]);
  const MEL_TB = melBars([
    [
      [0, "Bb4", 1],
      [1, "D5", 1],
      [2, "G5", 2],
    ],
    [
      [0, "F5", 3],
      [3, "E5", 1],
    ],
    [
      [0, "D5", 2],
      [2, "F5", 2],
    ],
    [
      [0, "A5", 3],
      [3, "G5", 1],
    ],
    [
      [0, "Bb5", 2],
      [2, "A5", 1],
      [3, "G5", 1],
    ],
    [
      [0, "E5", 2],
      [2, "A5", 2],
    ],
    [
      [0, "F5", 2],
      [2, "D5", 2],
    ],
    [[0, "D5", 4]],
  ]);
  function titleGen(b) {
    const sec = Math.floor(b / 8),
      i = b % 8,
      ch = CH[(sec === 1 ? TITLE_B : TITLE_A)[i]],
      ev = [];
    ev.push([0, ch.b, 4, 0.5]);
    if (sec === 2) ev.push([0, ch.b + 12, 4, 0.34]);
    const pat = [0, 2, 3, 4, 3, 2, 1, 2];
    for (let k = 0; k < 8; k++)
      ev.push([k * 0.5, ch.a[pat[k]], 0.5, k === 0 ? 0.3 : k % 2 ? 0.2 : 0.25]);
    for (const m of (sec === 1 ? MEL_TB : MEL_TA)[i]) {
      ev.push([m[0], m[1], m[2], 0.6]);
      if (sec === 2) ev.push([m[0], m[1] - 12, m[2], 0.32]);
    }
    return ev;
  }

  /* Battle theme 1: The Violet Sentinel (D minor, driving left hand) */
  const SENT_PROG = [
    "Dm",
    "Dm",
    "Bb",
    "C",
    "Dm",
    "Dm",
    "Gm",
    "A",
    "Dm",
    "F",
    "Bb",
    "C",
    "Gm",
    "A",
    "Dm",
    "A",
  ];
  const MEL_S = melBars([
    [
      [0, "D5", 1.5],
      [1.5, "F5", 0.5],
      [2, "A5", 2],
    ],
    [
      [0, "G5", 1],
      [1, "F5", 1],
      [2, "E5", 2],
    ],
    [
      [0, "D5", 1.5],
      [1.5, "F5", 0.5],
      [2, "Bb5", 2],
    ],
    [
      [0, "A5", 1],
      [1, "G5", 1],
      [2, "E5", 2],
    ],
    [
      [0, "F5", 1],
      [1, "A5", 1],
      [2, "D6", 2],
    ],
    [
      [0, "C6", 1],
      [1, "A5", 1],
      [2, "F5", 2],
    ],
    [
      [0, "G5", 1.5],
      [1.5, "Bb5", 0.5],
      [2, "D6", 2],
    ],
    [
      [0, "C#6", 1],
      [1, "E6", 1],
      [2, "A5", 2],
    ],
    [
      [0, "D6", 2],
      [2, "C6", 1],
      [3, "A5", 1],
    ],
    [
      [0, "A5", 1.5],
      [1.5, "C6", 0.5],
      [2, "F6", 2],
    ],
    [
      [0, "D6", 2],
      [2, "C6", 1],
      [3, "Bb5", 1],
    ],
    [
      [0, "G5", 1],
      [1, "A5", 1],
      [2, "G5", 2],
    ],
    [
      [0, "Bb5", 1],
      [1, "A5", 1],
      [2, "G5", 1],
      [3, "F5", 1],
    ],
    [
      [0, "E5", 1],
      [1, "G5", 1],
      [2, "A5", 2],
    ],
    [
      [0, "F5", 2],
      [2, "D5", 2],
    ],
    [
      [0, "E5", 2],
      [2, "C#5", 2],
    ],
  ]);
  function sentGen(b, hi) {
    const ch = CH[SENT_PROG[b]],
      ev = [],
      R = ch.b + 12;
    const pat = [R, R + 7, R + 12, R + 7, R, R + 7, R + 12, R + 7];
    for (let k = 0; k < 8; k++)
      ev.push([
        k * 0.5,
        pat[k],
        0.5,
        k % 4 === 0 ? 0.58 : k % 2 === 0 ? 0.46 : 0.34,
      ]);
    ev.push([0, ch.b, 2, 0.8]);
    ev.push([2, ch.b, 2, 0.66]);
    if (hi) {
      ev.push([1, ch.b, 1, 0.55]);
      ev.push([3, ch.b, 1, 0.55]);
    }
    for (const beat of hi ? [0, 1, 2, 3] : [0, 2])
      for (const n of ch.t) ev.push([beat, n, 1.6, 0.34]);
    for (const m of MEL_S[b]) {
      ev.push([m[0], m[1], m[2], 0.78]);
      if (hi) ev.push([m[0], m[1] - 12, m[2], 0.5]);
    }
    return ev;
  }

  /* Battle theme 2: Artorias (A minor, tolling bass and rising arpeggios) */
  const ART_PROG = [
    "Am",
    "F",
    "C",
    "G",
    "Am",
    "F",
    "Dm",
    "E",
    "Am",
    "F",
    "C",
    "G",
    "Dm",
    "Am",
    "E",
    "E",
  ];
  const MEL_A = melBars([
    [
      [0, "E5", 2],
      [2, "A5", 1],
      [3, "G5", 1],
    ],
    [
      [0, "F5", 2],
      [2, "A5", 2],
    ],
    [
      [0, "G5", 2],
      [2, "E5", 1],
      [3, "C5", 1],
    ],
    [
      [0, "D5", 2],
      [2, "B4", 2],
    ],
    [
      [0, "E5", 2],
      [2, "A5", 1],
      [3, "B5", 1],
    ],
    [
      [0, "C6", 2],
      [2, "A5", 2],
    ],
    [
      [0, "D6", 1.5],
      [1.5, "C6", 0.5],
      [2, "A5", 2],
    ],
    [
      [0, "G#5", 2],
      [2, "B5", 2],
    ],
    [
      [0, "A5", 2],
      [2, "C6", 1],
      [3, "E6", 1],
    ],
    [
      [0, "D6", 2],
      [2, "C6", 2],
    ],
    [
      [0, "E6", 2],
      [2, "D6", 1],
      [3, "C6", 1],
    ],
    [
      [0, "B5", 2],
      [2, "D6", 2],
    ],
    [
      [0, "F6", 2],
      [2, "E6", 1],
      [3, "D6", 1],
    ],
    [
      [0, "C6", 2],
      [2, "A5", 2],
    ],
    [
      [0, "B5", 2],
      [2, "G#5", 2],
    ],
    [[0, "E5", 4]],
  ]);
  function artGen(b, hi) {
    const ch = CH[ART_PROG[b]],
      ev = [];
    for (const beat of hi ? [0, 1, 2, 3] : [0, 2]) {
      ev.push([beat, ch.b, hi ? 1 : 2, 0.78]);
      ev.push([beat, ch.b + 12, hi ? 1 : 2, 0.6]);
    }
    const pat = [0, 1, 2, 3, 4, 3, 2, 1],
      steps = hi ? 16 : 8,
      sp = hi ? 0.25 : 0.5;
    for (let k = 0; k < steps; k++)
      ev.push([k * sp, ch.ra[pat[k % 8]], sp, 0.3 + (k % 4 === 0 ? 0.06 : 0)]);
    for (const m of MEL_A[b]) {
      ev.push([m[0], m[1], m[2], 0.8]);
      if (hi) ev.push([m[0], m[1] - 12, m[2], 0.5]);
    }
    return ev;
  }

  /* Victory: a warm D major resolution */
  const VICT_PROG = ["D", "A", "Bm", "G", "D", "A", "G", "D"];
  const MEL_V = melBars([
    [
      [0, "F#5", 2],
      [2, "A5", 2],
    ],
    [
      [0, "E5", 2],
      [2, "C#5", 2],
    ],
    [
      [0, "D5", 2],
      [2, "F#5", 2],
    ],
    [
      [0, "B4", 2],
      [2, "D5", 2],
    ],
    [
      [0, "A5", 2],
      [2, "F#5", 2],
    ],
    [
      [0, "E5", 2],
      [2, "A5", 2],
    ],
    [
      [0, "B5", 2],
      [2, "G5", 1],
      [3, "D5", 1],
    ],
    [[0, "D5", 4]],
  ]);
  function victGen(b) {
    const ch = CH[VICT_PROG[b]],
      ev = [],
      pat = [0, 2, 3, 4, 3, 2, 1, 2];
    ev.push([0, ch.b, 4, 0.5]);
    for (let k = 0; k < 8; k++)
      ev.push([k * 0.5, ch.a[pat[k]], 0.5, k === 0 ? 0.3 : 0.22]);
    for (const m of MEL_V[b]) {
      ev.push([m[0], m[1], m[2], 0.6]);
      ev.push([m[0], m[1] - 12, m[2], 0.3]);
    }
    return ev;
  }

  const TRACKS = {
    title: { bpm: 56, beats: 4, bars: 24, pedal: 3.6, gen: titleGen },
    battleSent: {
      bpm: 88,
      beats: 4,
      bars: 16,
      pedal: 1.1,
      intenseTempo: 1.1,
      gen: sentGen,
    },
    battleArt: {
      bpm: 74,
      beats: 4,
      bars: 16,
      pedal: 1.3,
      intenseTempo: 1.12,
      gen: artGen,
    },
    victory: { bpm: 58, beats: 4, bars: 8, pedal: 3.4, gen: victGen },
  };

  /* --- sequencer --- */
  const Music = { cur: null, timer: null, intense: false };
  function scheduleNote(a, dest, tr, e, when, beat) {
    const durS = e[2] * beat,
      vel = clamp(e[3] * (1 + (Math.random() - 0.5) * 0.14), 0.05, 1);
    pianoNote(
      a,
      dest,
      e[1],
      when + (Math.random() - 0.5) * 0.02,
      durS,
      vel,
      tr.pedal,
    );
  }
  function musicTick() {
    const a = AC,
      c = Music.cur;
    if (!a || !c) return;
    while (c.next < a.currentTime + 1.4) {
      const tr = c.track,
        bpm = tr.bpm * (Music.intense && tr.intenseTempo ? tr.intenseTempo : 1),
        beat = 60 / bpm;
      for (const e of tr.gen(c.bar % tr.bars, Music.intense))
        scheduleNote(a, c.gain, tr, e, c.next + e[0] * beat, beat);
      c.next += tr.beats * beat;
      c.bar++;
    }
  }
  function musicPlay(name) {
    const a = ac();
    if (!a || !MG) return;
    if (Music.cur && Music.cur.name === name) return;
    musicStop(1.2);
    const tr = TRACKS[name];
    if (!tr) return;
    const gain = a.createGain();
    gain.gain.setValueAtTime(0.0001, a.currentTime);
    gain.gain.linearRampToValueAtTime(1, a.currentTime + 1.2);
    gain.connect(MG.bus);
    gain.connect(MG.send);
    Music.cur = { name, track: tr, gain, bar: 0, next: a.currentTime + 0.3 };
    Music.intense = false;
    if (!Music.timer) Music.timer = setInterval(musicTick, 100);
    musicTick();
  }
  function musicStop(fade) {
    const a = AC,
      c = Music.cur;
    Music.cur = null;
    if (!a || !c) return;
    const t = a.currentTime;
    c.gain.gain.cancelScheduledValues(t);
    c.gain.gain.setValueAtTime(Math.max(0.0001, c.gain.gain.value), t);
    c.gain.gain.linearRampToValueAtTime(0.0001, t + fade);
    setTimeout(
      () => {
        try {
          c.gain.disconnect();
        } catch (e) {}
      },
      (fade + 0.4) * 1000,
    );
  }
  function musicIntensify() {
    Music.intense = true;
  }
  // dev/test helper: render a track offline (used only when window.__TEST__ is set)
  async function renderTrackOffline(name, secs, intense) {
    const sr = 44100,
      oa = new OfflineAudioContext(2, Math.floor(sr * secs), sr),
      g = buildMusicGraph(oa),
      tr = TRACKS[name];
    const tg = oa.createGain();
    tg.connect(g.bus);
    tg.connect(g.send);
    const bpm = tr.bpm * (intense && tr.intenseTempo ? tr.intenseTempo : 1),
      beat = 60 / bpm;
    let t = 0,
      bar = 0;
    while (t < secs) {
      for (const e of tr.gen(bar % tr.bars, !!intense)) {
        const when = t + e[0] * beat;
        if (when < secs) scheduleNote(oa, tg, tr, e, when, beat);
      }
      t += tr.beats * beat;
      bar++;
    }
    return oa.startRendering();
  }

  /* ================= SETTINGS: key bindings, volume, pause ================= */
  const ACTIONS = [
    ["left", "Move left"],
    ["right", "Move right"],
    ["jump", "Jump"],
    ["down", "Down (plunge)"],
    ["attack", "Attack"],
    ["parry", "Parry"],
    ["block", "Block (hold)"],
    ["dodge", "Dodge / air dodge"],
    ["heal", "Healing flask"],
    ["skill1", "Sunray Slash (skill)"],
    ["skill2", "Cinder Bomb (skill)"],
  ];
  const DEFAULT_BINDS = {
    left: ["KeyA", "ArrowLeft", ""],
    right: ["KeyD", "ArrowRight", ""],
    jump: ["KeyW", "Space", "ArrowUp"],
    down: ["KeyS", "ArrowDown", ""],
    attack: ["KeyJ", "Mouse0", "KeyZ"],
    parry: ["KeyK", "Mouse2", "KeyX"],
    block: ["KeyB", "KeyI", ""],
    dodge: ["KeyL", "ShiftLeft", "KeyC"],
    heal: ["KeyQ", "KeyH", ""],
    skill1: ["KeyR", "", ""],
    skill2: ["KeyE", "", ""],
  };
  const DEFAULT_BINDS2 = {
    left: ["ArrowLeft", "", ""],
    right: ["ArrowRight", "", ""],
    jump: ["ArrowUp", "", ""],
    down: ["ArrowDown", "", ""],
    attack: ["Numpad1", "", ""],
    parry: ["Numpad2", "", ""],
    block: ["Numpad0", "", ""],
    dodge: ["Numpad3", "", ""],
    heal: ["Numpad4", "", ""],
    skill1: ["Numpad5", "", ""],
    skill2: ["Numpad6", "", ""],
  };
  const PAD_OPTIONS = [
    ["axis0-", "Left stick left"],
    ["axis0+", "Left stick right"],
    ["axis1-", "Left stick up"],
    ["axis1+", "Left stick down"],
    ["b0", "A / Cross"],
    ["b1", "B / Circle"],
    ["b2", "X / Square"],
    ["b3", "Y / Triangle"],
    ["b4", "LB / L1"],
    ["b5", "RB / R1"],
    ["b6", "LT / L2"],
    ["b7", "RT / R2"],
    ["b8", "View / Share"],
    ["b9", "Menu / Options"],
    ["b10", "Left stick press"],
    ["b11", "Right stick press"],
    ["b12", "D-pad up"],
    ["b13", "D-pad down"],
    ["b14", "D-pad left"],
    ["b15", "D-pad right"],
  ];
  const DEFAULT_PAD_MAP = {
    left: "axis0-",
    right: "axis0+",
    jump: "b0",
    down: "axis1+",
    attack: "b2",
    parry: "b3",
    block: "b6",
    dodge: "b1",
    heal: "b4",
    skill1: "b5",
    skill2: "b7",
  };
  const RESERVED = [
    "Escape",
    "Enter",
    "KeyF",
    "KeyM",
    "Digit1",
    "Digit2",
    "Digit3",
    "Digit4",
  ];
  let binds = {},
    binds2 = {},
    codeMap = {},
    codeMap2 = {},
    bindPlayer = 1,
    padMaps = [{ ...DEFAULT_PAD_MAP }, { ...DEFAULT_PAD_MAP }],
    padPrev = [{}, {}],
    padHeld = [{ left: 0, right: 0, down: 0, block: 0 }, { left: 0, right: 0, down: 0, block: 0 }],
    capturing = null,
    settingsFrom = "title",
    settingsOpen = false,
    paused = false,
    consoleOpen = false,
    consoleCapture = false,
    consoleWasPaused = false;
  function rebuildMap() {
    codeMap = {};
    for (const a in binds) for (const c of binds[a]) if (c) codeMap[c] = a;
    codeMap2 = {};
    for (const a in binds2)
      for (const c of binds2[a]) if (c) codeMap2[c] = a;
  }
  function resetBinds() {
    binds = {};
    for (const a in DEFAULT_BINDS) binds[a] = DEFAULT_BINDS[a].slice();
    binds2 = {};
    for (const a in DEFAULT_BINDS2) binds2[a] = DEFAULT_BINDS2[a].slice();
    padMaps = [{ ...DEFAULT_PAD_MAP }, { ...DEFAULT_PAD_MAP }];
    rebuildMap();
  }
  function normCode(c) {
    return (c || "").replace(/(Shift|Control|Alt|Meta)Right$/, "$1Left");
  }
  function keyLabel(c) {
    if (!c) return "-";
    if (/^Mouse\d$/.test(c))
      return (
        ["Left click", "Middle click", "Right click"][+c[5]] || "Mouse " + c[5]
      );
    if (/^Key[A-Z]$/.test(c)) return c[3];
    if (/^Digit\d$/.test(c)) return c[5];
    if (/^Numpad/.test(c)) return "Num " + c.slice(6);
    const map = {
      ArrowLeft: "Left",
      ArrowRight: "Right",
      ArrowUp: "Up",
      ArrowDown: "Down",
      Space: "Space",
      ShiftLeft: "Shift",
      ControlLeft: "Ctrl",
      AltLeft: "Alt",
      MetaLeft: "Meta",
      Tab: "Tab",
      CapsLock: "Caps",
      Backquote: "`",
      Minus: "-",
      Equal: "=",
      BracketLeft: "[",
      BracketRight: "]",
      Semicolon: ";",
      Quote: "'",
      Comma: ",",
      Period: ".",
      Slash: "/",
      Backslash: "\\",
    };
    return map[c] || c;
  }
  function labelOf(a) {
    const r = ACTIONS.find((x) => x[0] === a);
    return r ? r[1] : a;
  }
  function keysOf(a, player = 1) {
    const source = player === 2 ? binds2 : binds;
    return source[a].filter((x) => x).map(keyLabel);
  }
  function primaryKey(a) {
    const k = keysOf(a);
    return k.length ? k[0] : "unbound";
  }
  function primaryKey2(a) {
    const k = keysOf(a, 2);
    return k.length ? k[0] : "unbound";
  }
  function twoKeys(a) {
    const k = keysOf(a).slice(0, 2);
    return k.length ? k.join(" / ") : "unbound";
  }
  function loadSettings() {
    resetBinds();
    try {
      const b = JSON.parse(localStorage.getItem("gilded_binds_v1") || "null");
      if (b)
        for (const a in DEFAULT_BINDS)
          if (Array.isArray(b[a]))
            binds[a] = [0, 1, 2].map((i) =>
              typeof b[a][i] === "string" ? b[a][i] : "",
            );
      const b2 = JSON.parse(localStorage.getItem("gilded_binds_p2_v1") || "null");
      if (b2)
        for (const a in DEFAULT_BINDS2)
          if (Array.isArray(b2[a]))
            binds2[a] = [0, 1, 2].map((i) =>
              typeof b2[a][i] === "string" ? b2[a][i] : "",
            );
      const pm = JSON.parse(localStorage.getItem("gilded_pad_maps_v1") || "null");
      if (Array.isArray(pm))
        for (let p = 0; p < 2; p++)
          if (pm[p] && typeof pm[p] === "object")
            for (const a of Object.keys(DEFAULT_PAD_MAP))
              if (typeof pm[p][a] === "string") padMaps[p][a] = pm[p][a];
      const c = JSON.parse(localStorage.getItem("gilded_audio_v1") || "null");
      if (c) {
        audioCfg.music = clamp(+c.music, 0, 1);
        audioCfg.sfx = clamp(+c.sfx, 0, 1);
      }
    } catch (e) {}
    if (!(audioCfg.music >= 0)) audioCfg.music = 0.8;
    if (!(audioCfg.sfx >= 0)) audioCfg.sfx = 0.9;
    rebuildMap();
  }
  function saveSettings() {
    try {
      localStorage.setItem("gilded_binds_v1", JSON.stringify(binds));
      localStorage.setItem("gilded_binds_p2_v1", JSON.stringify(binds2));
      localStorage.setItem("gilded_pad_maps_v1", JSON.stringify(padMaps));
      localStorage.setItem("gilded_audio_v1", JSON.stringify(audioCfg));
    } catch (e) {}
    saveProfile();
  }
  function setMsg(t) {
    $("bindMsg").textContent = t;
  }
  function setConsoleBindLabel() {
    if ($("consoleBind"))
      $("consoleBind").textContent = consoleCapture
        ? "press a key..."
        : keyLabel(profile.consoleKey);
  }
  function toggleConsole(force) {
    const next = force === undefined ? !consoleOpen : !!force;
    if (next === consoleOpen) return;
    consoleOpen = next;
    if (next) {
      consoleWasPaused = paused;
      if (isPlaying()) paused = true;
      clearInputState();
      $("devConsole").classList.remove("hide");
      $("consoleInput").value = "";
      $("consoleInput").focus();
    } else {
      $("devConsole").classList.add("hide");
      if (isPlaying() && !consoleWasPaused) paused = false;
    }
  }
  function runConsoleCommand(raw) {
    const command = (raw || "").trim().toLowerCase();
    if (command === "allrelic" || command === "allrelics") {
      for (const relic of RELICS)
        profile.inventory[relic.id] = Math.max(
          3,
          profile.inventory[relic.id] || 0,
        );
      saveProfile();
      renderLoadout();
      updateCoinLabels();
      $("consoleOutput").textContent =
        "Granted every relic (3 copies each).";
    } else if (command === "moneyall") {
      profile.coins = 99999;
      saveProfile();
      updateCoinLabels();
      $("consoleOutput").textContent = "Coins set to 99,999.";
    } else if (command === "help") {
      $("consoleOutput").textContent =
        "allrelic — grant every relic\\nmoneyall — set coins to 99,999";
    } else if (command) {
      $("consoleOutput").textContent =
        'Unknown command: "' + command + '". Type help.';
    }
  }
  function renderTitleKeys() {
    const T = $("titleKeys");
    if (!T) return;
    T.innerHTML = "";
    const shared = [
      [
        "Move",
        keysOf("left")
          .slice(0, 1)
          .concat(keysOf("right").slice(0, 1))
          .join(" / ") || "unbound",
      ],
      ["Jump", twoKeys("jump")],
      ["Block (hold)", twoKeys("block") + ", takes 25% less damage"],
      ["Dodge slide", twoKeys("dodge")],
      ["Air dodge", "Jump, then " + primaryKey("dodge")],
      ["Healing flask", twoKeys("heal")],
    ];
    const rows =
      heroType === "killnux"
        ? [
            ["Move", shared[0][1]],
            ["Jump", shared[1][1]],
            ["Colossal sword", twoKeys("attack") + ", 200 damage, 30 stamina"],
            ["Super dodge", twoKeys("dodge") + ", 50% farther, 20 stamina"],
            ["Abyss Quake", primaryKey("skill1") + ", ground slam + black wave, 400 damage, 30s cooldown"],
            ["Black Armour", primaryKey("skill2") + ", +50% attack and +20% defense for 20s, 60s cooldown"],
            shared[2], shared[4], shared[5],
          ]
        : heroType === "shadow"
        ? [
            ["Move", shared[0][1]],
            ["Jump", shared[1][1]],
            [
              "Shoot",
              twoKeys("attack") +
                ", 20 stamina per arrow, usable in the air too",
            ],
            [
              "Umbral Dash",
              twoKeys("parry") + ", teleport, 50 stamina, only Shadow has this",
            ],
            shared[2],
            shared[3],
            shared[4],
            shared[5],
            [
              "Piercing Dive",
              primaryKey("skill1") +
                ", dash 100 dmg + 20 arrows for 400 dmg, 30s cooldown",
            ],
            [
              "Arrow Rain",
              primaryKey("skill2") +
                ", 15-20 falling arrows, 60 dmg each, 45s cooldown",
            ],
          ]
        : heroType === "ronin"
          ? [
              ["Move", shared[0][1]],
              ["Jump", shared[1][1]],
              [
                "Twin-katana attack",
                twoKeys("attack") + ", 100 damage, 20 stamina",
              ],
              [
                "Deflect",
                twoKeys("parry") +
                  ", forgiving timing; 15 deflects stagger and deal 600",
              ],
              ["Teleport dodge", twoKeys("dodge") + ", 20 stamina"],
              shared[4],
              shared[5],
              [
                "Scarlet Lunge",
                primaryKey("skill1") + ", 300 damage, 30s cooldown",
              ],
              [
                "Bloodflame",
                primaryKey("skill2") +
                  ", +50 attack damage for 20s, 60s cooldown",
              ],
            ]
          : heroType === "regal"
            ? [
                ["Move", shared[0][1]],
                ["Jump", shared[1][1]],
                ["Regal sword", twoKeys("attack") + ", 90 damage, 20 stamina"],
                ["Pistol shot", twoKeys("parry") + ", 70 damage, 20 stamina"],
                shared[2],
                shared[3],
                shared[4],
                shared[5],
                [
                  "Black Starfall",
                  primaryKey("skill1") +
                    ", 8 falling orbs × 80 damage, 30s cooldown",
                ],
                [
                  "Abyss Cannon",
                  primaryKey("skill2") +
                    ", fast black hand-beam, 800 damage, 80s cooldown",
                ],
              ]
            : heroType === "wizard"
              ? [
                  ["Move", shared[0][1]],
                  ["Jump", shared[1][1]],
                  [
                    "Arcane Missile",
                    twoKeys("attack") + ", 100 damage, 20 stamina",
                  ],
                  [
                    "Conjured Sword",
                    twoKeys("parry") + ", 70 damage, 10 stamina",
                  ],
                  ["Blue teleport dodge", twoKeys("dodge") + ", 20 stamina"],
                  shared[4],
                  shared[5],
                  [
                    "Graveguard Trio",
                    primaryKey("skill1") +
                      ", summon 3 skeletons (300 HP), 40s cooldown",
                  ],
                  [
                    "Astral Comet",
                    primaryKey("skill2") +
                      ", charged beam, 1000 damage, 99s cooldown",
                  ],
                ]
              : [
                  ["Move", shared[0][1]],
                  ["Jump", shared[1][1]],
                  ["Attack", twoKeys("attack")],
                  ["Parry", twoKeys("parry")],
                  shared[2],
                  shared[3],
                  shared[4],
                  [
                    "Plunge strike",
                    primaryKey("down") +
                      " + " +
                      primaryKey("attack") +
                      " in the air",
                  ],
                  shared[5],
                  [
                    "Sunray Slash",
                    primaryKey("skill1") + ", 300 dmg, 30s cooldown",
                  ],
                  [
                    "Cinder Bomb",
                    primaryKey("skill2") + ", 800 dmg up close, 80s cooldown",
                  ],
                ];
    for (const r of rows) {
      const b = document.createElement("b");
      b.textContent = r[0];
      const s = document.createElement("span");
      s.textContent = r[1];
      T.appendChild(b);
      T.appendChild(s);
    }
  }
  function renderKeyTable() {
    const T = $("keyTable");
    T.innerHTML = "";
    const source = bindPlayer === 2 ? binds2 : binds;
    for (const [a, label] of ACTIONS) {
      const row = document.createElement("div");
      row.className = "krow";
      const l = document.createElement("span");
      l.className = "kl";
      l.textContent = label;
      row.appendChild(l);
      for (let s = 0; s < 3; s++) {
        const on = capturing && capturing.a === a && capturing.s === s;
        const b = document.createElement("button");
        b.className = "slot" + (on ? " cap" : "");
        b.textContent = on ? "press a key..." : keyLabel(source[a][s]);
        b.setAttribute("aria-label", label + " key " + (s + 1));
        b.addEventListener("click", () => startCapture(a, s));
        row.appendChild(b);
      }
      T.appendChild(row);
    }
  }
  function renderPadTable() {
    const T = $("padTable");
    if (!T) return;
    T.innerHTML = "";
    const map = padMaps[bindPlayer - 1];
    for (const [action, label] of ACTIONS) {
      const row = document.createElement("label");
      row.className = "pad-row";
      const span = document.createElement("span");
      span.textContent = label;
      const select = document.createElement("select");
      for (const [value, name] of PAD_OPTIONS) {
        const option = document.createElement("option");
        option.value = value;
        option.textContent = name;
        select.appendChild(option);
      }
      select.value = map[action] || DEFAULT_PAD_MAP[action];
      select.addEventListener("change", () => {
        map[action] = select.value;
        saveSettings();
      });
      row.append(span, select);
      T.appendChild(row);
    }
  }
  function gamepadValue(gp, binding) {
    if (!gp || !binding) return 0;
    if (binding.startsWith("b")) {
      const b = gp.buttons[+binding.slice(1)];
      return b && (b.pressed || b.value > 0.55) ? 1 : 0;
    }
    const m = /^axis(\d+)([+-])$/.exec(binding);
    if (!m) return 0;
    const v = gp.axes[+m[1]] || 0;
    return m[2] === "+" ? (v > 0.35 ? 1 : 0) : v < -0.35 ? 1 : 0;
  }
  function pollGamepads() {
    const pads = navigator.getGamepads
      ? Array.from(navigator.getGamepads()).filter(Boolean)
      : [];
    if ($("gamepadStatus"))
      $("gamepadStatus").textContent = pads.length
        ? pads
            .slice(0, 2)
            .map((p, i) => "P" + (i + 1) + ": " + p.id.replace(/\s*\([^)]*\)\s*/g, "").slice(0, 28))
            .join(" · ")
        : "No controller detected";
    for (let player = 0; player < 2; player++) {
      const gp = pads[player],
        map = padMaps[player],
        targetBuf = player === 0 ? buf : buf2;
      for (const [action] of ACTIONS) {
        const now = !!gamepadValue(gp, map[action]),
          was = !!padPrev[player][action];
        if (HELD_KEYS.includes(action)) padHeld[player][action] = now ? 1 : 0;
        else if (now && !was) targetBuf[action] = BUF;
        padPrev[player][action] = now;
      }
    }
  }
  function startCapture(a, s) {
    capturing = { a, s, player: bindPlayer };
    renderKeyTable();
    $("capPad").classList.remove("hide");
    setMsg(
      'Now press the new key for "' +
        labelOf(a) +
        '". Esc cancels. Backspace clears this box.',
    );
  }
  function endCapture(msg) {
    capturing = null;
    $("capPad").classList.add("hide");
    renderKeyTable();
    renderTitleKeys();
    saveSettings();
    if (msg) setMsg(msg);
  }
  function assignKey(code) {
    const { a, s, player } = capturing,
      target = player === 2 ? binds2 : binds,
      other = player === 2 ? binds : binds2;
    let moved = "";
    for (const x in target)
      for (let i = 0; i < 3; i++)
        if (target[x][i] === code && !(x === a && i === s)) {
          target[x][i] = "";
          if (x !== a) moved = x;
        }
    for (const x in other)
      for (let i = 0; i < 3; i++)
        if (other[x][i] === code) other[x][i] = "";
    target[a][s] = code;
    rebuildMap();
    const empty = ACTIONS.filter((r) => !target[r[0]].some((x) => x)).map(
      (r) => r[1],
    );
    let msg =
      keyLabel(code) +
      ' is now set for Player ' +
      player +
      ' "' +
      labelOf(a) +
      '".';
    if (moved)
      msg =
        keyLabel(code) +
        ' moved from "' +
        labelOf(moved) +
        '" to "' +
        labelOf(a) +
        '".';
    if (empty.length)
      msg += " Warning, no key set for: " + empty.join(", ") + ".";
    endCapture(msg);
  }
  function openSettings(from, player = 1) {
    settingsFrom = from;
    settingsOpen = true;
    bindPlayer = player;
    capturing = null;
    if ($("bindPlayer")) $("bindPlayer").value = String(bindPlayer);
    renderKeyTable();
    renderPadTable();
    setConsoleBindLabel();
    $("capPad").classList.add("hide");
    setMsg(
      "Editing Player " +
        bindPlayer +
        ". Click a key box, then press the new key. Each action can have up to three keys.",
    );
    $("volMusic").value = Math.round(audioCfg.music * 100);
    $("volSfx").value = Math.round(audioCfg.sfx * 100);
    $("resolutionScale").value = String(profile.resolution);
    $("graphicsMode").value = profile.graphics;
    if (from === "pause") $("pause").classList.add("hide");
    $("settings").classList.remove("hide");
  }
  function closeSettings() {
    settingsOpen = false;
    capturing = null;
    saveSettings();
    $("settings").classList.add("hide");
    if (settingsFrom === "pause") $("pause").classList.remove("hide");
  }
  function clearInputState() {
    held.left = held.right = held.down = held.block = 0;
    for (const k in buf) buf[k] = 0;
    held2.left = held2.right = held2.down = held2.block = 0;
    for (const k in buf2) buf2[k] = 0;
    for (const p of padHeld)
      p.left = p.right = p.down = p.block = 0;
  }
  function openPause() {
    if (paused) return;
    paused = true;
    clearInputState();
    $("pause").classList.remove("hide");
  }
  function closePause() {
    paused = false;
    $("pause").classList.add("hide");
  }
  const isPlaying = () =>
    phase === "intro" ||
    phase === "fight" ||
    phase === "won" ||
    phase === "lost";

  /* ================= INPUT ================= */
  let held = { left: 0, right: 0, down: 0, block: 0 };
  const held2 = { left: 0, right: 0, down: 0, block: 0 };
  const HELD_KEYS = ["left", "right", "down", "block"];
  let buf = {
    attack: 0,
    parry: 0,
    dodge: 0,
    jump: 0,
    heal: 0,
    skill1: 0,
    skill2: 0,
  };
  const buf2 = {
    attack: 0,
    parry: 0,
    dodge: 0,
    jump: 0,
    heal: 0,
    skill1: 0,
    skill2: 0,
  };
  const BUF = 0.17;
  function toggleFS() {
    const el = document.documentElement;
    if (!document.fullscreenElement) {
      if (el.requestFullscreen) el.requestFullscreen().catch(() => {});
    } else if (document.exitFullscreen) document.exitFullscreen();
  }
  function press(a) {
    if (HELD_KEYS.includes(a)) held[a] = 1;
    else buf[a] = BUF;
  }
  function pressP2(a) {
    if (HELD_KEYS.includes(a)) held2[a] = 1;
    else buf2[a] = BUF;
  }
  function release(a) {
    if (HELD_KEYS.includes(a)) held[a] = 0;
  }
  function releaseP2(a) {
    if (HELD_KEYS.includes(a)) held2[a] = 0;
  }
  function isActionHeld(action) {
    return !!held[action] || !!padHeld[activePlayerIndex][action];
  }
  // While a key box is waiting for a key, this runs first and swallows the event.
  addEventListener(
    "keydown",
    (e) => {
      if (!capturing && !consoleCapture) return;
      e.preventDefault();
      e.stopPropagation();
      const code = normCode(e.code);
      if (consoleCapture) {
        if (code === "Escape") {
          consoleCapture = false;
          setConsoleBindLabel();
          setMsg("Console key change cancelled.");
          return;
        }
        if (code === "Enter") return;
        profile.consoleKey = code;
        consoleCapture = false;
        setConsoleBindLabel();
        saveProfile();
        setMsg("Command console is now bound to " + keyLabel(code) + ".");
        return;
      }
      if (code === "Escape") {
        endCapture("Cancelled.");
        return;
      }
      if (code === "Backspace" || code === "Delete") {
        const source = capturing.player === 2 ? binds2 : binds;
        source[capturing.a][capturing.s] = "";
        rebuildMap();
        endCapture("Cleared.");
        return;
      }
      if (RESERVED.includes(code)) {
        setMsg(
          keyLabel(code) +
            " is reserved for menus (Esc, Enter, F, M, 1, 2). Pick another key.",
        );
        return;
      }
      assignKey(code);
    },
    true,
  );
  addEventListener("keydown", (e) => {
    if (capturing || consoleCapture) return;
    const code = normCode(e.code);
    if (consoleOpen) {
      if (code === "Escape" || code === profile.consoleKey) {
        e.preventDefault();
        toggleConsole(false);
      }
      return;
    }
    if (!settingsOpen && code === profile.consoleKey) {
      e.preventDefault();
      toggleConsole(true);
      return;
    }
    if (code === "Escape") {
      e.preventDefault();
      if (settingsOpen) closeSettings();
      else if (paused) closePause();
      else if (
        phase === "title" &&
        (!$("bossSelect").classList.contains("hide") ||
          !$("loadout").classList.contains("hide") ||
          !$("shop").classList.contains("hide"))
      )
        showFrontScreen("title");
      else if (isPlaying()) openPause();
      return;
    }
    if (code === "KeyM") {
      $("mute").click();
      return;
    }
    if (settingsOpen) return;
    if (code === "KeyF") {
      e.preventDefault();
      toggleFS();
      return;
    }
    const onButton =
      document.activeElement && document.activeElement.tagName === "BUTTON";
    if (
      phase === "title" &&
      !$("bossSelect").classList.contains("hide") &&
      (code === "Digit1" ||
        code === "Digit2" ||
        code === "Digit3" ||
        code === "Digit5")
    ) {
      e.preventDefault();
      startGame(
        code === "Digit1"
          ? "sentinel"
          : code === "Digit2"
            ? "art"
            : code === "Digit3"
              ? "shogun"
              : "demon",
      );
      return;
    }
    if (
      phase === "title" &&
      !$("loadout").classList.contains("hide") &&
      (code === "Digit3" || code === "Digit4" || code === "Digit6")
    ) {
      e.preventDefault();
      pickHero(
        code === "Digit3" ? "knight" : code === "Digit4" ? "shadow" : "ronin",
      );
      renderLoadout();
      return;
    }
    if (
      code === "Enter" &&
      phase === "title" &&
      !$("title").classList.contains("hide") &&
      !onButton
    ) {
      e.preventDefault();
      showFrontScreen("bossSelect");
      return;
    }
    if (code === "KeyR" && (phase === "lostUI" || phase === "wonUI")) {
      e.preventDefault();
      startGame();
      return;
    }
    if (paused) return;
    if (gameMode !== "solo" && codeMap2[code]) {
      e.preventDefault();
      if (!e.repeat) {
        ac();
        pressP2(codeMap2[code]);
      }
      return;
    }
    const a = codeMap[code];
    if (!a) return;
    e.preventDefault();
    if (e.repeat) return;
    ac();
    press(a);
  });
  addEventListener("keyup", (e) => {
    const code = normCode(e.code);
    if (gameMode !== "solo" && codeMap2[code]) {
      e.preventDefault();
      releaseP2(codeMap2[code]);
      return;
    }
    const a = codeMap[code];
    if (a) {
      e.preventDefault();
      release(a);
    }
  });
  addEventListener("blur", () => {
    held.left = held.right = held.down = held.block = 0;
    held2.left = held2.right = held2.down = held2.block = 0;
    for (const p of padHeld)
      p.left = p.right = p.down = p.block = 0;
    if (phase === "intro" || phase === "fight") openPause();
  });
  cv.addEventListener("mousedown", (e) => {
    ac();
    e.preventDefault();
    if (paused || settingsOpen) return;
    const a = codeMap["Mouse" + e.button];
    if (a) press(a);
  });
  addEventListener("mouseup", (e) => {
    const a = codeMap["Mouse" + e.button];
    if (a) release(a);
  });
  stage.addEventListener("contextmenu", (e) => e.preventDefault());
  $("capPad").addEventListener("mousedown", (e) => {
    if (!capturing) return;
    e.preventDefault();
    assignKey("Mouse" + e.button);
  });
  document.addEventListener(
    "click",
    (e) => {
      const b = e.target.closest && e.target.closest("button");
      if (e.detail > 0 && b) b.blur();
    },
    true,
  );
  document.addEventListener("pointerover", (e) => {
    const b = e.target.closest && e.target.closest("button");
    if (!b || b.disabled || b.contains(e.relatedTarget)) return;
    tone(330, 0.035, "sine", 0.018, 90);
  });
  document.addEventListener("pointerdown", (e) => {
    const b = e.target.closest && e.target.closest("button");
    if (!b || b.disabled) return;
    const r = b.getBoundingClientRect(),
      q = document.createElement("span");
    q.className = "ui-ripple";
    q.style.left = e.clientX - r.left + "px";
    q.style.top = e.clientY - r.top + "px";
    b.appendChild(q);
    setTimeout(() => q.remove(), 520);
    tone(190, 0.055, "triangle", 0.035, 150);
  });
  document.addEventListener("click", (e) => {
    const b = e.target.closest && e.target.closest("button");
    if (b && !b.disabled) tone(520, 0.07, "sine", 0.04, 160);
  });
  document.querySelectorAll(".tb").forEach((b) => {
    const a = b.dataset.a;
    b.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      ac();
      b.setPointerCapture(e.pointerId);
      b.classList.add("on");
      press(a);
    });
    const up = (e) => {
      e.preventDefault();
      b.classList.remove("on");
      release(a);
    };
    b.addEventListener("pointerup", up);
    b.addEventListener("pointercancel", up);
    b.addEventListener("lostpointercapture", up);
  });
  if (matchMedia("(pointer:coarse)").matches || "ontouchstart" in window)
    $("touch").classList.remove("hide");
  // settings + pause buttons
  $("openSettings").addEventListener("click", () => openSettings("title"));
  $("consoleBind").addEventListener("click", () => {
    consoleCapture = true;
    setConsoleBindLabel();
    setMsg("Press the key that should open the command console. Esc cancels.");
  });
  $("consoleInput").addEventListener("keydown", (e) => {
    if (e.code === "Enter") {
      e.preventDefault();
      runConsoleCommand(e.currentTarget.value);
      e.currentTarget.value = "";
    }
  });
  $("editP1Controls").addEventListener("click", () =>
    openSettings("multiplayer", 1),
  );
  $("editP2Controls").addEventListener("click", () =>
    openSettings("multiplayer", 2),
  );
  $("bindPlayer").addEventListener("change", (e) => {
    bindPlayer = +e.target.value === 2 ? 2 : 1;
    capturing = null;
    $("capPad").classList.add("hide");
    renderKeyTable();
    renderPadTable();
    setMsg("Editing Player " + bindPlayer + " controls.");
  });
  $("closeSettings").addEventListener("click", closeSettings);
  $("resetBinds").addEventListener("click", () => {
    resetBinds();
    capturing = null;
    $("capPad").classList.add("hide");
    renderKeyTable();
    renderPadTable();
    renderTitleKeys();
    saveSettings();
    setMsg("Controls reset to the defaults.");
  });
  $("volMusic").addEventListener("input", (e) => {
    audioCfg.music = clamp(+e.target.value / 100, 0, 1);
    applyVolumes();
  });
  $("volSfx").addEventListener("input", (e) => {
    audioCfg.sfx = clamp(+e.target.value / 100, 0, 1);
    applyVolumes();
  });
  $("volMusic").addEventListener("change", saveSettings);
  $("volSfx").addEventListener("change", saveSettings);
  $("resolutionScale").addEventListener("change", (e) => {
    profile.resolution = e.target.value;
    applyVideoSettings();
    saveProfile();
    buildBG();
    tone(620, 0.08, "sine", 0.045, 120);
    toast(
      "Resolution applied: " + e.target.options[e.target.selectedIndex].text,
    );
  });
  $("graphicsMode").addEventListener("change", (e) => {
    profile.graphics = e.target.value;
    applyVideoSettings();
    buildBG();
    saveProfile();
    toast(
      profile.graphics === "low"
        ? "Low: 50% render scale, minimal particles and no fog."
        : profile.graphics === "medium"
          ? "Medium: 75% render scale and reduced effects."
          : "High: full selected resolution and full effects.",
    );
  });
  $("pauseBtn").addEventListener("click", () => {
    if (isPlaying()) (paused ? closePause : openPause)();
  });
  $("resumeBtn").addEventListener("click", closePause);
  $("pauseSettings").addEventListener("click", () => openSettings("pause"));
  $("quitBtn").addEventListener("click", () => {
    closePause();
    toTitle();
  });
  loadSettings();
  renderTitleKeys();
  relabelTouch();
  // the browser only allows sound after a click or key press, so start the title music then
  function firstGesture() {
    ac();
    setTimeout(() => {
      if (phase === "title") musicPlay("title");
    }, 260);
  }
  addEventListener("pointerdown", firstGesture, { once: true, capture: true });
  addEventListener("keydown", firstGesture, { once: true, capture: true });

  /* ================= SHADOW (second hero): ranger with a bow ================= */
  const HERO_STATS = {
    knight: { hp: 500, st: 140, flasks: 7 },
    shadow: { hp: 400, st: 200, flasks: 6 },
    ronin: { hp: 500, st: 300, flasks: 6 },
    regal: { hp: 450, st: 250, flasks: 6 },
    wizard: { hp: 300, st: 200, flasks: 6 },
    killnux: { hp: 600, st: 300, flasks: 6 },
  };
  const arrows = [],
    rain = [],
    regalShots = [],
    regalMeteors = [],
    regalBeams = [],
    wizardMissiles = [],
    skeletons = [],
    killWaves = [];
  const SHADOW_SKILL1_CD = 30,
    SHADOW_SKILL2_CD = 45,
    RONIN_SKILL1_CD = 30,
    RONIN_SKILL2_CD = 60,
    REGAL_SKILL1_CD = 30,
    REGAL_SKILL2_CD = 80,
    WIZARD_SKILL1_CD = 40,
    WIZARD_SKILL2_CD = 99,
    KILLNUX_SKILL1_CD = 30,
    KILLNUX_SKILL2_CD = 60;
  function skill1MaxCD() {
    return heroType === "shadow"
      ? SHADOW_SKILL1_CD
      : heroType === "ronin"
        ? RONIN_SKILL1_CD
        : heroType === "regal"
          ? REGAL_SKILL1_CD
          : heroType === "wizard"
            ? WIZARD_SKILL1_CD
            : heroType === "killnux"
              ? KILLNUX_SKILL1_CD
              : SKILL1_CD;
  }
  function skill2MaxCD() {
    return heroType === "shadow"
      ? SHADOW_SKILL2_CD
      : heroType === "ronin"
        ? RONIN_SKILL2_CD
        : heroType === "regal"
          ? REGAL_SKILL2_CD
          : heroType === "wizard"
            ? WIZARD_SKILL2_CD
            : heroType === "killnux"
              ? KILLNUX_SKILL2_CD
              : SKILL2_CD;
  }
  const PAL_SH = {
    dark: "#0d0c12",
    mid: "#232230",
    light: "#3c3a49",
    trim: "#5a5566",
    fur: "#5a5148",
    furLight: "#8a7d6e",
    leg: "#1c1b24",
    legFar: "#100f16",
    cloak: "#17151e",
    cloakDark: "#0a090e",
    strap: "#4a3a2a",
    glow: "#7ff0e6",
    glowCore: "#e8fffb",
    glowDark: "#0f6f6c",
    outline: "#020103",
  };

  function fireBasicArrow() {
    sfx("shot");
    const pb = GROUND - P.y;
    arrows.push({
      owner: activePlayerIndex,
      x: P.x + P.face * 30,
      y: P.y - 80,
      vx: P.face * 1500,
      life: 1.1,
      t: 0,
      hit: false,
      pb,
      dmg: 60,
      kind: "basic",
    });
    spark(P.x + P.face * 26, P.y - 80, 8, "#bdf3f0", 300, 0.28);
  }
  function startShot(dir) {
    P.state = "shot";
    P.t = 0;
    P.shotFired = false;
    if (dir) P.face = dir;
    P.vx *= 0.5;
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.5;
  }
  function startTeleport(dir) {
    P.state = "teleport";
    P.t = 0;
    P.rt = "wind";
    P.teleDir = dir || P.face;
    if (dir) P.face = dir;
    P.st = Math.max(0, P.st - 50);
    P.stDelay = 0.6;
    P.invuln = Math.max(P.invuln, 0.3);
    buf.parry = 0;
    P.vx = 0;
    P.vy = 0;
    spark(P.x, P.y - 55, 10, "#5a3aa8", 260, 0.3);
  }
  function startRoninDodge(dir) {
    P.state = "teleport";
    P.t = 0;
    P.rt = "wind";
    P.teleDir = dir || P.face;
    if (dir) P.face = dir;
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.5;
    P.invuln = Math.max(P.invuln, 0.34);
    buf.dodge = 0;
    P.vx = 0;
    P.vy = 0;
    const wizardDodge = heroType === "wizard";
    spark(P.x, P.y - 55, 18, wizardDodge ? "#258cff" : "#ff244c", 340, 0.38, 0);
    addRing(
      P.x,
      P.y - 58,
      6,
      62,
      0.3,
      wizardDodge ? "rgba(35,145,255,.85)" : "rgba(255,35,75,.8)",
      4,
    );
  }
  function startRoninSkill1() {
    P.state = "roninLunge";
    P.t = 0;
    P.skill1CD = RONIN_SKILL1_CD;
    buf.skill1 = 0;
    P.face = B.x >= P.x ? 1 : -1;
    P.roninStartX = P.x;
    P.roninTargetX = clamp(B.x - P.face * 72, 50, WORLD - 50);
    P.roninHit = false;
    P.invuln = Math.max(P.invuln, 0.28);
    sfx("skill1");
  }
  function startRoninSkill2() {
    P.state = "roninFlame";
    P.t = 0;
    P.skill2CD = RONIN_SKILL2_CD;
    buf.skill2 = 0;
    P.vx = 0;
    sfx("charge");
  }
  function startRegalSword(dir) {
    P.state = "regalSword";
    P.t = 0;
    P.regalHit = false;
    P.regalFx = false;
    if (dir) P.face = dir;
    P.vx *= 0.35;
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.65;
    buf.attack = 0;
  }
  function startRegalGun(dir) {
    P.state = "regalGun";
    P.t = 0;
    P.shotFired = false;
    if (dir) P.face = dir;
    P.vx *= 0.45;
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.55;
    buf.parry = 0;
  }
  function fireRegalShot() {
    sfx("shot");
    const pb = GROUND - P.y;
    regalShots.push({
      owner: activePlayerIndex,
      x: P.x + P.face * 36,
      y: P.y - 78,
      vx: P.face * 1450,
      t: 0,
      life: 1.15,
      hit: false,
      pb,
      dmg: 70,
    });
    spark(P.x + P.face * 38, P.y - 78, 16, "#ffd56b", 430, 0.32, 0);
    addRing(P.x + P.face * 38, P.y - 78, 3, 28, 0.16, "rgba(255,205,95,.9)", 3);
  }
  function startRegalSkill1() {
    P.state = "regalOrb";
    P.t = 0;
    P.skill1CD = REGAL_SKILL1_CD;
    P.regalOrbFired = false;
    buf.skill1 = 0;
    P.vx = 0;
    P.face = B.x >= P.x ? 1 : -1;
    sfx("charge");
  }
  function castRegalOrb() {
    const tx = clamp(B.x, 100, WORLD - 100),
      ty = 112;
    regalMeteors.push({
      owner: activePlayerIndex,
      kind: "carrier",
      x: P.x + P.face * 30,
      y: P.y - 88,
      sx: P.x + P.face * 30,
      sy: P.y - 88,
      tx,
      ty,
      t: 0,
      life: 0.46,
      burst: false,
    });
    spark(P.x + P.face * 30, P.y - 88, 28, "#8d61ff", 500, 0.5, 0);
  }
  function burstRegalOrb(o) {
    sfx("boom");
    doShake(12);
    doFlash(0.28, "80,25,130");
    addRing(o.x, o.y, 16, 150, 0.55, "rgba(120,75,220,.9)", 9);
    for (let i = 0; i < 8; i++)
      regalMeteors.push({
        owner: activePlayerIndex,
        kind: "drop",
        x: o.x + (i - 3.5) * 34 + rnd(-10, 10),
        y: o.y + rnd(-18, 18),
        vy: 460 + rnd(0, 90),
        t: 0,
        life: 1.2,
        hit: false,
        dmg: 80,
      });
    addText(o.x, o.y - 25, "BLACK STARFALL", "#c7a7ff", 20, 1);
  }
  function startRegalSkill2() {
    P.state = "regalBeam";
    P.t = 0;
    P.skill2CD = REGAL_SKILL2_CD;
    P.regalBeamFired = false;
    buf.skill2 = 0;
    P.vx = 0;
    P.face = B.x >= P.x ? 1 : -1;
    sfx("charge");
  }
  function fireRegalBeam() {
    sfx("beam");
    doShake(16);
    doFlash(0.35, "55,15,90");
    regalBeams.push({
      owner: activePlayerIndex,
      x: P.x + P.face * 36,
      y: P.y - 72,
      vx: P.face * 980,
      face: P.face,
      t: 0,
      life: 1.35,
      hit: false,
      dmg: 800,
    });
    addRing(
      P.x + P.face * 34,
      P.y - 72,
      8,
      70,
      0.32,
      "rgba(180,110,255,.9)",
      7,
    );
  }
  function updateRegalProjectiles(dt) {
    for (let i = regalShots.length - 1; i >= 0; i--) {
      const a = regalShots[i];
      a.t += dt;
      a.x += a.vx * dt;
      let dead = a.t > a.life || a.x < 0 || a.x > WORLD;
      if (
        !a.hit &&
        B.state !== "dead" &&
        B.state !== "intro" &&
        Math.abs(a.x - B.x) < B.hw + 18 &&
        a.pb + 125 > B.h &&
        a.pb - 20 < B.h + B.hh
      ) {
        a.hit = true;
        dead = true;
        hitBoss(a.dmg, 0.05, true, false);
        spark(a.x, a.y, 14, "#ffd56b", 420, 0.34);
        addRing(a.x, a.y, 4, 42, 0.22, "rgba(255,210,100,.9)", 3);
      }
      if (dead) regalShots.splice(i, 1);
    }
    for (let i = regalMeteors.length - 1; i >= 0; i--) {
      const o = regalMeteors[i];
      o.t += dt;
      if (o.kind === "carrier") {
        const k = clamp(o.t / o.life, 0, 1);
        o.x = lerp(o.sx, o.tx, easeOut(k));
        o.y = lerp(o.sy, o.ty, ease(k));
        if (Math.random() < 0.8)
          parts.push({
            k: "dot",
            x: o.x + rnd(-8, 8),
            y: o.y + rnd(-8, 8),
            vx: 0,
            vy: 0,
            life: 0.22,
            t: 0,
            col: "115,70,190",
            g: 0,
            drag: 1,
            sz: rnd(3, 7),
          });
        if (k >= 1) {
          burstRegalOrb(o);
          regalMeteors.splice(i, 1);
        }
      } else {
        o.y += o.vy * dt;
        o.vy += 620 * dt;
        if (Math.random() < 0.7)
          parts.push({
            k: "dot",
            x: o.x,
            y: o.y - 12,
            vx: 0,
            vy: 0,
            life: 0.18,
            t: 0,
            col: "115,65,190",
            g: 0,
            drag: 1,
            sz: rnd(3, 6),
          });
        let dead = o.t > o.life;
        if (
          !o.hit &&
          B.state !== "dead" &&
          B.state !== "intro" &&
          Math.abs(o.x - B.x) < B.hw + 34 &&
          o.y >= GROUND - B.h - 10
        ) {
          o.hit = true;
          dead = true;
          hitBoss(o.dmg, 0.04, true, true);
          spark(o.x, o.y, 18, "#a173ff", 480, 0.38);
          addRing(o.x, o.y, 5, 55, 0.25, "rgba(145,90,240,.9)", 5);
        }
        if (!dead && o.y >= GROUND) {
          dead = true;
          spark(o.x, GROUND, 10, "#68429b", 320, 0.3);
          dust(o.x, GROUND, 3);
        }
        if (dead) regalMeteors.splice(i, 1);
      }
    }
    for (let i = regalBeams.length - 1; i >= 0; i--) {
      const q = regalBeams[i];
      q.t += dt;
      q.x += q.vx * dt;
      let dead = q.t > q.life || q.x < 0 || q.x > WORLD;
      if (
        !q.hit &&
        B.state !== "dead" &&
        B.state !== "intro" &&
        Math.abs(q.x - B.x) < B.hw + 85 &&
        q.y > GROUND - B.h - B.hh - 55 &&
        q.y < GROUND - B.h + 55
      ) {
        q.hit = true;
        dead = true;
        hitBoss(q.dmg, 0.16, true, true);
        spark(q.x, q.y, 36, "#b37aff", 700, 0.5);
        addRing(q.x, q.y, 12, 115, 0.4, "rgba(160,90,255,.95)", 10);
        doShake(20);
      }
      if (dead) regalBeams.splice(i, 1);
    }
  }
  function drawRegalProjectiles() {
    for (const a of regalShots) {
      ctx.save();
      ctx.translate(a.x, a.y);
      ctx.scale(Math.sign(a.vx), 1);
      ctx.shadowColor = "#ffd56b";
      ctx.shadowBlur = 12;
      ctx.fillStyle = "#fff1aa";
      ctx.fillRect(-18, -2, 36, 4);
      ctx.fillStyle = "#d59a35";
      ctx.beginPath();
      ctx.moveTo(20, 0);
      ctx.lineTo(10, -6);
      ctx.lineTo(10, 6);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    for (const o of regalMeteors) {
      ctx.save();
      ctx.translate(o.x, o.y);
      const r = o.kind === "carrier" ? 24 : 13;
      const g = ctx.createRadialGradient(-r * 0.25, -r * 0.3, 2, 0, 0, r);
      g.addColorStop(0, "#f4ddff");
      g.addColorStop(0.25, "#8c4fda");
      g.addColorStop(0.65, "#26123f");
      g.addColorStop(1, "rgba(0,0,0,.05)");
      ctx.fillStyle = g;
      ctx.shadowColor = "#8d58d8";
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "#d7adff";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    }
    for (const q of regalBeams) {
      ctx.save();
      ctx.translate(q.x, q.y);
      ctx.scale(q.face, 1);
      const pulse = 1 + Math.sin(time * 45) * 0.08;
      const g = ctx.createLinearGradient(-95, 0, 95, 0);
      g.addColorStop(0, "rgba(10,2,18,.15)");
      g.addColorStop(0.35, "#1a062a");
      g.addColorStop(0.7, "#6d2aa5");
      g.addColorStop(1, "rgba(210,160,255,.15)");
      ctx.fillStyle = g;
      ctx.shadowColor = "#7028ad";
      ctx.shadowBlur = 24;
      ctx.beginPath();
      ctx.ellipse(0, 0, 100, 25 * pulse, 0, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "rgba(245,225,255,.85)";
      ctx.beginPath();
      ctx.ellipse(18, 0, 78, 6 * pulse, 0, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }

  /* ================= ARCANE WIZARD ================= */
  function startWizardMissile(dir) {
    P.state = "wizardMissile";
    P.t = 0;
    P.shotFired = false;
    if (dir) P.face = dir;
    P.vx *= 0.35;
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.55;
    buf.attack = 0;
    sfx("charge");
  }
  function fireWizardMissile() {
    wizardMissiles.push({
      owner: activePlayerIndex,
      x: P.x + P.face * 36,
      y: P.y - 76,
      vx: P.face * 1080,
      t: 0,
      life: 1.65,
      hit: false,
      dmg: 100,
      trail: [],
    });
    spark(P.x + P.face * 35, P.y - 76, 24, "#63c9ff", 420, 0.42, 0);
    addRing(
      P.x + P.face * 34,
      P.y - 76,
      4,
      38,
      0.24,
      "rgba(105,210,255,.9)",
      3,
    );
    sfx("shot");
  }
  function startWizardSword(dir) {
    P.state = "wizardSword";
    P.t = 0;
    P.wizardHit = false;
    P.wizardFx = false;
    if (dir) P.face = dir;
    P.vx *= 0.3;
    P.st = Math.max(0, P.st - 10);
    P.stDelay = 0.45;
    buf.parry = 0;
    sfx("charge");
  }
  function startWizardSummon() {
    P.state = "wizardSummon";
    P.t = 0;
    P.vx = 0;
    P.skill1CD = WIZARD_SKILL1_CD;
    P.skill1Fired = false;
    P.invuln = Math.max(P.invuln, 0.72);
    buf.skill1 = 0;
    sfx("charge");
  }
  function summonSkeletons() {
    skeletons.length = 0;
    const face = B.x >= P.x ? 1 : -1;
    for (let i = 0; i < 3; i++) {
      const x = clamp(P.x + face * (82 + i * 76), 45, WORLD - 45);
      skeletons.push({
        x,
        rank: i,
        hp: 300,
        maxhp: 300,
        face,
        state: "spawn",
        t: 0,
        attackT: 0,
        stride: i * 1.8,
        flash: 0,
        alpha: 0,
      });
      addRing(x, GROUND - 4, 8, 48, 0.55, "rgba(85,190,255,.85)", 4);
      spark(x, GROUND - 45, 18, "#78d6ff", 260, 0.65, -60);
    }
    sfx("skill1");
  }
  function startWizardBeam() {
    P.state = "wizardBeam";
    P.t = 0;
    P.vx = 0;
    P.skill2CD = WIZARD_SKILL2_CD;
    P.skill2Fired = false;
    P.skill2Hit = false;
    P.invuln = Math.max(P.invuln, 1.75);
    P.face = B.x >= P.x ? 1 : -1;
    buf.skill2 = 0;
    sfx("charge");
  }
  function updateWizardSystems(dt) {
    for (let i = wizardMissiles.length - 1; i >= 0; i--) {
      const m = wizardMissiles[i],
        target = projectileTarget(m);
      m.t += dt;
      m.life -= dt;
      m.trail.push({ x: m.x, y: m.y, a: 1 });
      if (m.trail.length > 10) m.trail.shift();
      for (const q of m.trail) q.a *= 0.8;
      const targetY =
        gameMode === "pvp"
          ? target.y - 72
          : GROUND - (target.type === "demon" ? 118 : 92);
      m.y += (targetY - m.y) * Math.min(1, dt * 3.5);
      m.x += m.vx * dt;
      if (
        !m.hit &&
        target.state !== "dead" &&
        Math.abs(m.x - target.x) < target.hw + 28 &&
        Math.abs(m.y - targetY) < target.hh * 0.7
      ) {
        m.hit = true;
        hitProjectileTarget(m, m.dmg, 0.07, true, false);
        spark(m.x, m.y, 30, "#80ddff", 520, 0.48, 0);
        addRing(m.x, m.y, 5, 58, 0.28, "rgba(110,220,255,.95)", 5);
        doShake(5);
        sfx("hit");
      }
      if (m.hit || m.life <= 0 || m.x < 0 || m.x > WORLD)
        wizardMissiles.splice(i, 1);
    }
    for (let i = skeletons.length - 1; i >= 0; i--) {
      const s = skeletons[i];
      s.t += dt;
      s.flash = Math.max(0, s.flash - dt);
      if (s.hp <= 0) {
        s.state = "dead";
        s.alpha -= dt * 1.5;
        if (s.alpha <= 0) skeletons.splice(i, 1);
        continue;
      }
      if (s.state === "spawn") {
        s.alpha = Math.min(1, s.alpha + dt * 2.6);
        if (s.t > 0.72) {
          s.state = "walk";
          s.t = 0;
        }
        continue;
      }
      if (phase !== "fight" || B.state === "dead") continue;
      s.face = B.x >= s.x ? 1 : -1;
      const d = Math.abs(B.x - s.x);
      const desired = B.hw + 58 + (s.rank || 0) * 46;
      if (s.state === "attack") {
        if (s.t >= 0.28 && s.t - dt < 0.28 && d < desired + 24) {
          hitBoss(50, 0.025, false, false);
          addArc(
            s.x + s.face * 8,
            GROUND - 63,
            54,
            -1.9,
            0.8,
            s.face,
            0.16,
            "rgba(170,225,255,.85)",
            5,
          );
          sfx("hit");
        }
        if (s.t > 0.7) {
          s.state = "walk";
          s.t = 0;
          s.attackT = 0.42;
        }
      } else {
        s.attackT = Math.max(0, s.attackT - dt);
        if (d > desired) {
          s.x += s.face * 118 * dt;
          s.stride += dt * 8;
        } else if (s.attackT <= 0) {
          s.state = "attack";
          s.t = 0;
        }
      }
      if (
        (s.state === "walk" || s.state === "attack") &&
        Math.random() < dt * 5
      )
        parts.push({
          k: "dot",
          x: s.x + rnd(-12, 12),
          y: GROUND - rnd(22, 92),
          vx: rnd(-16, 16),
          vy: rnd(-45, -16),
          life: rnd(0.25, 0.5),
          t: 0,
          col: "90,205,255",
          g: -10,
          drag: 1,
          sz: rnd(1.5, 3),
        });
    }
  }
  function damageSkeleton(s, dmg) {
    if (!s || s.hp <= 0) return false;
    s.hp = Math.max(0, s.hp - dmg);
    s.flash = 0.18;
    spark(s.x, GROUND - 58, 14, "#dff4ff", 280, 0.4, 300);
    addText(s.x, GROUND - 116, "-" + Math.round(dmg), "#bdeaff", 13, 0.55);
    if (s.hp <= 0) {
      s.state = "dead";
      s.alpha = 1;
      sfx("hurt");
    }
    return true;
  }
  function drawWizardSystems() {
    for (const m of wizardMissiles) {
      ctx.save();
      const dir = Math.sign(m.vx) || 1;
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < m.trail.length; i++) {
        const q = m.trail[i];
        const k = (i + 1) / m.trail.length;
        ctx.globalAlpha = k * 0.42;
        ctx.fillStyle = i % 2 ? "#4b8dff" : "#79ddff";
        ctx.beginPath();
        ctx.ellipse(q.x, q.y, 3 + i * 0.45, 1.5 + i * 0.2, 0, 0, TAU);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
      ctx.translate(m.x, m.y);
      ctx.scale(dir, 1);
      ctx.rotate(Math.sin(m.t * 18) * 0.045);
      // spinning glyph halo makes the projectile read as sorcery, not a bullet
      ctx.strokeStyle = "rgba(140,225,255,.82)";
      ctx.lineWidth = 1.6;
      ctx.save();
      ctx.rotate(m.t * 11);
      ctx.beginPath();
      ctx.ellipse(-8, 0, 13, 22, 0, 0, TAU);
      ctx.stroke();
      for (let r = 0; r < 4; r++) {
        const a = (r * TAU) / 4;
        ctx.beginPath();
        ctx.moveTo(-8 + Math.cos(a) * 13, Math.sin(a) * 22);
        ctx.lineTo(-8 + Math.cos(a + 0.45) * 17, Math.sin(a + 0.45) * 26);
        ctx.stroke();
      }
      ctx.restore();
      ctx.shadowColor = "#62d5ff";
      ctx.shadowBlur = 22;
      const g = ctx.createLinearGradient(-20, 0, 28, 0);
      g.addColorStop(0, "#ffffff");
      g.addColorStop(0.35, "#a9eeff");
      g.addColorStop(0.75, "#438fff");
      g.addColorStop(1, "#4937d8");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(30, 0);
      ctx.quadraticCurveTo(5, -12, -22, -6);
      ctx.quadraticCurveTo(-10, 0, -22, 6);
      ctx.quadraticCurveTo(5, 12, 30, 0);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#e7fcff";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(-16, 0);
      ctx.lineTo(27, 0);
      ctx.stroke();
      ctx.restore();
    }
    for (const s of skeletons) {
      if (s.state === "spawn") {
        const k = clamp(s.t / 0.72, 0, 1);
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        ctx.translate(s.x, GROUND - 2);
        ctx.scale(1, 0.32);
        ctx.rotate(time * 0.35);
        ctx.strokeStyle = "rgba(75,195,255," + (0.35 + 0.55 * (1 - k)) + ")";
        ctx.shadowColor = "#4ecbff";
        ctx.shadowBlur = 15;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(0, 0, 43, 0, TAU);
        ctx.stroke();
        ctx.beginPath();
        for (let i = 0; i < 10; i++) {
          const a = (i * TAU) / 10;
          const r = i % 2 ? 22 : 36;
          const x = Math.cos(a) * r,
            y = Math.sin(a) * r;
          if (!i) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.stroke();
        ctx.restore();
      }
      drawSkeletonMinion(ctx, s);
    }
    if (heroType === "wizard" && P.state === "wizardBeam") {
      const charge = clamp(P.t / 1.0, 0, 1);
      const handX = P.x + P.face * 48,
        handY = P.y - 67;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      ctx.strokeStyle = "rgba(105,215,255," + (0.22 + charge * 0.5) + ")";
      ctx.lineWidth = 1.5 + charge * 1.5;
      for (let i = 0; i < 8; i++) {
        const a = time * (2.1 + i * 0.12) + (i * TAU) / 8;
        ctx.beginPath();
        ctx.arc(handX, handY, 14 + charge * (28 + i * 2), a, a + 0.85);
        ctx.stroke();
      }
      // large ritual seal behind the casting hand
      ctx.save();
      ctx.translate(handX, handY);
      ctx.rotate(time * 0.45);
      ctx.strokeStyle = "rgba(120,225,255," + charge * 0.72 + ")";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, 34 * charge, 0, TAU);
      ctx.stroke();
      for (let i = 0; i < 8; i++) {
        const a = (i * TAU) / 8;
        ctx.beginPath();
        ctx.moveTo(Math.cos(a) * 20 * charge, Math.sin(a) * 20 * charge);
        ctx.lineTo(Math.cos(a) * 34 * charge, Math.sin(a) * 34 * charge);
        ctx.stroke();
      }
      ctx.restore();
      if (P.t >= 1.0 && P.t <= 1.58) {
        const len = Math.abs(B.x - handX) + 130;
        const x0 = P.face > 0 ? handX : handX - len;
        const grad = ctx.createLinearGradient(
          handX,
          0,
          handX + P.face * len,
          0,
        );
        grad.addColorStop(0, "rgba(235,255,255,.98)");
        grad.addColorStop(0.22, "rgba(120,230,255,.96)");
        grad.addColorStop(0.62, "rgba(66,130,255,.82)");
        grad.addColorStop(0.88, "rgba(92,65,235,.55)");
        grad.addColorStop(1, "rgba(90,45,220,0)");
        ctx.shadowColor = "#5ed8ff";
        ctx.shadowBlur = 38;
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(x0, handY - 14);
        ctx.lineTo(x0 + len, handY - 42);
        ctx.lineTo(x0 + len, handY + 42);
        ctx.lineTo(x0, handY + 14);
        ctx.closePath();
        ctx.fill();
        const core = ctx.createLinearGradient(
          handX,
          0,
          handX + P.face * len,
          0,
        );
        core.addColorStop(0, "rgba(255,255,255,.98)");
        core.addColorStop(0.38, "rgba(205,250,255,.9)");
        core.addColorStop(0.82, "rgba(115,210,255,.68)");
        core.addColorStop(1, "rgba(100,120,255,0)");
        ctx.fillStyle = core;
        ctx.beginPath();
        ctx.moveTo(x0, handY - 3);
        ctx.lineTo(x0 + len, handY - 8);
        ctx.lineTo(x0 + len, handY + 8);
        ctx.lineTo(x0, handY + 3);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(160,238,255,.75)";
        ctx.lineWidth = 3;
        for (let i = 0; i < 3; i++) {
          const yy = handY + Math.sin(time * 18 + i * 2.1) * (16 + i * 7);
          ctx.beginPath();
          ctx.moveTo(x0, yy);
          ctx.lineTo(x0 + len, yy + Math.sin(time * 9 + i) * 8);
          ctx.stroke();
        }
      }
      ctx.restore();
    }
  }

  function startRangerSkill1() {
    P.state = "rskill1";
    P.t = 0;
    P.rPhase = "dash";
    P.skill1CD = SHADOW_SKILL1_CD;
    buf.skill1 = 0;
    P.face = B.x >= P.x ? 1 : -1;
    P.rHit100 = false;
    P.rArrows = 0;
    P.rNextArrow = 0;
    P.rDropped = false;
    P.rStartX = P.x;
    P.rTargetX = clamp(B.x - P.face * 70, 60, WORLD - 60);
    P.invuln = Math.max(P.invuln, 0.22);
    B.execMark = 0;
    sfx("dodge");
  }
  function startRangerSkill2() {
    P.state = "rain2";
    P.t = 0;
    P.skill2CD = SHADOW_SKILL2_CD;
    buf.skill2 = 0;
    P.face = B.x >= P.x ? 1 : -1;
    P.rainFired = false;
    P.vx = 0;
  }
  function launchRain() {
    sfx("skill2rain");
    const cx = clamp(
      B.state !== "dead" && B.state !== "intro" ? B.x : P.x + P.face * 400,
      100,
      WORLD - 100,
    );
    const n = 15 + Math.floor(Math.random() * 6),
      total = 1.7;
    for (let i = 0; i < n; i++)
      rain.push({
        owner: activePlayerIndex,
        x: cx + rnd(-90, 90),
        y: -60 - rnd(0, 80),
        vy: 1350,
        delay: (i / n) * total + rnd(0, 0.06),
        t: 0,
        started: false,
        hit: false,
        dmg: 60,
      });
    addText(cx, 90, "ARROW RAIN", "#8ef0ea", 20, 1);
  }
  function updateArrows(dt) {
    for (let i = arrows.length - 1; i >= 0; i--) {
      const a = arrows[i],
        target = projectileTarget(a);
      a.t += dt;
      a.x += a.vx * dt;
      if (Math.random() < 0.7)
        parts.push({
          k: "dot",
          x: a.x - Math.sign(a.vx) * 10,
          y: a.y + rnd(-3, 3),
          vx: -Math.sign(a.vx) * 26,
          vy: rnd(-5, 5),
          life: 0.15,
          t: 0,
          col: "150,235,230",
          g: 0,
          drag: 2,
          sz: rnd(1.6, 3.4),
        });
      let dead = a.t > a.life || a.x < -60 || a.x > WORLD + 60;
      if (!a.hit && target.state !== "dead" && target.state !== "intro") {
        const lo = Math.min(a.x - 14, a.x + 14),
          hi = Math.max(a.x - 14, a.x + 14);
        if (
          target.x + target.hw > lo &&
          target.x - target.hw < hi &&
          a.pb + 125 > target.h &&
          a.pb - 20 < target.h + target.hh
        ) {
          a.hit = true;
          dead = true;
          hitProjectileTarget(a, a.dmg, a.dmg >= 60 ? 0.05 : 0.02, true, a.kind === "barrage");
          spark(a.x, a.y, a.dmg >= 60 ? 12 : 7, "#bdf3f0", 380, 0.32);
          addRing(a.x, a.y, 4, 42, 0.22, "rgba(150,235,230,.85)", 3);
        }
      }
      if (dead) arrows.splice(i, 1);
    }
  }
  function updateRain(dt) {
    for (let i = rain.length - 1; i >= 0; i--) {
      const r = rain[i],
        target = projectileTarget(r);
      r.t += dt;
      if (!r.started) {
        if (r.t >= r.delay) r.started = true;
        else continue;
      }
      r.y += r.vy * dt;
      if (Math.random() < 0.55)
        parts.push({
          k: "dot",
          x: r.x,
          y: r.y - 16,
          vx: 0,
          vy: 0,
          life: 0.14,
          t: 0,
          col: "150,235,230",
          g: 0,
          drag: 1,
          sz: rnd(1.6, 3.2),
        });
      let dead = false;
      if (
        !r.hit &&
        target.state !== "dead" &&
        target.state !== "intro" &&
        Math.abs(r.x - target.x) < target.hw + 70
      ) {
        const landY = GROUND - target.h;
        if (r.y >= landY - 6) {
          r.hit = true;
          dead = true;
          hitProjectileTarget(r, r.dmg, 0.03, true, true);
          spark(r.x, landY, 10, "#bdf3f0", 340, 0.3);
          addRing(r.x, landY, 4, 40, 0.2, "rgba(150,235,230,.8)", 3);
        }
      }
      if (!dead && r.y >= GROUND) {
        dead = true;
        spark(r.x, GROUND, 5, "#6fa8a4", 200, 0.22);
        dust(r.x, GROUND, 2);
      }
      if (dead) rain.splice(i, 1);
    }
  }
  function drawArrowShape(c, x, y, rot, glow) {
    c.save();
    c.translate(x, y);
    c.rotate(rot);
    if (glow) {
      c.shadowColor = "#7ff0e6";
      c.shadowBlur = glow;
    }
    c.strokeStyle = "#caa06a";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-16, 0);
    c.lineTo(8, 0);
    c.stroke();
    c.fillStyle = "#6a5636";
    c.beginPath();
    c.moveTo(-16, 0);
    c.lineTo(-10, -4);
    c.lineTo(-10, 4);
    c.closePath();
    c.fill();
    c.strokeStyle = "#bdf3f0";
    c.lineWidth = 1.4;
    c.shadowBlur = 0;
    const g = c.createLinearGradient(0, 0, 12, 0);
    g.addColorStop(0, "#0f6f6c");
    g.addColorStop(1, "#e8fffb");
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(6, -3.4);
    c.lineTo(13, 0);
    c.lineTo(6, 3.4);
    c.lineTo(8, 0);
    c.closePath();
    c.fill();
    c.restore();
  }
  function drawArrows() {
    for (const a of arrows)
      drawArrowShape(ctx, a.x, a.y, a.vx >= 0 ? 0 : Math.PI, 8);
  }
  function drawRain() {
    for (const r of rain) {
      if (!r.started) continue;
      drawArrowShape(ctx, r.x, r.y, Math.PI / 2, 7);
    }
  }
  function drawExecMark() {
    if (B.execMark == null) return;
    const k = clamp(B.execMark, 0, 1),
      col = `rgb(255,${Math.round(255 - 195 * k)},${Math.round(255 - 205 * k)})`;
    const x = B.x,
      y = GROUND - (B.type === "art" ? 220 : 198) - B.h;
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(Math.sin(time * 9) * 0.07);
    const s = 12 + 2 * Math.sin(time * 13);
    ctx.strokeStyle = col;
    ctx.lineWidth = 4;
    ctx.lineCap = "round";
    ctx.shadowColor = col;
    ctx.shadowBlur = 8 + 10 * k;
    ctx.beginPath();
    ctx.moveTo(-s, -s);
    ctx.lineTo(s, s);
    ctx.moveTo(s, -s);
    ctx.lineTo(-s, s);
    ctx.stroke();
    ctx.restore();
  }
  function drawBow(c, gx, gy, aimA, drawT, glow) {
    c.save();
    c.translate(gx, gy);
    c.rotate(aimA);
    const pull = 3 + drawT * 11;
    if (glow) {
      c.shadowColor = "#7ff0e6";
      c.shadowBlur = glow;
    }
    c.strokeStyle = "rgba(210,250,247,.95)";
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(0, -26);
    c.quadraticCurveTo(pull, 0, 0, 26);
    c.stroke();
    c.shadowBlur = 0;
    const limb = (sign) => {
      c.strokeStyle = PAL_SH.outline;
      c.lineWidth = 6.5;
      c.beginPath();
      c.moveTo(0, 0);
      c.quadraticCurveTo(sign * 14, sign * 13 * 0, sign * 10, sign * 15);
      c.quadraticCurveTo(sign * 4, sign * 22, sign * 13, sign * 27);
      c.stroke();
      const g = c.createLinearGradient(0, 0, 0, sign * 27);
      g.addColorStop(0, PAL_SH.glowDark);
      g.addColorStop(0.6, PAL_SH.glow);
      g.addColorStop(1, PAL_SH.glowCore);
      c.strokeStyle = g;
      c.lineWidth = 3.4;
      c.shadowColor = PAL_SH.glow;
      c.shadowBlur = glow ? glow * 0.8 : 5;
      c.beginPath();
      c.moveTo(0, 0);
      c.quadraticCurveTo(sign * 14, sign * 0, sign * 10, sign * 15);
      c.quadraticCurveTo(sign * 4, sign * 22, sign * 13, sign * 27);
      c.stroke();
      c.shadowBlur = 0;
    };
    limb(-1);
    limb(1);
    c.fillStyle = PAL_SH.mid;
    c.strokeStyle = PAL_SH.outline;
    c.lineWidth = 1;
    c.beginPath();
    c.ellipse(0, 0, 4.4, 7, 0, 0, TAU);
    c.fill();
    c.stroke();
    if (drawT > 0.05) {
      c.strokeStyle = "#caa06a";
      c.lineWidth = 2;
      c.beginPath();
      c.moveTo(pull - 2, 0);
      c.lineTo(pull - 15, 0);
      c.stroke();
      drawArrowShape(c, pull + 4, 0, 0, 6);
    }
    c.restore();
  }
  function drawRanger(c, o) {
    const p = PAL_SH,
      t = o.t,
      run = o.run || 0,
      air = o.air,
      crouch = o.crouch || 0,
      lean = o.lean || 0;
    c.save();
    c.translate(o.x, o.y);
    c.scale(o.face * o.scale, o.scale);
    if (o.rot) c.rotate(o.rot);
    c.globalAlpha = o.alpha === undefined ? 1 : o.alpha;
    if (o.flash) c.filter = "brightness(2.6) saturate(.4)";
    const hipY = -42 + crouch * 0.9;
    let fA, fB;
    if (air) {
      fA = { x: -7, y: -16 };
      fB = { x: 11, y: -26 };
    } else if (o.slide) {
      fA = { x: -19, y: -2 };
      fB = { x: 23, y: -1 };
    } else if (o.kneel) {
      fA = { x: -20, y: -2 };
      fB = { x: 13, y: 0 };
    } else {
      const ph = o.phase !== undefined ? o.phase : t * 9,
        rx = 16 * run;
      fA = {
        x: -9 * (1 - run) + Math.sin(ph) * rx,
        y: -Math.max(0, Math.cos(ph)) * 9 * run,
      };
      fB = {
        x: 9 * (1 - run) + Math.sin(ph + Math.PI) * rx,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 9 * run,
      };
    }
    const drawLeg = (hx, f, far) => {
      const k = ik(hx, hipY, f.x, f.y, 22, 22, -1);
      limb(
        c,
        [
          { x: hx, y: hipY },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        10,
        p.outline,
        far ? p.legFar : p.leg,
        p.light,
      );
      c.fillStyle = p.dark;
      c.strokeStyle = p.outline;
      c.lineWidth = 1;
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 2, 9, 4.6, 0, 0, TAU);
      c.fill();
      c.stroke();
      c.fillStyle = p.strap;
      c.beginPath();
      c.arc(k.x + 1, k.y - 4, 3, 0, TAU);
      c.fill();
    };
    drawLeg(-4, fA, true);
    drawLeg(4, fB, false);

    const sw = Math.sin(t * 1.6) * 2 + run * -8 + (o.clothSway || 0);
    poly(
      c,
      [
        [-9, hipY - 2],
        [10, hipY - 2],
        [15 + sw, hipY + 34],
        [10 + sw, hipY + 28],
        [4 + sw, hipY + 40],
        [-2 + sw, hipY + 30],
        [-8 + sw, hipY + 38],
        [-13 + sw, hipY + 30],
      ],
      p.cloak,
      p.outline,
      1.1,
    );
    c.fillStyle = "rgba(0,0,0,.4)";
    for (let i = 0; i < 4; i++) {
      c.beginPath();
      c.arc(-4 + i * 4, hipY + 6, 1, 0, TAU);
      c.fill();
    }

    c.save();
    c.translate(0, crouch);
    c.translate(0, -42);
    c.rotate(lean);
    c.translate(0, 42);
    const w1 = Math.sin(t * 3) * 3 + run * 8 + (o.capeBack || 0),
      w2 = Math.sin(t * 3 + 1) * 4 + run * 11 + (o.capeBack || 0) * 1.3;
    poly(
      c,
      [
        [-4, -82],
        [-14, -70],
        [-19 - w1, -42],
        [-24 - w2, -6],
        [-19 - w2, 0],
        [-15 - w1, -8],
        [-10 - w2 * 0.7, 1],
        [-6 - w1 * 0.5, -7],
        [-2, -1],
        [1, -42],
      ],
      p.cloakDark,
      p.outline,
      1.2,
    );

    // quiver on the back
    c.save();
    c.translate(-13, -66);
    c.rotate(-0.3);
    c.fillStyle = p.strap;
    c.fillRect(-4, 0, 8, 22);
    c.strokeStyle = p.outline;
    c.lineWidth = 1;
    c.strokeRect(-4, 0, 8, 22);
    for (let i = -1; i <= 1; i++) {
      c.strokeStyle = "#8a8272";
      c.lineWidth = 1.6;
      c.beginPath();
      c.moveTo(i * 2.6, 0);
      c.lineTo(i * 3.6, -13);
      c.stroke();
      c.fillStyle = "#c8c0ae";
      c.beginPath();
      c.moveTo(i * 3.6, -13);
      c.lineTo(i * 3.6 - 2, -9);
      c.lineTo(i * 3.6 + 2, -9);
      c.closePath();
      c.fill();
    }
    c.restore();

    const tg = c.createLinearGradient(-11, 0, 13, 0);
    tg.addColorStop(0, p.dark);
    tg.addColorStop(0.5, p.mid);
    tg.addColorStop(1, p.light);
    c.beginPath();
    c.moveTo(-10, -78);
    c.quadraticCurveTo(1, -87, 11, -78);
    c.quadraticCurveTo(16, -62, 10, -45);
    c.lineTo(-9, -45);
    c.quadraticCurveTo(-14, -62, -10, -78);
    c.closePath();
    c.fillStyle = tg;
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.5;
    c.stroke();
    c.strokeStyle = p.strap;
    c.lineWidth = 2.2;
    c.beginPath();
    c.moveTo(-9, -76);
    c.lineTo(9, -50);
    c.stroke();
    c.strokeStyle = "rgba(0,0,0,.35)";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-8, -68);
    c.quadraticCurveTo(2, -64, 11, -68);
    c.moveTo(-8, -57);
    c.quadraticCurveTo(2, -54, 10, -57);
    c.stroke();
    c.fillStyle = p.dark;
    c.fillRect(-10, -48, 21, 5);
    c.strokeStyle = p.outline;
    c.lineWidth = 1;
    c.strokeRect(-10, -48, 21, 5);
    c.fillStyle = p.strap;
    c.beginPath();
    c.arc(0, -45.5, 2.8, 0, TAU);
    c.fill();

    c.fillStyle = p.dark;
    c.fillRect(-2, -85, 7, 8);
    const hoodGrad = c.createLinearGradient(-10, -110, 12, -80);
    hoodGrad.addColorStop(0, p.light);
    hoodGrad.addColorStop(0.55, p.mid);
    hoodGrad.addColorStop(1, p.dark);
    c.beginPath();
    c.moveTo(-10, -84);
    c.quadraticCurveTo(-13, -104, 0, -112);
    c.quadraticCurveTo(13, -104, 12, -88);
    c.quadraticCurveTo(12, -80, 5, -78);
    c.quadraticCurveTo(-4, -78, -10, -84);
    c.closePath();
    c.fillStyle = hoodGrad;
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.5;
    c.stroke();
    poly(
      c,
      [
        [-9, -86],
        [-11, -98],
        [-2, -108],
        [8, -104],
        [11, -92],
        [4, -86],
        [-2, -90],
      ],
      p.dark,
      null,
    );
    c.fillStyle = "#04070a";
    c.beginPath();
    c.moveTo(-6, -92);
    c.quadraticCurveTo(1, -97, 8, -91);
    c.quadraticCurveTo(9, -83, 1, -80);
    c.quadraticCurveTo(-7, -83, -6, -92);
    c.closePath();
    c.fill();
    const eyeGlow = 6 + Math.sin(time * 3) * 1.5;
    c.fillStyle = p.glowCore;
    c.shadowColor = p.glow;
    c.shadowBlur = eyeGlow;
    c.beginPath();
    c.ellipse(-1.5, -90, 2.6, 1, -0.15, 0, TAU);
    c.fill();
    c.beginPath();
    c.ellipse(4.5, -89.5, 2.6, 1, -0.1, 0, TAU);
    c.fill();
    c.shadowBlur = 0;
    c.strokeStyle = p.trim;
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-10, -96);
    c.quadraticCurveTo(1, -100, 11, -95);
    c.stroke();

    const pr = 11.5,
      pg = c.createRadialGradient(-2, -80, 1, 2, -76, pr + 2);
    pg.addColorStop(0, p.light);
    pg.addColorStop(0.7, p.mid);
    pg.addColorStop(1, p.dark);
    c.fillStyle = pg;
    c.beginPath();
    c.arc(1, -76, pr, 0, TAU);
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.4;
    c.stroke();
    c.fillStyle = p.furLight;
    c.beginPath();
    for (let i = 0; i < 7; i++) {
      const a = -Math.PI * 0.15 + (i / 6) * Math.PI * 1.3;
      c.moveTo(1 + Math.cos(a) * pr, -76 + Math.sin(a) * pr);
      c.arc(1 + Math.cos(a) * pr, -76 + Math.sin(a) * pr, 2.6, 0, TAU);
    }
    c.fill();
    c.strokeStyle = p.trim;
    c.lineWidth = 1;
    c.beginPath();
    c.arc(1, -76, pr - 4, 0.4, 2.6);
    c.stroke();

    if (o.offTarget) {
      const S = { x: 1, y: -76 },
        e = ik(S.x, S.y, o.offTarget.x, o.offTarget.y, 16, 16, -1);
      limb(
        c,
        [S, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
        9,
        p.outline,
        p.mid,
        p.light,
      );
      c.fillStyle = "#1a1720";
      c.strokeStyle = p.furLight;
      c.lineWidth = 2;
      c.beginPath();
      c.arc(e.tx, e.ty, 4.6, 0, TAU);
      c.fill();
      c.stroke();
    }
    if (o.drink > 0) {
      const fx0 = 15,
        fy0 = -90;
      c.save();
      c.translate(fx0, fy0);
      c.rotate(-0.9 * Math.min(1, o.drink));
      c.fillStyle = "#8bf07a";
      c.strokeStyle = p.outline;
      c.lineWidth = 1;
      c.beginPath();
      c.ellipse(0, 4, 5, 6, 0, 0, TAU);
      c.fill();
      c.stroke();
      c.fillStyle = "#d9d0b8";
      c.fillRect(-2, -5, 4, 5);
      c.strokeRect(-2, -5, 4, 5);
      c.fillStyle = "#7a4a22";
      c.fillRect(-2.6, -8, 5.2, 3.4);
      c.restore();
    }

    const S = { x: 2, y: -77 },
      R = 32,
      A = o.aimA;
    const gx = S.x + Math.cos(A) * R,
      gy = S.y + Math.sin(A) * R;
    if (!o.hideBow) drawBow(c, gx, gy, A, 0, o.glow || 0);
    const fel = ik(S.x, S.y, gx, gy, 17, 17, -1);
    limb(
      c,
      [S, { x: fel.x, y: fel.y }, { x: fel.tx, y: fel.ty }],
      9,
      p.outline,
      p.mid,
      p.light,
    );
    c.fillStyle = "#1a1720";
    c.strokeStyle = p.furLight;
    c.lineWidth = 2;
    c.beginPath();
    c.arc(fel.tx, fel.ty, 4.8, 0, TAU);
    c.fill();
    c.stroke();

    if (!o.offTarget) {
      const drawT = o.draw || 0,
        backX = lerp(gx * 0.35, -7, drawT),
        backY = lerp(gy * 0.35 - 74, -92, drawT);
      const S2 = { x: -1, y: -76 },
        e2 = ik(S2.x, S2.y, backX, backY, 16, 16, 1);
      limb(
        c,
        [S2, { x: e2.x, y: e2.y }, { x: e2.tx, y: e2.ty }],
        9,
        p.outline,
        p.mid,
        p.light,
      );
      c.fillStyle = "#1a1720";
      c.strokeStyle = p.furLight;
      c.lineWidth = 2;
      c.beginPath();
      c.arc(e2.tx, e2.ty, 4.6, 0, TAU);
      c.fill();
      c.stroke();
      if (!o.hideBow && drawT > 0.04) {
        c.save();
        c.translate(gx, gy);
        c.rotate(A);
        c.strokeStyle = "#caa06a";
        c.lineWidth = 2;
        c.beginPath();
        c.moveTo(3 + drawT * 11, 0);
        c.lineTo(3 + drawT * 11 - 13, 0);
        c.stroke();
        drawArrowShape(c, 3 + drawT * 11 + 4, 0, 0, 6);
        c.restore();
      }
      if (!o.hideBow) {
        c.save();
        c.translate(gx, gy);
        c.rotate(A);
        const pull = 3 + drawT * 11;
        c.strokeStyle = "rgba(210,250,247,.95)";
        c.lineWidth = 1.4;
        c.beginPath();
        c.moveTo(0, -26);
        c.quadraticCurveTo(pull, 0, 0, 26);
        c.stroke();
        c.restore();
      }
    }
    c.restore();
    c.restore();
  }
  function rangerObj() {
    const air = P.y < GROUND - 3;
    const o = {
      kind: "ranger",
      scale: 1.06,
      x: P.x,
      y: P.y,
      face: P.face,
      t: time,
      run: 0,
      air,
      aimA: -0.12,
      draw: 0,
      crouch: 0,
      lean: 0,
      flash: P.flash > 0,
      alpha: 1,
      glow: 5,
      runSpeed: 9,
      phase: P.stride,
    };
    o.run = P.state === "free" && !air ? Math.min(1, Math.abs(P.vx) / 240) : 0;
    o.aimA = -0.12 + Math.sin(time * 2) * 0.02 - o.run * 0.1;
    o.crouch = P.state === "free" && !air ? 9 * (P.landT / 0.14) : 0;
    o.lean = o.run * 0.08;
    if (
      P.invuln > 0 &&
      P.state !== "dodge" &&
      P.state !== "airdash" &&
      P.state !== "teleport" &&
      Math.floor(time * 30) % 2
    )
      o.alpha = 0.5;
    switch (P.state) {
      case "shot": {
        const k = clamp(P.t / 0.16, 0, 1);
        o.draw =
          k < 0.375 ? ease(k / 0.375) : Math.max(0, 1 - (k - 0.375) / 0.35);
        o.lean = -0.05 * Math.sin(k * Math.PI);
        o.glow = 6 + o.draw * 14;
        o.run = 0;
        break;
      }
      case "teleport": {
        const wind = P.rt === "wind";
        const k = wind ? P.t / 0.07 : P.t / 0.16;
        o.alpha = wind ? 1 - k : k;
        o.aimA = -0.3;
        o.lean = wind ? 0.1 : -0.1;
        o.glow = 18;
        o.run = 0;
        o.hideBow = false;
        break;
      }
      case "rskill1": {
        o.run = 0;
        if (P.rPhase === "dash") {
          o.slide = true;
          o.crouch = 14;
          o.lean = 0.5;
          o.aimA = -0.5;
          o.glow = 16;
        } else if (P.rPhase === "barrage") {
          const saw = (P.t % 0.045) / 0.045;
          o.draw = saw;
          o.lean = -0.03;
          o.aimA = -0.08;
          o.glow = 14;
        } else {
          const k = Math.min(1, P.t / 0.34);
          o.crouch = lerp(20, 6, k);
          o.lean = lerp(0.28, 0, k);
          o.aimA = lerp(-1.1, -0.12, k);
          o.glow = lerp(22, 5, k);
        }
        break;
      }
      case "rain2": {
        const k = clamp(P.t / 0.42, 0, 1);
        o.aimA = lerp(-0.3, -1.55, Math.min(1, k * 2.2));
        o.draw = k < 0.55 ? ease(k / 0.55) : Math.max(0, 1 - (k - 0.55) / 0.3);
        o.lean = -0.1;
        o.glow = 6 + 14 * k;
        o.run = 0;
        break;
      }
      case "dodge":
        o.slide = true;
        o.crouch = 20;
        o.lean = 0.5;
        o.run = 0;
        o.air = false;
        break;
      case "airdash":
        o.air = true;
        o.lean = 0.5;
        o.run = 0;
        break;
      case "block":
        o.crouch = 5;
        o.lean = 0.05;
        o.aimA = -0.02;
        o.glow = 4;
        o.run = Math.min(1, Math.abs(P.vx) / 120) * 0.4;
        break;
      case "hurt":
        o.lean = -0.25;
        o.run = 0;
        break;
      case "heal":
        o.drink = Math.min(1, P.t / 0.5);
        o.crouch = 5;
        o.lean = 0.1;
        o.offTarget = { x: 14, y: -88 };
        o.run = 0;
        break;
      case "dead":
        o.rot = -Math.min(1.5, P.deadT * 3.5);
        o.run = 0;
        o.alpha = clamp(1 - (P.deadT - 1) * 0.8, 0.25, 1);
        break;
      case "free":
        if (air) {
          o.aimA = -0.16;
          o.lean = 0.04;
        }
        break;
    }
    return o;
  }

  /* ================= CRIMSON RONIN (third hero): twin red katana ================= */
  function drawRoninKatana(c, x, y, a, flame, back) {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    c.strokeStyle = "#050307";
    c.lineWidth = 8;
    c.beginPath();
    c.moveTo(-14, 0);
    c.lineTo(4, 0);
    c.stroke();
    c.strokeStyle = "#7c1b2c";
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(-13, 0);
    c.lineTo(5, 0);
    c.stroke();
    c.strokeStyle = "#b88b69";
    c.lineWidth = 4;
    c.beginPath();
    c.moveTo(2, -7);
    c.lineTo(2, 7);
    c.stroke();
    const g = c.createLinearGradient(4, 0, 76, 0);
    g.addColorStop(0, back ? "#7c1025" : "#ff234c");
    g.addColorStop(0.55, "#ef2444");
    g.addColorStop(1, "#ffb0ba");
    c.shadowColor = "#ff234c";
    c.shadowBlur = flame ? 24 : 12;
    c.strokeStyle = g;
    c.lineWidth = back ? 5 : 6;
    c.beginPath();
    c.moveTo(5, 0);
    c.quadraticCurveTo(43, back ? 2 : -2, 76, -5);
    c.stroke();
    c.shadowBlur = 0;
    c.strokeStyle = "#ffd3d8";
    c.globalAlpha *= 0.75;
    c.lineWidth = 1.2;
    c.beginPath();
    c.moveTo(9, -1);
    c.quadraticCurveTo(45, -2, 70, -5);
    c.stroke();
    if (flame) {
      c.globalAlpha *= 0.9;
      c.fillStyle = "#ff3455";
      c.shadowColor = "#ff1d43";
      c.shadowBlur = 18;
      for (let i = 0; i < 6; i++) {
        const q = i / 5,
          xx = 12 + q * 60,
          h = 5 + Math.sin(time * 12 + i * 1.7) * 3;
        c.beginPath();
        c.moveTo(xx - 5, -3);
        c.quadraticCurveTo(xx, -9 - h, xx + 5, -3);
        c.quadraticCurveTo(xx, 1, xx - 5, -3);
        c.fill();
      }
    }
    c.restore();
  }
  function drawRonin(c, o) {
    c.save();
    c.translate(o.x, o.y);
    const roninStep = (o.run || 0) * Math.abs(Math.sin((o.phase || 0) * 0.5)) * 2.8;
    c.translate(0, -roninStep);
    c.scale(o.face * o.scale, o.scale);
    c.rotate((o.lean || 0) * 0.22 + Math.sin(o.phase || 0) * (o.run || 0) * 0.018);
    if (o.rot) c.rotate(o.rot);
    c.globalAlpha = o.alpha;
    if (o.flash) c.filter = "brightness(2.8) saturate(.5)";
    const run = o.run || 0,
      ph = o.phase || 0,
      crouch = o.crouch || 0,
      hip = -40 + crouch;
    // teleport after-image and bloodflame aura
    if (o.tele) {
      c.shadowColor = "#ff244c";
      c.shadowBlur = 24;
    }
    if (o.flame) {
      c.fillStyle = "rgba(255,25,60,.12)";
      c.beginPath();
      c.ellipse(0, -61, 43 + Math.sin(time * 9) * 4, 72, 0, 0, TAU);
      c.fill();
    }
    let f1 = {
        x: -9 + Math.sin(ph) * 16 * run,
        y: -Math.max(0, Math.cos(ph)) * 8 * run,
      },
      f2 = {
        x: 9 + Math.sin(ph + Math.PI) * 16 * run,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 8 * run,
      };
    if (o.slide) {
      f1 = { x: -23, y: -2 };
      f2 = { x: 24, y: -1 };
    }
    if (o.kneel) {
      f1 = { x: -18, y: -1 };
      f2 = { x: 12, y: 0 };
    }
    const leg = (hx, f, far) => {
      const k = ik(hx, hip, f.x, f.y, 22, 22, -1);
      limb(
        c,
        [
          { x: hx, y: hip },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        10,
        "#030205",
        far ? "#111016" : "#1d1b22",
        "#37323b",
      );
      c.fillStyle = "#0a090d";
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 2, 10, 4.5, 0, 0, TAU);
      c.fill();
    };
    leg(-4, f1, true);
    leg(4, f2, false);
    const sway = Math.sin(time * 2.1) * 3 - run * 10;
    poly(
      c,
      [
        [-10, hip - 4],
        [11, hip - 4],
        [18 + sway, hip + 39],
        [9 + sway, hip + 31],
        [3 + sway, hip + 43],
        [-4 + sway, hip + 32],
        [-12 + sway, hip + 40],
        [-17 + sway, hip + 26],
      ],
      "#15131a",
      "#030205",
      1.3,
    );
    c.save();
    c.translate(0, crouch);
    c.rotate(o.lean || 0);
    // torn cloak / layered robe
    poly(
      c,
      [
        [-8, -80],
        [-17, -69],
        [-22 - sway * 0.4, -31],
        [-30 - sway * 0.8, -5],
        [-21 - sway, 0],
        [-15 - sway * 0.4, -11],
        [-8 - sway * 0.8, 2],
        [-1, -42],
      ],
      "#0a090d",
      "#020103",
      1.4,
    );
    poly(
      c,
      [
        [-11, -78],
        [12, -78],
        [15, -44],
        [9, -35],
        [-10, -38],
        [-15, -52],
      ],
      "#1e1a20",
      "#030205",
      1.4,
    );
    c.strokeStyle = "#64202b";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-10, -67);
    c.lineTo(11, -45);
    c.stroke();
    // masked head and scarf
    c.fillStyle = "#050407";
    c.beginPath();
    c.arc(1, -91, 12, 0, TAU);
    c.fill();
    poly(
      c,
      [
        [-11, -96],
        [-4, -106],
        [8, -104],
        [13, -94],
        [8, -82],
        [-7, -83],
      ],
      "#111016",
      "#020103",
      1.2,
    );
    c.fillStyle = "#0a090d";
    c.beginPath();
    c.moveTo(-10, -91);
    c.quadraticCurveTo(1, -96, 11, -91);
    c.lineTo(8, -84);
    c.lineTo(-8, -85);
    c.closePath();
    c.fill();
    c.strokeStyle = "#ff405e";
    c.shadowColor = "#ff244c";
    c.shadowBlur = 8;
    c.lineWidth = 1.8;
    c.beginPath();
    c.moveTo(-5, -92);
    c.lineTo(6, -91);
    c.stroke();
    c.shadowBlur = 0;
    // broad kasa hat
    c.fillStyle = "#21191a";
    c.strokeStyle = "#050305";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-37, -104);
    c.quadraticCurveTo(0, -128, 39, -103);
    c.quadraticCurveTo(1, -94, -37, -104);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#6f2a32";
    c.lineWidth = 1.3;
    c.beginPath();
    c.moveTo(-31, -103);
    c.quadraticCurveTo(0, -119, 33, -102);
    c.moveTo(-19, -106);
    c.quadraticCurveTo(0, -116, 21, -105);
    c.stroke();
    c.fillStyle = "#2d2323";
    c.beginPath();
    c.moveTo(-7, -112);
    c.lineTo(1, -126);
    c.lineTo(10, -111);
    c.closePath();
    c.fill();
    // back katana/scabbard silhouette
    c.save();
    c.translate(-13, -55);
    c.rotate(-2.28);
    c.strokeStyle = "#050305";
    c.lineWidth = 8;
    c.beginPath();
    c.moveTo(-10, 0);
    c.lineTo(64, 0);
    c.stroke();
    c.strokeStyle = "#5e1725";
    c.lineWidth = 3;
    c.stroke();
    c.restore();
    // arms and twin blades
    const pose = o.pose || 0,
      a1 = o.a1 === undefined ? -0.22 : o.a1,
      a2 = o.a2 === undefined ? 0.42 : o.a2;
    const shoulder = { x: 3, y: -71 };
    const h1 = {
      x: shoulder.x + Math.cos(a1) * 29,
      y: shoulder.y + Math.sin(a1) * 29,
    };
    const h2 = { x: -3 + Math.cos(a2) * 27, y: -69 + Math.sin(a2) * 27 };
    let e = ik(shoulder.x, shoulder.y, h1.x, h1.y, 16, 16, -1);
    limb(
      c,
      [shoulder, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
      9,
      "#030205",
      "#201c22",
      "#38323a",
    );
    e = ik(-3, -69, h2.x, h2.y, 16, 16, 1);
    limb(
      c,
      [
        { x: -3, y: -69 },
        { x: e.x, y: e.y },
        { x: e.tx, y: e.ty },
      ],
      9,
      "#030205",
      "#17151b",
      "#302b33",
    );
    drawRoninKatana(c, h2.x, h2.y, a2, o.flame, true);
    drawRoninKatana(c, h1.x, h1.y, a1, o.flame, false);
    c.restore();
    c.restore();
  }
  function roninObj() {
    const air = P.y < GROUND - 3,
      o = {
        kind: "ronin",
        scale: 1.08,
        x: P.x,
        y: P.y,
        face: P.face,
        t: time,
        run: 0,
        air,
        phase: P.stride,
        crouch: 0,
        lean: 0,
        a1: -0.22,
        a2: 0.42,
        flash: P.flash > 0,
        alpha: 1,
        flame: P.flameT > 0,
        tele: false,
      };
    o.run = P.state === "free" && !air ? Math.min(1, Math.abs(P.vx) / 240) : 0;
    o.lean = o.run * 0.08;
    o.crouch = P.state === "free" && !air ? 9 * (P.landT / 0.14) : 0;
    if (P.state === "attack") {
      const A = ATK[P.combo],
        k = clamp(P.t / (A.w + A.a + A.r), 0, 1),
        sw = k < 0.55 ? ease(k / 0.55) : easeOut((k - 0.55) / 0.45);
      if (P.combo === 0) {
        o.a1 = lerp(-2.25, 0.72, sw);
        o.a2 = lerp(1.25, -1.45, sw);
      } else if (P.combo === 1) {
        o.a1 = lerp(2.1, -0.65, sw);
        o.a2 = lerp(-1.2, 1.45, sw);
      } else {
        o.a1 = 0.02;
        o.a2 = 0.1;
        o.lean = 0.34;
      }
      o.run = 0;
    } else if (P.state === "parry") {
      o.a1 = -0.85;
      o.a2 = 0.82;
      o.lean = -0.08;
      o.run = 0;
      if (P.t < RONIN_DEFLECT_WIN && !P.parrySucc) {
        o.flame = true;
      }
    } else if (P.state === "teleport") {
      o.tele = true;
      o.slide = true;
      o.crouch = 15;
      o.lean = 0.55;
      o.a1 = -0.1;
      o.a2 = 0.2;
      o.alpha =
        P.rt === "wind"
          ? Math.max(0.12, 1 - P.t / 0.07)
          : Math.min(1, P.t / 0.16);
      o.run = 0;
    } else if (P.state === "roninLunge") {
      o.slide = true;
      o.crouch = 10;
      o.lean = 0.52;
      o.a1 = 0.02;
      o.a2 = 0.12;
      o.flame = true;
      o.run = 0;
    } else if (P.state === "roninFlame") {
      const k = clamp(P.t / 0.72, 0, 1);
      o.a1 = lerp(-0.2, -1.75, ease(k));
      o.a2 = lerp(0.4, 1.8, ease(k));
      o.flame = true;
      o.run = 0;
    } else if (P.state === "dodge" || P.state === "airdash") {
      o.slide = !air;
      o.lean = 0.5;
      o.run = 0;
    } else if (P.state === "block") {
      o.a1 = -0.65;
      o.a2 = 0.65;
      o.crouch = 4;
      o.run = Math.min(1, Math.abs(P.vx) / 120) * 0.4;
    } else if (P.state === "hurt") {
      o.lean = -0.3;
      o.run = 0;
    } else if (P.state === "heal") {
      o.crouch = 6;
      o.a1 = 1.65;
      o.a2 = 1.3;
      o.run = 0;
    } else if (P.state === "dead") {
      o.rot = -Math.min(1.5, P.deadT * 3.5);
      o.run = 0;
      o.alpha = clamp(1 - (P.deadT - 1) * 0.8, 0.25, 1);
    }
    return o;
  }

  /* ================= METAL REGAL (fourth hero): ornate gunblade duelist ================= */
  const PAL_RG = {
    black: "#08080c",
    dark: "#121119",
    mid: "#241f29",
    red: "#68152a",
    red2: "#a52840",
    gold: "#b89043",
    gold2: "#f0d079",
    steel: "#aaa4a9",
    outline: "#020204",
  };
  /* ================= ARCANE WIZARD — articulated character art ================= */
  function drawArcaneBlade(c, x, y, a, size = 1, alpha = 1) {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    c.scale(size, size);
    c.globalAlpha *= alpha;
    const g = c.createLinearGradient(3, 0, 82, 0);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.25, "#9eeaff");
    g.addColorStop(0.7, "#3e9eff");
    g.addColorStop(1, "rgba(80,70,255,.1)");
    c.shadowColor = "#45c8ff";
    c.shadowBlur = 18;
    c.strokeStyle = g;
    c.lineWidth = 7;
    c.beginPath();
    c.moveTo(4, 0);
    c.quadraticCurveTo(48, -3, 82, -9);
    c.stroke();
    c.shadowBlur = 0;
    c.strokeStyle = "rgba(245,255,255,.95)";
    c.lineWidth = 1.6;
    c.beginPath();
    c.moveTo(8, -2);
    c.quadraticCurveTo(48, -4, 76, -9);
    c.stroke();
    c.strokeStyle = "#79dfff";
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(1, -9);
    c.lineTo(1, 9);
    c.moveTo(-7, 0);
    c.lineTo(8, 0);
    c.stroke();
    c.restore();
  }
  function drawWizardStaff(c, x, y, a, power = 0) {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    const wood = c.createLinearGradient(-4, 0, 6, 0);
    wood.addColorStop(0, "#24182b");
    wood.addColorStop(0.5, "#79573f");
    wood.addColorStop(1, "#2c1c31");
    c.strokeStyle = "#09060d";
    c.lineWidth = 9;
    c.beginPath();
    c.moveTo(0, -102);
    c.quadraticCurveTo(4, 40, 1, 105);
    c.stroke();
    c.strokeStyle = wood;
    c.lineWidth = 5;
    c.beginPath();
    c.moveTo(0, -102);
    c.quadraticCurveTo(4, 40, 1, 105);
    c.stroke();
    c.strokeStyle = "#a07a4d";
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(0, -94);
    c.quadraticCurveTo(-23, -106, -18, -123);
    c.quadraticCurveTo(-7, -114, 0, -105);
    c.quadraticCurveTo(12, -124, 27, -119);
    c.quadraticCurveTo(18, -104, 4, -94);
    c.stroke();
    const pulse = 1 + Math.sin(time * 9) * 0.08 + power * 0.3;
    const g = c.createRadialGradient(1, -112, 1, 1, -112, 18 * pulse);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.18, "#b9f2ff");
    g.addColorStop(0.5, "#6b6cff");
    g.addColorStop(1, "rgba(100,35,220,0)");
    c.fillStyle = g;
    c.shadowColor = power > 0.3 ? "#50d7ff" : "#8b5cff";
    c.shadowBlur = 16 + power * 22;
    c.beginPath();
    c.arc(1, -112, 17 * pulse, 0, TAU);
    c.fill();
    c.fillStyle = "#bfefff";
    c.beginPath();
    c.moveTo(1, -126);
    c.lineTo(10, -112);
    c.lineTo(1, -99);
    c.lineTo(-8, -112);
    c.closePath();
    c.fill();
    c.restore();
  }
  function drawSkeletonMinion(c, s) {
    const spawnK = s.state === "spawn" ? easeOut(clamp(s.t / 0.72, 0, 1)) : 1;
    const dead = s.state === "dead";
    const run = s.state === "walk" ? 1 : 0;
    const ph = s.stride || 0;
    const crouch = dead ? 22 : (1 - spawnK) * 18;
    const hip = -35 + crouch;
    const scale = 0.92;
    const attackK = s.state === "attack" ? clamp(s.t / 0.7, 0, 1) : 0,
      attackLunge = Math.sin(attackK * Math.PI) * 19,
      bodyBob = run * Math.abs(Math.sin(ph)) * 3.5,
      bodyLean =
        s.state === "attack"
          ? -0.11 + attackK * 0.2
          : run
            ? Math.sin(ph) * 0.035
            : Math.sin(time * 2.4 + (s.rank || 0)) * 0.012;
    c.save();
    c.translate(s.x, GROUND + (1 - spawnK) * 52);
    c.scale(s.face * scale, scale);
    c.translate(attackLunge, -bodyBob);
    c.rotate(bodyLean);
    c.globalAlpha = Math.max(0, s.alpha) * (0.45 + 0.55 * spawnK);
    if (s.flash > 0) c.filter = "brightness(3) saturate(.3)";
    if (dead) c.rotate(-1.18 * clamp((1 - s.alpha) * 1.5, 0, 1));
    if (s.state === "spawn") {
      c.fillStyle = "rgba(70,180,255,.13)";
      c.shadowColor = "#53cfff";
      c.shadowBlur = 22;
      c.beginPath();
      c.ellipse(0, -48, 31 + Math.sin(time * 8) * 3, 62, 0, 0, TAU);
      c.fill();
      c.shadowBlur = 0;
    }
    let f1 = {
      x: -8 + Math.sin(ph) * 13 * run,
      y: -Math.max(0, Math.cos(ph)) * 7 * run,
    };
    let f2 = {
      x: 8 + Math.sin(ph + Math.PI) * 13 * run,
      y: -Math.max(0, Math.cos(ph + Math.PI)) * 7 * run,
    };
    if (dead) {
      f1 = { x: -18, y: 0 };
      f2 = { x: 17, y: 0 };
    }
    const boneLimb = (pts, w, far = false) =>
      limb(c, pts, w, "#26303a", far ? "#9cabb0" : "#d9e2df", "#f5fbf7");
    const leg = (hx, f, far) => {
      const k = ik(hx, hip, f.x, f.y, 20, 21, -1);
      boneLimb(
        [
          { x: hx, y: hip },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        7,
        far,
      );
      c.fillStyle = far ? "#89979d" : "#dce6e4";
      c.strokeStyle = "#2b3540";
      c.lineWidth = 1.5;
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 1, 10, 3.8, 0, 0, TAU);
      c.fill();
      c.stroke();
      c.fillStyle = "#7390a5";
      c.beginPath();
      c.arc(k.x, k.y, 5, 0, TAU);
      c.fill();
    };
    leg(-5, f1, true);
    leg(5, f2, false);
    // torn spectral tabard behind the bones
    const sway = Math.sin(time * 3 + s.stride) * 2 - run * 5;
    poly(
      c,
      [
        [-10, hip - 5],
        [10, hip - 5],
        [18 + sway, hip + 35],
        [8 + sway, hip + 27],
        [2 + sway, hip + 39],
        [-5 + sway, hip + 27],
        [-15 + sway, hip + 33],
      ],
      "#23364e",
      "#07101c",
      1.4,
    );
    c.save();
    c.translate(0, crouch);
    // pelvis and spine
    c.fillStyle = "#cbd8d7";
    c.strokeStyle = "#26313a";
    c.lineWidth = 1.6;
    c.beginPath();
    c.moveTo(-12, -39);
    c.quadraticCurveTo(0, -31, 12, -39);
    c.lineTo(8, -29);
    c.lineTo(-8, -29);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#e1e9e5";
    c.lineWidth = 5;
    c.beginPath();
    c.moveTo(0, -38);
    c.lineTo(0, -77);
    c.stroke();
    // armored rib cage with visible individual ribs
    c.strokeStyle = "#dbe5e2";
    c.lineWidth = 3.2;
    for (let r = 0; r < 4; r++) {
      const yy = -70 + r * 8,
        ww = 18 - r * 2;
      c.beginPath();
      c.moveTo(0, yy);
      c.quadraticCurveTo(-ww, yy - 2, -ww + 2, yy + 8);
      c.moveTo(0, yy);
      c.quadraticCurveTo(ww, yy - 2, ww - 2, yy + 8);
      c.stroke();
    }
    poly(
      c,
      [
        [-20, -76],
        [-12, -85],
        [12, -85],
        [20, -76],
        [14, -68],
        [-14, -68],
      ],
      "#60758b",
      "#18222e",
      1.8,
    );
    c.strokeStyle = "#a9d9ee";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-13, -78);
    c.lineTo(13, -78);
    c.stroke();
    // ragged cape
    poly(
      c,
      [
        [-14, -81],
        [-26, -72],
        [-31 + sway, -26],
        [-21 + sway, -33],
        [-15 + sway, -19],
        [-8, -64],
      ],
      "#1b293e",
      "#08101c",
      1.3,
    );
    // sword arm, fully jointed
    let swordA = -0.72;
    if (s.state === "attack") {
      const k = clamp(s.t / 0.34, 0, 1);
      swordA = lerp(-2.35, 0.72, ease(k));
    } else if (run) swordA = -0.5 + Math.sin(ph + Math.PI) * 0.18;
    const sh = { x: 15, y: -77 },
      hand = {
        x: sh.x + Math.cos(swordA) * 34,
        y: sh.y + Math.sin(swordA) * 34,
      };
    const elbow = ik(sh.x, sh.y, hand.x, hand.y, 18, 18, -1);
    boneLimb(
      [
        { x: sh.x, y: sh.y },
        { x: elbow.x, y: elbow.y },
        { x: hand.x, y: hand.y },
      ],
      7,
      false,
    );
    c.fillStyle = "#7793aa";
    c.strokeStyle = "#172331";
    c.lineWidth = 1.5;
    c.beginPath();
    c.arc(sh.x, sh.y, 9, 0, TAU);
    c.fill();
    c.stroke();
    c.strokeStyle = "#c5d4d5";
    c.lineWidth = 2;
    c.beginPath();
    c.arc(sh.x, sh.y, 5, 0, TAU);
    c.stroke();
    c.save();
    c.translate(hand.x, hand.y);
    c.rotate(swordA + 0.05);
    c.strokeStyle = "#181d25";
    c.lineWidth = 7;
    c.beginPath();
    c.moveTo(-8, 0);
    c.lineTo(5, 0);
    c.stroke();
    c.strokeStyle = "#a88645";
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(1, -7);
    c.lineTo(1, 7);
    c.stroke();
    const bladeLen = 68 + (s.rank || 0) * 18;
    const sg = c.createLinearGradient(5, 0, bladeLen, 0);
    sg.addColorStop(0, "#dff7ff");
    sg.addColorStop(0.5, "#8ccff0");
    sg.addColorStop(1, "#efffff");
    c.strokeStyle = sg;
    c.shadowColor = "#55c7ff";
    c.shadowBlur = 8;
    c.lineWidth = 5;
    c.beginPath();
    c.moveTo(5, 0);
    c.lineTo(bladeLen, -5);
    c.stroke();
    c.shadowBlur = 0;
    c.restore();
    // free arm and small engraved buckler
    const sh2 = { x: -15, y: -76 },
      h2 = { x: -26 + Math.sin(ph) * 4 * run, y: -49 };
    const e2 = ik(sh2.x, sh2.y, h2.x, h2.y, 17, 18, 1);
    boneLimb(
      [
        { x: sh2.x, y: sh2.y },
        { x: e2.x, y: e2.y },
        { x: h2.x, y: h2.y },
      ],
      7,
      true,
    );
    c.fillStyle = "#3e566f";
    c.strokeStyle = "#a5d8ee";
    c.lineWidth = 2;
    c.beginPath();
    c.arc(h2.x - 2, h2.y, 13, 0, TAU);
    c.fill();
    c.stroke();
    c.strokeStyle = "#6fbce1";
    c.lineWidth = 1.2;
    for (let q = 0; q < 6; q++) {
      let a = (q * TAU) / 6;
      c.beginPath();
      c.moveTo(h2.x - 2, h2.y);
      c.lineTo(h2.x - 2 + Math.cos(a) * 10, h2.y + Math.sin(a) * 10);
      c.stroke();
    }
    // detailed skull, jaw and crown-like helm
    c.fillStyle = "#dde6e2";
    c.strokeStyle = "#26313a";
    c.lineWidth = 1.8;
    c.beginPath();
    c.moveTo(-13, -103);
    c.quadraticCurveTo(-15, -119, 0, -123);
    c.quadraticCurveTo(16, -119, 13, -102);
    c.lineTo(8, -92);
    c.lineTo(-8, -92);
    c.closePath();
    c.fill();
    c.stroke();
    c.fillStyle = "#111a24";
    c.beginPath();
    c.ellipse(-5, -108, 4, 5.5, -0.1, 0, TAU);
    c.ellipse(5, -108, 4, 5.5, 0.1, 0, TAU);
    c.fill();
    c.fillStyle = "#62cfff";
    c.shadowColor = "#55c8ff";
    c.shadowBlur = 7;
    c.beginPath();
    c.arc(-5, -108, 1.5, 0, TAU);
    c.arc(5, -108, 1.5, 0, TAU);
    c.fill();
    c.shadowBlur = 0;
    c.fillStyle = "#cbd6d4";
    c.strokeStyle = "#26313a";
    c.beginPath();
    c.moveTo(-8, -93);
    c.lineTo(8, -93);
    c.lineTo(6, -85);
    c.lineTo(-6, -85);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#506b82";
    c.lineWidth = 1;
    for (let q = -4; q <= 4; q += 2) {
      c.beginPath();
      c.moveTo(q, -92);
      c.lineTo(q, -86);
      c.stroke();
    }
    poly(
      c,
      [
        [-15, -121],
        [-10, -132],
        [-4, -124],
        [0, -136],
        [5, -124],
        [12, -132],
        [15, -119],
      ],
      "#546d83",
      "#18232f",
      1.5,
    );
    c.restore();
    if (s.hp < s.maxhp && !dead) {
      c.scale(s.face, 1);
      c.fillStyle = "rgba(3,7,12,.82)";
      c.fillRect(-24, -144, 48, 5);
      c.fillStyle = "#67cfff";
      c.fillRect(-23, -143, 46 * clamp(s.hp / s.maxhp, 0, 1), 3);
    }
    c.restore();
  }
  function wizardObj() {
    const air = P.y < GROUND - 3;
    const o = {
      x: P.x,
      y: P.y,
      face: P.face,
      scale: 0.83,
      run: 0,
      phase: P.stride,
      crouch: 0,
      lean: 0,
      alpha: 1,
      flash: P.flash > 0,
      staffA: 1.45,
      staffRot: 0.03,
      handA: 1.25,
      magic: 0,
      sword: false,
      tele: false,
      beam: false,
      summon: false,
    };
    o.run = P.state === "free" && !air ? Math.min(1, Math.abs(P.vx) / 240) : 0;
    o.crouch = P.state === "free" && !air ? 8 * (P.landT / 0.14) : 0;
    if (P.state === "wizardMissile") {
      const k = clamp(P.t / 0.11, 0, 1);
      o.handA = lerp(1.25, -0.38, ease(k));
      o.staffA = lerp(1.45, 0.45, ease(k));
      o.staffRot = -0.08;
      o.magic = 1;
      o.lean = -0.08;
    } else if (P.state === "wizardSword") {
      const k = clamp(P.t / 0.22, 0, 1);
      o.handA = lerp(-2.25, 0.72, ease(k));
      o.sword = true;
      o.lean = 0.12;
      o.magic = 0.7;
    } else if (P.state === "wizardSummon") {
      o.staffA = lerp(1.45, -1.12, ease(clamp(P.t / 0.34, 0, 1)));
      o.staffRot = -0.58;
      o.handA = -1.55;
      o.magic = 1;
      o.summon = true;
      o.crouch = 5;
    } else if (P.state === "wizardBeam") {
      o.staffA = 0.72;
      o.staffRot = -0.12;
      o.handA = -0.06;
      o.magic = clamp(P.t / 1.0, 0, 1);
      o.beam = true;
      o.lean = -0.16;
    } else if (P.state === "teleport") {
      o.tele = true;
      o.alpha = 0.28 + 0.18 * Math.sin(time * 42) ** 2;
      o.lean = 0.42;
    } else if (P.state === "dodge" || P.state === "airdash") {
      o.lean = 0.48;
      o.crouch = 10;
    } else if (P.state === "block") {
      o.staffA = -0.65;
      o.staffRot = -0.36;
      o.handA = -0.75;
      o.magic = 0.55;
      o.crouch = 5;
    } else if (P.state === "hurt") {
      o.lean = -0.32;
    } else if (P.state === "heal") {
      o.staffA = 1.15;
      o.staffRot = 0.06;
      o.handA = -1.2;
      o.crouch = 7;
    } else if (P.state === "dead") {
      o.rot = -Math.min(1.5, P.deadT * 3.4);
      o.alpha = clamp(1 - (P.deadT - 1) * 0.8, 0.2, 1);
    }
    return o;
  }
  function drawWizard(c, o = wizardObj()) {
    c.save();
    c.translate(o.x, o.y);
    c.scale(o.face * o.scale, o.scale);
    if (o.rot) c.rotate(o.rot);
    c.globalAlpha = o.alpha;
    if (o.flash) c.filter = "brightness(2.8) saturate(.5)";
    const run = o.run || 0,
      ph = o.phase || 0,
      crouch = o.crouch || 0,
      hip = -40 + crouch;
    if (o.tele) {
      c.globalCompositeOperation = "lighter";
      for (let i = 3; i >= 1; i--) {
        c.globalAlpha = 0.07 * i;
        c.fillStyle = "#4abaff";
        c.beginPath();
        c.ellipse(-P.teleDir * i * 14, -67, 24, 64, 0, 0, TAU);
        c.fill();
      }
      c.globalCompositeOperation = "source-over";
      c.globalAlpha = o.alpha;
    }
    let f1 = {
        x: -9 + Math.sin(ph) * 16 * run,
        y: -Math.max(0, Math.cos(ph)) * 8 * run,
      },
      f2 = {
        x: 9 + Math.sin(ph + Math.PI) * 16 * run,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 8 * run,
      };
    const bootLeg = (hx, f, far) => {
      const k = ik(hx, hip, f.x, f.y, 22, 22, -1);
      limb(
        c,
        [
          { x: hx, y: hip },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        11,
        "#070610",
        far ? "#171526" : "#29243a",
        "#49405b",
      );
      c.fillStyle = "#0b0912";
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 2, 11, 4.5, 0, 0, TAU);
      c.fill();
      c.strokeStyle = "#a78a4d";
      c.lineWidth = 1.3;
      c.stroke();
    };
    bootLeg(-4, f1, true);
    bootLeg(4, f2, false);
    const sway = Math.sin(time * 2.2) * 3 - run * 10;
    // long layered robe tails
    poly(
      c,
      [
        [-12, hip - 5],
        [12, hip - 5],
        [22 + sway, hip + 43],
        [12 + sway, hip + 34],
        [5 + sway, hip + 47],
        [-2 + sway, hip + 35],
        [-12 + sway, hip + 44],
        [-20 + sway, hip + 29],
      ],
      "#241b35",
      "#05040a",
      1.5,
    );
    c.strokeStyle = "#6f45a1";
    c.lineWidth = 1.4;
    for (let i = 0; i < 4; i++) {
      c.beginPath();
      c.moveTo(-9 + i * 6, hip);
      c.quadraticCurveTo(-7 + i * 6, hip + 21, 2 + i * 4, hip + 38);
      c.stroke();
    }
    c.save();
    c.translate(0, crouch);
    c.rotate(o.lean || 0);
    // split traveling cloak with purple inner lining
    poly(
      c,
      [
        [-10, -82],
        [-21, -72],
        [-30 - sway * 0.3, -39],
        [-39 - sway * 0.7, -4],
        [-27 - sway, 1],
        [-19 - sway * 0.5, -12],
        [-11 - sway, 3],
        [-2, -45],
      ],
      "#0b0912",
      "#030207",
      1.5,
    );
    poly(
      c,
      [
        [8, -79],
        [19, -68],
        [25 + sway * 0.2, -36],
        [34 + sway * 0.6, -3],
        [24 + sway, 2],
        [16 + sway * 0.5, -12],
        [9 + sway * 0.8, 3],
        [1, -44],
      ],
      "#2d2043",
      "#05030a",
      1.4,
    );
    c.strokeStyle = "#7548a5";
    c.lineWidth = 1.3;
    c.beginPath();
    c.moveTo(14, -65);
    c.quadraticCurveTo(20, -34, 24 + sway, -5);
    c.stroke();
    // tailored torso, sash, belt and potion pouches
    const tg = c.createLinearGradient(-16, -88, 15, -43);
    tg.addColorStop(0, "#171322");
    tg.addColorStop(0.5, "#3c304e");
    tg.addColorStop(1, "#100c18");
    c.fillStyle = tg;
    c.strokeStyle = "#05030a";
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(-14, -83);
    c.quadraticCurveTo(0, -93, 15, -82);
    c.lineTo(12, -44);
    c.lineTo(-12, -44);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#aa8b4c";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-10, -77);
    c.quadraticCurveTo(0, -61, 11, -52);
    c.stroke();
    c.fillStyle = "#856b39";
    c.fillRect(-15, -50, 31, 5);
    c.fillStyle = "#c4a65d";
    c.fillRect(-3, -52, 7, 8);
    c.fillStyle = "#39283f";
    for (const px of [-12, 12]) {
      c.beginPath();
      c.roundRect(px - 5, -45, 10, 12, 3);
      c.fill();
      c.strokeStyle = "#a88848";
      c.lineWidth = 1;
      c.stroke();
    }
    // back arm holds articulated staff
    const s0 = { x: -9, y: -76 },
      staffHand = {
        x: s0.x + Math.cos(o.staffA) * 31,
        y: s0.y + Math.sin(o.staffA) * 31,
      };
    let e0 = ik(s0.x, s0.y, staffHand.x, staffHand.y, 18, 18, 1);
    limb(
      c,
      [
        { x: s0.x, y: s0.y },
        { x: e0.x, y: e0.y },
        { x: staffHand.x, y: staffHand.y },
      ],
      12,
      "#05030a",
      "#21182d",
      "#463756",
    );
    c.fillStyle = "#b09255";
    c.strokeStyle = "#392817";
    c.lineWidth = 1.5;
    c.beginPath();
    c.ellipse(s0.x, s0.y, 11, 8, -0.2, 0, TAU);
    c.fill();
    c.stroke();
    drawWizardStaff(c, staffHand.x - 8, staffHand.y, o.staffRot, o.magic);
    // front casting/sword arm with IK
    const s1 = { x: 10, y: -76 },
      hand = {
        x: s1.x + Math.cos(o.handA) * 37,
        y: s1.y + Math.sin(o.handA) * 37,
      };
    let e1 = ik(s1.x, s1.y, hand.x, hand.y, 19, 19, -1);
    limb(
      c,
      [
        { x: s1.x, y: s1.y },
        { x: e1.x, y: e1.y },
        { x: hand.x, y: hand.y },
      ],
      12,
      "#05030a",
      "#2a2039",
      "#514162",
    );
    c.fillStyle = "#c2a18a";
    c.strokeStyle = "#3b2630";
    c.lineWidth = 1.2;
    c.beginPath();
    c.arc(hand.x, hand.y, 6, 0, TAU);
    c.fill();
    c.stroke();
    if (o.sword) drawArcaneBlade(c, hand.x, hand.y, o.handA, 0.96);
    else if (o.magic > 0) {
      const rr = 6 + o.magic * 5 + Math.sin(time * 12) * 1.5;
      c.fillStyle = "#d9fbff";
      c.shadowColor = "#55cfff";
      c.shadowBlur = 12 + o.magic * 15;
      c.beginPath();
      c.arc(hand.x, hand.y, rr, 0, TAU);
      c.fill();
      c.shadowBlur = 0;
      c.strokeStyle = "rgba(110,220,255,.85)";
      c.lineWidth = 1.4;
      for (let i = 0; i < 3; i++) {
        let a = time * (2 + i * 0.4) + i * 2;
        c.beginPath();
        c.arc(hand.x, hand.y, rr + 5 + i * 3, a, a + 2.2);
        c.stroke();
      }
    }
    // neck, lined hood, face and long layered beard
    c.fillStyle = "#15101e";
    c.strokeStyle = "#05030a";
    c.lineWidth = 1.5;
    c.beginPath();
    c.ellipse(0, -91, 18, 16, 0, 0, TAU);
    c.fill();
    c.stroke();
    c.fillStyle = "#8b7264";
    c.strokeStyle = "#3b2930";
    c.lineWidth = 1.2;
    c.beginPath();
    c.moveTo(-10, -112);
    c.quadraticCurveTo(4, -119, 12, -109);
    c.lineTo(18, -103);
    c.lineTo(11, -99);
    c.quadraticCurveTo(6, -86, -8, -91);
    c.quadraticCurveTo(-14, -101, -10, -112);
    c.closePath();
    c.fill();
    c.stroke();
    // one readable profile eye and brow: local +X is always forward
    c.strokeStyle = "#37242e";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(3, -109);
    c.lineTo(11, -108);
    c.stroke();
    c.fillStyle = "#69d8ff";
    c.shadowColor = "#50caff";
    c.shadowBlur = 6;
    c.beginPath();
    c.ellipse(8, -106, 2.2, 1.6, 0, 0, TAU);
    c.fill();
    c.shadowBlur = 0;
    c.fillStyle = "#6f584f";
    c.beginPath();
    c.ellipse(-11, -103, 3, 5, 0, 0, TAU);
    c.fill();
    c.fillStyle = "#b7b7c5";
    c.beginPath();
    c.moveTo(-12, -100);
    c.quadraticCurveTo(-18, -77, -8, -66);
    c.quadraticCurveTo(0, -59, 6, -72);
    c.quadraticCurveTo(13, -81, 13, -99);
    c.quadraticCurveTo(6, -91, 1, -81);
    c.quadraticCurveTo(-4, -91, -12, -100);
    c.fill();
    c.strokeStyle = "#77788a";
    c.lineWidth = 1.2;
    for (let i = -8; i <= 8; i += 4) {
      c.beginPath();
      c.moveTo(i, -94);
      c.quadraticCurveTo(i - 3, -76, i, -66);
      c.stroke();
    }
    // crooked, layered sorcerer hat
    c.fillStyle = "#0c0913";
    c.strokeStyle = "#05030a";
    c.lineWidth = 2;
    c.beginPath();
    c.ellipse(0, -119, 34, 8, -0.08, 0, TAU);
    c.fill();
    c.stroke();
    const hg = c.createLinearGradient(-15, -160, 20, -118);
    hg.addColorStop(0, "#171222");
    hg.addColorStop(0.55, "#322443");
    hg.addColorStop(1, "#0c0913");
    c.fillStyle = hg;
    c.beginPath();
    c.moveTo(-18, -121);
    c.quadraticCurveTo(-12, -157, 5, -166);
    c.quadraticCurveTo(20, -163, 26, -150);
    c.quadraticCurveTo(16, -151, 11, -142);
    c.quadraticCurveTo(24, -138, 21, -123);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#8251b2";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-25, -119);
    c.quadraticCurveTo(0, -113, 27, -121);
    c.stroke();
    c.fillStyle = "#b89b58";
    c.beginPath();
    c.arc(10, -120, 3, 0, TAU);
    c.fill();
    // summoned spell circle beneath both hands
    if (o.summon) {
      c.save();
      c.globalCompositeOperation = "lighter";
      c.strokeStyle = "rgba(80,195,255,.75)";
      c.lineWidth = 2;
      const r = 34 + Math.sin(time * 9) * 3;
      c.beginPath();
      c.ellipse(0, -3, r, 9, 0, 0, TAU);
      c.stroke();
      for (let i = 0; i < 8; i++) {
        let a = (i * TAU) / 8 + time * 0.5;
        c.beginPath();
        c.moveTo(Math.cos(a) * r * 0.65, -3 + Math.sin(a) * 5);
        c.lineTo(Math.cos(a) * r, -3 + Math.sin(a) * 9);
        c.stroke();
      }
      c.restore();
    }
    c.restore();
    c.restore();
  }

  function drawRegalSword(c, x, y, a) {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    c.strokeStyle = PAL_RG.outline;
    c.lineWidth = 8;
    c.beginPath();
    c.moveTo(-13, 0);
    c.lineTo(7, 0);
    c.stroke();
    c.strokeStyle = PAL_RG.gold;
    c.lineWidth = 3;
    c.stroke();
    c.fillStyle = PAL_RG.gold2;
    c.fillRect(3, -7, 4, 14);
    const g = c.createLinearGradient(7, 0, 79, 0);
    g.addColorStop(0, "#5e5960");
    g.addColorStop(0.5, "#d9d1d4");
    g.addColorStop(1, "#fff4e0");
    c.strokeStyle = g;
    c.lineWidth = 6;
    c.beginPath();
    c.moveTo(7, 0);
    c.lineTo(75, -4);
    c.stroke();
    c.strokeStyle = "#4b333b";
    c.lineWidth = 1.2;
    c.beginPath();
    c.moveTo(12, 1);
    c.lineTo(69, -3);
    c.stroke();
    c.restore();
  }
  function drawRegalGun(c, x, y, a, flash) {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    c.fillStyle = PAL_RG.outline;
    c.fillRect(-10, -6, 57, 12);
    c.fillStyle = "#2c2930";
    c.fillRect(-6, -4, 49, 8);
    c.fillStyle = PAL_RG.gold;
    c.fillRect(4, -5, 5, 10);
    c.fillRect(25, -5, 4, 10);
    c.fillStyle = "#17141b";
    c.beginPath();
    c.moveTo(2, 5);
    c.lineTo(15, 5);
    c.lineTo(10, 22);
    c.lineTo(2, 19);
    c.closePath();
    c.fill();
    c.strokeStyle = PAL_RG.gold2;
    c.lineWidth = 1.5;
    c.stroke();
    c.fillStyle = "#5a1729";
    c.fillRect(31, -2, 18, 4);
    if (flash) {
      const g = c.createRadialGradient(53, 0, 1, 53, 0, 25);
      g.addColorStop(0, "#fffbd0");
      g.addColorStop(0.3, "#ffc554");
      g.addColorStop(1, "rgba(255,120,20,0)");
      c.fillStyle = g;
      c.beginPath();
      c.arc(53, 0, 25, 0, TAU);
      c.fill();
    }
    c.restore();
  }
  function drawRegal(c, o) {
    const p = PAL_RG,
      run = o.run || 0,
      ph = o.phase || 0,
      crouch = o.crouch || 0,
      hip = -40 + crouch;
    c.save();
    c.translate(o.x, o.y);
    const regalStep = (o.run || 0) * Math.abs(Math.sin((o.phase || 0) * 0.5)) * 2.5;
    c.translate(0, -regalStep);
    c.scale(o.face * o.scale, o.scale);
    c.rotate((o.lean || 0) * 0.2 + Math.sin(o.phase || 0) * (o.run || 0) * 0.016);
    if (o.rot) c.rotate(o.rot);
    c.globalAlpha = o.alpha;
    if (o.flash) c.filter = "brightness(2.6) saturate(.5)";
    let f1 = {
        x: -9 + Math.sin(ph) * 17 * run,
        y: -Math.max(0, Math.cos(ph)) * 9 * run,
      },
      f2 = {
        x: 9 + Math.sin(ph + Math.PI) * 17 * run,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 9 * run,
      };
    if (o.slide) {
      f1 = { x: -23, y: -2 };
      f2 = { x: 24, y: -1 };
    }
    const leg = (hx, f, far) => {
      const k = ik(hx, hip, f.x, f.y, 22, 22, -1);
      limb(
        c,
        [
          { x: hx, y: hip },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        10,
        p.outline,
        far ? "#111017" : p.mid,
        "#443b46",
      );
      c.fillStyle = p.black;
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 2, 10, 4.5, 0, 0, TAU);
      c.fill();
      c.strokeStyle = p.gold;
      c.lineWidth = 1;
      c.stroke();
    };
    leg(-4, f1, true);
    leg(4, f2, false);
    const sway = Math.sin(time * 2.2) * 3 - run * 11;
    poly(
      c,
      [
        [-11, hip - 5],
        [12, hip - 5],
        [20 + sway, hip + 41],
        [10 + sway, hip + 32],
        [4 + sway, hip + 45],
        [-3 + sway, hip + 34],
        [-12 + sway, hip + 42],
        [-19 + sway, hip + 28],
      ],
      p.red,
      p.outline,
      1.5,
    );
    c.strokeStyle = p.gold;
    c.lineWidth = 1.4;
    for (let i = 0; i < 4; i++) {
      c.beginPath();
      c.moveTo(-8 + i * 5, hip);
      c.quadraticCurveTo(-5 + i * 5, hip + 19, 4 + i * 4, hip + 36);
      c.stroke();
    }
    c.save();
    c.translate(0, crouch);
    c.rotate(o.lean || 0);
    // sweeping black/red coat and gold chains
    poly(
      c,
      [
        [-10, -82],
        [-21, -70],
        [-29 - sway * 0.3, -38],
        [-39 - sway * 0.7, -4],
        [-28 - sway, 2],
        [-20 - sway * 0.6, -12],
        [-12 - sway, 3],
        [-2, -45],
      ],
      "#09090d",
      p.outline,
      1.5,
    );
    poly(
      c,
      [
        [8, -78],
        [18, -66],
        [24 + sway * 0.2, -35],
        [32 + sway * 0.6, -4],
        [23 + sway, 1],
        [16 + sway * 0.5, -13],
        [9 + sway * 0.8, 2],
        [1, -44],
      ],
      p.red,
      p.outline,
      1.4,
    );
    const tg = c.createLinearGradient(-14, -80, 15, -45);
    tg.addColorStop(0, "#100f15");
    tg.addColorStop(0.55, "#2b242d");
    tg.addColorStop(1, "#0a090d");
    c.fillStyle = tg;
    c.beginPath();
    c.moveTo(-13, -80);
    c.quadraticCurveTo(1, -91, 14, -79);
    c.lineTo(11, -45);
    c.lineTo(-10, -45);
    c.closePath();
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.5;
    c.stroke();
    c.strokeStyle = p.gold;
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(-9, -75);
    c.quadraticCurveTo(0, -60, 11, -52);
    c.stroke();
    c.fillStyle = p.gold2;
    for (let i = 0; i < 4; i++) {
      c.beginPath();
      c.arc(-7 + i * 6, -72 + i * 6, 2.1, 0, TAU);
      c.fill();
    }
    // mask and extravagant bicorne hat
    c.fillStyle = "#050507";
    c.beginPath();
    c.arc(1, -94, 12, 0, TAU);
    c.fill();
    poly(
      c,
      [
        [-10, -100],
        [-5, -109],
        [7, -108],
        [13, -98],
        [9, -84],
        [-7, -85],
      ],
      "#17151a",
      p.outline,
      1.3,
    );
    c.fillStyle = "#030305";
    c.beginPath();
    c.moveTo(-8, -98);
    c.quadraticCurveTo(2, -102, 11, -96);
    c.lineTo(8, -88);
    c.lineTo(-7, -89);
    c.closePath();
    c.fill();
    c.strokeStyle = p.gold2;
    c.shadowColor = p.gold;
    c.shadowBlur = 6;
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(-4, -96);
    c.lineTo(7, -95);
    c.stroke();
    c.shadowBlur = 0;
    c.fillStyle = "#09080d";
    c.strokeStyle = p.gold;
    c.lineWidth = 1.8;
    c.beginPath();
    c.moveTo(-42, -109);
    c.quadraticCurveTo(-17, -132, 0, -116);
    c.quadraticCurveTo(18, -137, 43, -107);
    c.quadraticCurveTo(5, -97, -42, -109);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#755326";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-35, -108);
    c.quadraticCurveTo(-14, -125, 0, -113);
    c.quadraticCurveTo(17, -128, 36, -107);
    c.stroke();
    // ornate pauldron
    const pg = c.createRadialGradient(-3, -81, 1, 2, -77, 15);
    pg.addColorStop(0, p.gold2);
    pg.addColorStop(0.55, p.gold);
    pg.addColorStop(1, "#4c3416");
    c.fillStyle = pg;
    c.beginPath();
    c.arc(2, -77, 14, 0, TAU);
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.5;
    c.stroke();
    c.strokeStyle = "#f3d681";
    c.lineWidth = 1;
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * TAU;
      c.beginPath();
      c.moveTo(2, -77);
      c.lineTo(2 + Math.cos(a) * 12, -77 + Math.sin(a) * 12);
      c.stroke();
    }
    const s1 = { x: 3, y: -74 },
      h1 = {
        x: s1.x + Math.cos(o.swordA) * 30,
        y: s1.y + Math.sin(o.swordA) * 30,
      },
      s2 = { x: -4, y: -72 },
      h2 = { x: s2.x + Math.cos(o.gunA) * 28, y: s2.y + Math.sin(o.gunA) * 28 };
    let e = ik(s1.x, s1.y, h1.x, h1.y, 17, 17, -1);
    limb(
      c,
      [s1, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
      9,
      p.outline,
      p.red2,
      "#7c3343",
    );
    e = ik(s2.x, s2.y, h2.x, h2.y, 16, 16, 1);
    limb(
      c,
      [s2, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
      9,
      p.outline,
      p.mid,
      "#493f4b",
    );
    drawRegalSword(c, h1.x, h1.y, o.swordA);
    drawRegalGun(c, h2.x, h2.y, o.gunA, o.muzzle);
    if (o.magic) {
      const g = c.createRadialGradient(h2.x, h2.y, 1, h2.x, h2.y, 22);
      g.addColorStop(0, "#f2d9ff");
      g.addColorStop(0.3, "#7d3fac");
      g.addColorStop(1, "rgba(20,0,35,0)");
      c.fillStyle = g;
      c.beginPath();
      c.arc(h2.x, h2.y, 22, 0, TAU);
      c.fill();
    }
    c.restore();
    c.restore();
  }
  function regalObj() {
    const air = P.y < GROUND - 3,
      o = {
        kind: "regal",
        scale: 1.06,
        x: P.x,
        y: P.y,
        face: P.face,
        run: 0,
        phase: P.stride,
        crouch: 0,
        lean: 0,
        swordA: 0.55,
        gunA: -0.16,
        flash: P.flash > 0,
        alpha: 1,
        muzzle: false,
        magic: false,
      };
    o.run = P.state === "free" && !air ? Math.min(1, Math.abs(P.vx) / 240) : 0;
    o.lean = o.run * 0.08;
    o.crouch = P.state === "free" && !air ? 9 * (P.landT / 0.14) : 0;
    if (P.state === "regalSword") {
      const k = clamp(P.t / 0.38, 0, 1),
        sw = k < 0.55 ? ease(k / 0.55) : easeOut((k - 0.55) / 0.45);
      o.swordA = lerp(-2.25, 1.05, sw);
      o.gunA = 0.45;
      o.lean = 0.12;
      o.run = 0;
    } else if (P.state === "regalGun") {
      o.gunA = -0.03;
      o.swordA = 1.2;
      o.muzzle = P.shotFired && P.t < 0.14;
      o.lean = -0.08;
      o.run = 0;
    } else if (P.state === "regalOrb") {
      o.gunA = lerp(0.3, -1.35, clamp(P.t / 0.28, 0, 1));
      o.swordA = 1.35;
      o.magic = true;
      o.lean = -0.1;
      o.run = 0;
    } else if (P.state === "regalBeam") {
      o.gunA = 0.02;
      o.swordA = 1.35;
      o.magic = true;
      o.lean = -0.16;
      o.run = 0;
    } else if (P.state === "dodge" || P.state === "airdash") {
      o.slide = !air;
      o.lean = 0.5;
      o.run = 0;
    } else if (P.state === "block") {
      o.swordA = -0.7;
      o.gunA = 0.6;
      o.crouch = 5;
      o.run = Math.min(1, Math.abs(P.vx) / 120) * 0.4;
    } else if (P.state === "hurt") {
      o.lean = -0.3;
      o.run = 0;
    } else if (P.state === "heal") {
      o.swordA = 1.65;
      o.gunA = 1.4;
      o.crouch = 6;
      o.run = 0;
    } else if (P.state === "dead") {
      o.rot = -Math.min(1.5, P.deadT * 3.5);
      o.run = 0;
      o.alpha = clamp(1 - (P.deadT - 1) * 0.8, 0.25, 1);
    }
    return o;
  }

  /* ================= KILLNUX — colossal-sword berserker ================= */
  const KILL_ATK = [
    { w: 0.3, a: 0.17, r: 0.34, reach: 168, lunge: 58, a0: -2.18, a1: 0.82 },
    { w: 0.25, a: 0.17, r: 0.36, reach: 172, lunge: 62, a0: 2.15, a1: -0.72 },
    { w: 0.38, a: 0.19, r: 0.52, reach: 184, lunge: 74, a0: -1.72, a1: 1.12 },
  ];
  function startKillAttack(idx = 0) {
    const A = KILL_ATK[idx];
    P.state = "killAttack";
    P.t = 0;
    P.combo = idx;
    P.hitDone = false;
    P.fxDone = false;
    P.st = Math.max(0, P.st - 30);
    P.stDelay = P.st <= 0 ? 1.15 : 0.76;
    const dir = (isActionHeld("right") ? 1 : 0) - (isActionHeld("left") ? 1 : 0);
    if (dir) P.face = dir;
    P.vx *= 0.28;
    buf.attack = 0;
  }
  function killnuxStrike(A) {
    if (P.hitDone || B.state === "dead" || B.state === "intro") return;
    const lo = Math.min(P.x - P.face * 16, P.x + P.face * A.reach),
      hi = Math.max(P.x - P.face * 16, P.x + P.face * A.reach),
      pb = GROUND - P.y;
    if (B.x + B.hw > lo && B.x - B.hw < hi && pb + 140 > B.h && pb - 22 < B.h + B.hh) {
      P.hitDone = true;
      hitBoss(200 * (P.killArmorT > 0 ? 1.5 : 1), 0.1);
      doShake(8);
      spark(B.x, GROUND - B.h - Math.min(95, B.hh * .55), 18, "#dbe1e8", 420, .4, 180);
    }
  }
  function startKillDodge(dir) {
    P.state = "killDodge";
    P.t = 0;
    P.dodgeDir = dir || P.face;
    P.face = P.dodgeDir;
    P.invuln = Math.max(P.invuln, 0.34);
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.55;
    buf.dodge = 0;
    sfx("dodge");
    dust(P.x, GROUND, 8);
  }
function startKillSkill1(dir) {
    P.state = "killSkill1";
    P.t = 0;
    P.killSkillFired = false;
    P.skill1CD = KILLNUX_SKILL1_CD;
    if (dir) P.face = dir;
    P.vx = 0;
    buf.skill1 = 0;
    sfx("charge");
  }
  function releaseKillWave() {
    const powered = P.killArmorT > 0;
    killWaves.push({
      owner: activePlayerIndex,
      x: P.x + P.face * 52,
      y: GROUND - 20,
      vx: P.face * 760,
      face: P.face,
      t: 0,
      life: 1.65,
      hit: false,
      dmg: 400 * (powered ? 1.5 : 1),
      powered,
    });
    sfx("boom"); doShake(16); doFlash(.24, "35,25,50");
    dust(P.x + P.face * 42, GROUND, 24);
    spark(P.x + P.face * 48, GROUND - 12, 30, powered ? "#8c65b2" : "#292633", 620, .6, 180);
    addRing(P.x + P.face * 42, GROUND - 4, 10, 155, .4, "rgba(40,34,52,.92)", 9);
  }
  function startKillSkill2() {
    P.state = "killTransform";
    P.t = 0;
    P.killSkillFired = false;
    P.skill2CD = KILLNUX_SKILL2_CD;
    P.vx = 0;
    buf.skill2 = 0;
    sfx("charge");
  }
  function updateKillWaves(dt) {
    for (let i = killWaves.length - 1; i >= 0; i--) {
      const w = killWaves[i],
        target = projectileTarget(w);
      w.t += dt; w.x += w.vx * dt;
      if (Math.random() < .8) parts.push({k:"dot",x:w.x-rnd(0,45)*w.face,y:GROUND-rnd(4,42),vx:-w.face*rnd(15,80),vy:rnd(-35,5),life:rnd(.18,.38),t:0,col:w.powered?"85,55,110":"25,23,31",g:0,drag:2,sz:rnd(3,8)});
      let dead = w.t > w.life || w.x < -80 || w.x > WORLD + 80;
      if (!w.hit && target.state !== "dead" && target.state !== "intro" && Math.abs(target.x - w.x) < target.hw + 58 && target.h < 120) {
        w.hit = true; dead = true;
        hitProjectileTarget(w, w.dmg, .14, true, true);
        doShake(13); spark(w.x, GROUND - 48, 28, w.powered ? "#9b6fc5" : "#40394d", 520, .5, 120);
        addRing(w.x, GROUND - 38, 10, 105, .34, "rgba(55,45,70,.9)", 8);
      }
      if (dead) killWaves.splice(i, 1);
    }
  }
  function drawKillWaves() {
    for (const w of killWaves) {
      const k = clamp(w.t / w.life, 0, 1), pulse = 1 + Math.sin(time * 18) * .08;
      ctx.save(); ctx.translate(w.x, w.y); ctx.scale(w.face, 1); ctx.globalAlpha = 1 - k * .45;
      ctx.shadowColor = w.powered ? "#6d428f" : "#09080d"; ctx.shadowBlur = 20;
      const g = ctx.createLinearGradient(-45, 0, 58, -74);
      g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(.25, w.powered ? "rgba(52,31,70,.95)" : "rgba(5,5,8,.96)"); g.addColorStop(.72, w.powered ? "rgba(117,72,145,.9)" : "rgba(35,31,43,.9)"); g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-72, 15); ctx.quadraticCurveTo(12, -132 * pulse, 96, 4); ctx.quadraticCurveTo(15, -24, -72, 15); ctx.fill();
      ctx.strokeStyle = w.powered ? "rgba(185,130,225,.72)" : "rgba(120,112,135,.5)"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-48, 7); ctx.quadraticCurveTo(14, -108 * pulse, 82, 0); ctx.stroke();
      ctx.restore();
    }
  }
  function drawKillnuxSword(c, x, y, A, glow = 0) {
    const enchanted = heroType === "killnux" && P && P.killArmorT > 0;
    c.save(); c.translate(x, y); c.rotate(A);
    c.strokeStyle = "#030406"; c.lineWidth = 16; c.lineCap = "round";
    c.beginPath(); c.moveTo(-17,0); c.lineTo(6,0); c.stroke();
    c.strokeStyle = "#3a2a25"; c.lineWidth = 8; c.beginPath(); c.moveTo(-17,0); c.lineTo(7,0); c.stroke();
    c.lineCap = "butt";
    c.fillStyle = "#9ba1a8"; c.strokeStyle = "#08090b"; c.lineWidth = 2;
    c.beginPath(); c.moveTo(0,-11); c.lineTo(10,-13); c.lineTo(14,-7); c.lineTo(14,7); c.lineTo(10,13); c.lineTo(0,11); c.closePath(); c.fill(); c.stroke();
    const g=c.createLinearGradient(12,-16,112,16); g.addColorStop(0,"#d8dce0");g.addColorStop(.12,"#60656c");g.addColorStop(.5,"#171a1f");g.addColorStop(.86,"#484e55");g.addColorStop(1,"#d7dce1");
    c.shadowColor=enchanted?"#513164":"#d9e2eb";c.shadowBlur=glow;
    c.fillStyle=g;c.strokeStyle="#050608";c.lineWidth=2.4;
    c.beginPath();c.moveTo(12,-15);c.lineTo(106,-13);c.lineTo(122,0);c.lineTo(106,13);c.lineTo(12,15);c.closePath();c.fill();c.stroke();
    c.shadowBlur=0;c.strokeStyle=enchanted?"rgba(151,103,181,.9)":"rgba(245,248,250,.72)";c.lineWidth=1.4;c.beginPath();c.moveTo(18,-12);c.lineTo(104,-10);c.lineTo(116,0);c.stroke();
    if(enchanted){
      c.globalCompositeOperation="screen";c.fillStyle="rgba(47,28,58,.78)";c.shadowColor="#5d3970";c.shadowBlur=13;
      for(let i=0;i<7;i++){const xx=22+i*14,h=5+Math.sin(time*11+i*1.4)*3;c.beginPath();c.moveTo(xx-6,-12);c.quadraticCurveTo(xx,-21-h,xx+6,-11);c.quadraticCurveTo(xx,-7,xx-6,-12);c.fill();}
      c.shadowBlur=0;
    }
    c.restore();
  }
  function killnuxObj() {
    const air=P.y<GROUND-3, st=P.state;
    const o={x:P.x,y:P.y,face:P.face,scale:.9,phase:P.stride,run:0,air,crouch:0,lean:.025,swordA:-1.15,handR:31,alpha:1,flash:P.flash>0,rot:0,cloak:0,armored:P.killArmorT>0};
    o.run=st==="free"&&!air?Math.min(1,Math.abs(P.vx)/250):0;
    o.lean=.025+o.run*.09; o.cloak=-o.run*12; o.crouch=st==="free"&&!air?9*(P.landT/.14):0;
    if(st==="killAttack"){
      const A=KILL_ATK[P.combo];
      if(P.t<A.w){const k=easeOut(P.t/A.w);o.swordA=lerp(-1.15,A.a0,k);o.lean=-.14*k;o.crouch=6*k;}
      else if(P.t<A.w+A.a){const k=ease((P.t-A.w)/A.a);o.swordA=lerp(A.a0,A.a1,k);o.handR=lerp(27,45,k);o.lean=lerp(-.12,.34,k);o.crouch=7;}
      else{const k=clamp((P.t-A.w-A.a)/A.r,0,1);o.swordA=lerp(A.a1,-1.15,easeOut(k));o.handR=lerp(45,28,k);o.lean=.26*(1-k);}
      o.run=0;o.cloak=-18;
    }else if(st==="killSkill1"){
      if(P.t<.38){const k=easeOut(P.t/.38);o.swordA=lerp(-1.15,-1.72,k);o.handR=lerp(31,26,k);o.crouch=8*k;o.lean=-.16*k;}
      else if(P.t<.56){const k=ease((P.t-.38)/.18);o.swordA=lerp(-1.72,1.34,k);o.handR=lerp(26,47,k);o.crouch=lerp(8,17,k);o.lean=lerp(-.16,.38,k);}
      else{const k=clamp((P.t-.56)/.6,0,1);o.swordA=lerp(1.34,-1.15,easeOut(k));o.handR=lerp(47,31,k);o.crouch=17*(1-k);o.lean=.3*(1-k);}
      o.run=0;o.cloak=-22;
    }else if(st==="killTransform"){
      const k=clamp(P.t/1.35,0,1);o.swordA=lerp(-1.15,-1.48,ease(Math.min(1,k*1.8)));o.handR=35;o.crouch=10*Math.sin(k*Math.PI);o.lean=-.12*Math.sin(k*Math.PI);o.cloak=-28*Math.sin(k*Math.PI);o.armored=P.killSkillFired||k>.46;o.run=0;
    }else if(st==="killDodge"){o.crouch=23;o.lean=.64;o.swordA=2.75;o.run=0;o.cloak=-24;}
    else if(st==="block"){o.crouch=7;o.lean=-.08;o.swordA=-.18;o.handR=40;o.run=Math.min(1,Math.abs(P.vx)/120)*.35;}
    else if(st==="hurt"){o.lean=-.3;o.swordA=1.8;o.run=0;}
    else if(st==="heal"){o.crouch=6;o.swordA=1.45;o.run=0;}
    else if(st==="dead"){o.rot=-Math.min(1.35,P.deadT*2.7);o.alpha=clamp(1-(P.deadT-1)*.8,.25,1);o.run=0;}
    else if(air){o.swordA=-1.18;o.lean=.08;}
    // Blend the important pose channels between rendered frames. Each player
    // owns a separate cache, so local co-op never mixes their animation state.
    if(P.killVisualPose){
      const q=P.killVisualPose,k=.34;
      for(const key of ["swordA","handR","lean","crouch","cloak","run"])
        o[key]=lerp(q[key],o[key],k);
    }
    P.killVisualPose={
      swordA:o.swordA,handR:o.handR,lean:o.lean,crouch:o.crouch,
      cloak:o.cloak,run:o.run
    };
    return o;
  }
  function drawKillnux(c,o=killnuxObj()){
    const run=o.run||0,ph=o.phase||0,crouch=o.crouch||0,hip=-48+crouch;
    const ink="#020304",black=o.armored?"#020205":"#080a0d",mid=o.armored?"#090a10":"#171a1f",steel=o.armored?"#333741":"#626a73",edge="#c7ced5",skin="#bd8d72";
    const breathe=run<.08&&P.state==="free"?Math.sin(time*2.35)*.85:0;
    c.save();c.translate(o.x,o.y-run*Math.abs(Math.sin(ph))*2.8+breathe);c.scale(o.face*o.scale,o.scale);c.rotate((o.rot||0)+(o.lean||0)*.22+Math.sin(ph)*run*.018);c.globalAlpha=o.alpha;if(o.flash)c.filter="brightness(2.5) saturate(.4)";
    if(o.armored){
      c.save();c.globalCompositeOperation="screen";c.fillStyle="rgba(45,30,62,"+(.1+.04*Math.sin(time*8))+")";c.shadowColor="#4c315f";c.shadowBlur=24;c.beginPath();c.ellipse(0,-67,42,76,0,0,TAU);c.fill();c.restore();
    }
    // broad wind-reactive cloak
    const sway=Math.sin(time*2.2+ph*.12)*4+(o.cloak||0);
    const cg=c.createLinearGradient(-10,-102,-45,0);cg.addColorStop(0,"#20242a");cg.addColorStop(.45,"#0c0e12");cg.addColorStop(1,"#030405");
    c.fillStyle=cg;c.strokeStyle=ink;c.lineWidth=1.7;c.beginPath();c.moveTo(-18,-94);c.quadraticCurveTo(-38+sway,-72,-34+sway,-25);c.lineTo(-25+sway,3);c.lineTo(-14+sway,-5);c.lineTo(-4+sway,7);c.lineTo(7+sway,-5);c.lineTo(18+sway,1);c.lineTo(24+sway,-49);c.lineTo(17,-94);c.closePath();c.fill();c.stroke();
    c.strokeStyle="rgba(115,125,138,.3)";c.lineWidth=1;for(let i=0;i<5;i++){c.beginPath();c.moveTo(-14+i*7,-90);c.quadraticCurveTo(-27+sway+i*9,-48,-19+sway+i*8,-2);c.stroke();}
    let f1={x:-13+Math.sin(ph)*18*run,y:-Math.max(0,Math.cos(ph))*9*run},f2={x:14+Math.sin(ph+Math.PI)*18*run,y:-Math.max(0,Math.cos(ph+Math.PI))*9*run};
    if(o.air){f1={x:-14,y:-16};f2={x:18,y:-25};}if(P.state==="killDodge"){f1={x:-24,y:-2};f2={x:25,y:-1};}
    const leg=(hx,f,far)=>{const k=ik(hx,hip,f.x,f.y,24,25,-1);limb(c,[{x:hx,y:hip},{x:k.x,y:k.y},{x:k.tx,y:k.ty}],8.5,ink,far?"#0a0b0e":mid,steel);poly(c,[[k.tx-8,k.ty-4],[k.tx+12,k.ty-4],[k.tx+18,k.ty],[k.tx+9,k.ty+3],[k.tx-8,k.ty+2]],black,ink,1);};leg(-6,f1,true);leg(6,f2,false);
    c.save();c.translate(0,crouch*.6);
    // layered dark plate and belts
    c.fillStyle=mid;c.strokeStyle=ink;c.lineWidth=1.8;c.beginPath();c.moveTo(-19,-86);c.quadraticCurveTo(0,-101,20,-85);c.lineTo(14,-45);c.quadraticCurveTo(0,-38,-14,-46);c.closePath();c.fill();c.stroke();
    c.strokeStyle=steel;c.lineWidth=1.4;for(let y=-79;y<-48;y+=8){c.beginPath();c.moveTo(-15,y);c.lineTo(15,y+2);c.stroke();}
    c.fillStyle="#35271f";c.fillRect(-15,-50,30,6);c.strokeStyle=ink;c.strokeRect(-15,-50,30,6);c.fillStyle=steel;for(let x=-11;x<13;x+=8)c.fillRect(x,-49,2.5,4);
    poly(c,[[-13,-44],[13,-44],[12,-18],[6,-25],[1,-14],[-5,-26],[-11,-18]],black,ink,1.3);
    if(o.armored){
      c.strokeStyle="#3c3449";c.lineWidth=1.2;
      for(let yy=-82;yy<-44;yy+=7)for(let xx=-15;xx<16;xx+=10){c.beginPath();c.moveTo(xx,yy);c.lineTo(xx+5,yy+4);c.lineTo(xx,yy+8);c.stroke();}
      poly(c,[[-25,-89],[-13,-101],[-4,-89],[-13,-78]],"#0b0c12",ink,1.2);poly(c,[[25,-89],[13,-101],[4,-89],[13,-78]],"#0b0c12",ink,1.2);
    }
    // asymmetric pauldrons
    const pauldron=(x,y,big)=>{c.fillStyle=big?"#262a30":"#171a1f";c.strokeStyle=ink;c.lineWidth=1.6;c.beginPath();c.ellipse(x,y,big?14:11,big?10:8,x<0?-.25:.25,0,TAU);c.fill();c.stroke();c.strokeStyle=steel;c.lineWidth=1;c.beginPath();c.arc(x,y,big?10:8,.2,2.8);c.stroke();};pauldron(-21,-82,true);pauldron(22,-81,false);
    // neck scarf and a narrower, human face with a defined jaw
    c.fillStyle="#050608";c.beginPath();c.ellipse(0,-96,15,10,0,0,TAU);c.fill();
    const face=c.createLinearGradient(-9,-125,9,-101);
    face.addColorStop(0,"#d4a187");face.addColorStop(.48,skin);face.addColorStop(1,"#805747");
    c.fillStyle=face;c.strokeStyle=ink;c.lineWidth=1.25;c.beginPath();
    c.moveTo(-8,-122);c.quadraticCurveTo(-7,-130,1,-131);c.quadraticCurveTo(9,-129,10,-121);
    c.lineTo(7,-106);c.quadraticCurveTo(4,-100,0,-98);c.quadraticCurveTo(-5,-101,-8,-107);c.closePath();c.fill();c.stroke();
    // brows, focused eyes, nose, mouth and the diagonal scar
    c.strokeStyle="#2b1d1b";c.lineWidth=1.35;c.beginPath();c.moveTo(-7,-118);c.lineTo(-1,-119);c.moveTo(2,-119);c.lineTo(8,-117);c.stroke();
    c.fillStyle="#17181b";c.beginPath();c.ellipse(-4.2,-115.5,2.4,1.05,-.12,0,TAU);c.ellipse(4.8,-114.8,2.4,1.05,.12,0,TAU);c.fill();
    c.strokeStyle="rgba(76,43,35,.9)";c.lineWidth=1;c.beginPath();c.moveTo(.4,-115);c.lineTo(-.8,-109);c.lineTo(1.6,-108);c.moveTo(-3,-104.5);c.quadraticCurveTo(1,-102.8,4.5,-104.8);c.stroke();
    c.strokeStyle="#533029";c.lineWidth=1.15;c.beginPath();c.moveTo(-7,-121);c.lineTo(5,-103);c.moveTo(-6,-112);c.lineTo(7,-113.5);c.stroke();
    // layered spiky hair instead of a flat rectangular crown
    c.fillStyle="#08090c";c.beginPath();c.ellipse(0,-124,10.5,7.5,0,Math.PI,TAU);c.fill();
    for(let i=0;i<11;i++){const x=-10.5+i*2.05,h=4.5+((i*5)%4)*1.35,lean=(i-5)*.14;poly(c,[[x,-122],[x+lean,-128-h],[x+2.8,-121]],i%2?"#050608":"#15171c",ink,.55);}
    if(o.armored){
      poly(c,[[-15,-125],[-10,-139],[-3,-134],[2,-145],[8,-134],[16,-138],[13,-119],[8,-102],[0,-96],[-9,-103]],"#090a0e",ink,1.4);
      poly(c,[[-11,-133],[-20,-144],[-14,-121]],"#171922",ink,1);poly(c,[[10,-134],[20,-145],[14,-121]],"#171922",ink,1);
      c.fillStyle="#b84b45";c.shadowColor="#7b2434";c.shadowBlur=8;c.beginPath();c.ellipse(6,-119,3.2,1.8,-.15,0,TAU);c.fill();c.shadowBlur=0;
      c.strokeStyle="#4d5260";c.lineWidth=1;c.beginPath();c.moveTo(-6,-112);c.lineTo(8,-109);c.lineTo(4,-101);c.stroke();
    }
    const shoulder={x:17,y:-80},A=o.swordA,R=o.handR,hand={x:shoulder.x+Math.cos(A)*R,y:shoulder.y+Math.sin(A)*R},el=ik(shoulder.x,shoulder.y,hand.x,hand.y,19,20,1);
    limb(c,[shoulder,{x:el.x,y:el.y},{x:el.tx,y:el.ty}],9.5,ink,mid,steel);
    // second hand follows the huge grip on heavy swings
    const grip2={x:hand.x-Math.cos(A)*18,y:hand.y-Math.sin(A)*18},s2={x:-16,y:-80},e2=ik(s2.x,s2.y,grip2.x,grip2.y,19,20,-1);
    limb(c,[s2,{x:e2.x,y:e2.y},{x:e2.tx,y:e2.ty}],9,ink,"#12151a",steel);
    drawKillnuxSword(c,hand.x,hand.y,A,o.armored?22:(P.state==="killSkill1"?12:2));
    c.fillStyle=steel;c.beginPath();c.arc(hand.x,hand.y,5,0,TAU);c.fill();c.restore();c.restore();
  }

  /* ================= COMBAT DATA ================= */
  const ATK = [
    {
      w: 0.02,
      a: 0.08,
      r: 0.09,
      cost: 20,
      reach: 122,
      lunge: 40,
      a0: -2.3,
      a1: 1.05,
    },
    {
      w: 0.02,
      a: 0.08,
      r: 0.09,
      cost: 20,
      reach: 128,
      lunge: 40,
      a0: 1.35,
      a1: -1.6,
    },
    {
      w: 0.03,
      a: 0.09,
      r: 0.17,
      cost: 20,
      reach: 160,
      lunge: 80,
      a0: -0.5,
      a1: 0.05,
      thrust: true,
    },
  ];
  const RECT = {
    sweep: { x0: 8, x1: 190, h0: 0, h1: 62 },
    over: { x0: 8, x1: 165, h0: 0, h1: 155 },
    thrust: { x0: 8, x1: 225, h0: 30, h1: 118 },
    rise: { x0: -10, x1: 170, h0: 0, h1: 155 },
  };
  const STOP = { sweep: 105, over: 100, thrust: 135, rise: 100 };
  const mkA = (type, w, a, r, lunge) => ({
    type,
    w,
    a,
    r,
    lunge,
    rect: RECT[type],
    stop: STOP[type],
  });
  const COMBOS = [
    {
      name: "Twin Cut",
      atks: [
        mkA("sweep", 0.62, 0.12, 0.28, 70),
        mkA("over", 0.55, 0.13, 1.0, 50),
      ],
    },
    {
      name: "Triple Reaver",
      atks: [
        mkA("thrust", 0.56, 0.12, 0.3, 90),
        mkA("sweep", 0.42, 0.12, 0.28, 60),
        mkA("rise", 0.5, 0.13, 1.0, 50),
      ],
    },
    {
      name: "Crescent Fall",
      atks: [
        mkA("rise", 0.66, 0.13, 0.34, 70),
        mkA("over", 0.36, 0.12, 0.3, 60),
        mkA("thrust", 0.78, 0.12, 1.05, 110),
      ],
    },
    {
      name: "Requiem",
      atks: [
        mkA("sweep", 0.5, 0.12, 0.26, 70),
        mkA("sweep", 0.36, 0.12, 0.3, 60),
        mkA("over", 0.6, 0.13, 0.34, 60),
        mkA("thrust", 0.7, 0.12, 1.1, 90),
      ],
    },
  ];
  const BK = {
    over: { aw: -2.1, a1: 1.25, wl: -0.12, sl: 0.22, rw: 26, rs: 28 },
    sweep: { aw: 2.9, a1: 0.05, wl: -0.2, sl: 0.25, rw: 26, rs: 34 },
    thrust: { aw: -0.15, a1: 0.02, wl: -0.22, sl: 0.3, rw: 12, rs: 40 },
    rise: { aw: 1.7, a1: -1.9, wl: 0.15, sl: -0.1, rw: 28, rs: 26 },
  };

  /* ================= STATE ================= */
  let phase = "title",
    phaseT = 0,
    time = 0,
    hitstop = 0,
    shake = 0,
    screenFlash = 0,
    screenFlashCol = "255,255,255",
    impactMuteT = 0,
    cam = 0;
  let pvpWinner = 0;
  let P, P2 = null, B;
  let players = [];
  let playerHeroes = ["knight", "killnux"];
  const parts = [],
    fx = [],
    motes = [];
  const orbs = [];
  const slashes = [];
  const demonHazards = [];
  const shogunHazards = [];
  let shogunMinion = null;
  const SKILL1_CD = 30,
    SKILL2_CD = 80;
  let bossType = "sentinel";
  function bossHP() {
    return bossType === "art"
      ? 12000
      : bossType === "demon"
        ? 16000
        : bossType === "shogun"
          ? 15000
          : 4000;
  }
  const prev = {
    bh: 0,
    px: 0,
    py: 0,
    bx: 0,
    cam: 0,
    pt: 0,
    bpt: 0,
    ps: "",
    bs: "",
    bph: "",
    time: 0,
    pst: 0,
    bst: 0,
  };
  function savePrev() {
    prev.px = P.x;
    prev.py = P.y;
    prev.bx = B.x;
    prev.cam = cam;
    prev.pt = P.t;
    prev.bpt = B.pt;
    prev.ps = P.state;
    prev.bs = B.state;
    prev.bph = B.phase;
    prev.pst = P.stride;
    prev.bst = B.stride;
    prev.bh = B.h;
  }
  function reset() {
    const rb = buildBonuses(),
      maxHp = HERO_STATS[heroType].hp + rb.health,
      maxSt = HERO_STATS[heroType].st + rb.stamina;
    P = {
      x: 560,
      y: GROUND,
      vx: 0,
      vy: 0,
      face: 1,
      hp: maxHp,
      maxhp: maxHp,
      ghost: maxHp,
      ghostDelay: 0,
      st: maxSt,
      maxst: maxSt,
      stDelay: 0,
      flasks: HERO_STATS[heroType].flasks,
      maxFlasks: HERO_STATS[heroType].flasks,
      state: "free",
      t: 0,
      combo: 0,
      hitDone: false,
      fxDone: false,
      invuln: 0,
      flash: 0,
      parrySucc: false,
      endT: 0.62,
      healed: false,
      plungeHit: false,
      deadT: 0,
      dodgeDir: 1,
      airAtk: false,
      parryFlash: 0,
      airDodged: false,
      landT: 0,
      stride: 0,
      blockFlash: 0,
      skill1CD: 0,
      skill2CD: 0,
      skill1Fired: false,
      skill2Fired: false,
      skill2Hit: false,
      shotFired: false,
      rt: "",
      teleDir: 1,
      rPhase: "",
      rHit100: false,
      rArrows: 0,
      rNextArrow: 0,
      rDropped: false,
      rStartX: 0,
      rTargetX: 0,
      rainFired: false,
      regalHit: false,
      regalFx: false,
      regalOrbFired: false,
      regalBeamFired: false,
      wizardHit: false,
      wizardFx: false,
      flameT: 0,
      killArmorT: 0,
      killSkillFired: false,
      deflects: 0,
      roninStartX: 0,
      roninTargetX: 0,
      roninHit: false,
      attackMult: 1 + rb.attack,
      skillAttackMult: 1 + rb.skillAttack,
      defenseMult: Math.max(0, 1 - rb.defense),
      skillRate: 1 + rb.cooldown,
      staminaRegenMult: 1 + rb.staminaRecovery,
      healMult: 1 + rb.healing,
    };
    B = {
      type: bossType,
      hw:
        bossType === "demon"
          ? 58
          : bossType === "art" || bossType === "shogun"
            ? 38
            : 34,
      hh:
        bossType === "demon"
          ? 205
          : bossType === "art" || bossType === "shogun"
            ? 165
            : 148,
      h: 0,
      jn: 0,
      rn: 0,
      jx0: 0,
      jx1: 0,
      rdir: 1,
      rdist: 0,
      rmoved: 0,
      jfirst: true,
      rfirst: true,
      x: 1230,
      y: GROUND,
      face: -1,
      hp: bossHP(),
      maxhp: bossHP(),
      ghost: bossHP(),
      ghostDelay: 0,
      state: "intro",
      t: 0,
      cool: 1,
      last: "",
      lastCombo: -1,
      flash: 0,
      stunT: 0,
      combo: null,
      ci: 0,
      atk: null,
      phase: "",
      pt: 0,
      hitDone: false,
      rage: false,
      moving: false,
      beamHit: false,
      dieT: 0,
      roared: false,
      expR: 0,
      introFill: 0,
      stride: 0,
      execMark: null,
      dphase: 1,
      transformed2: false,
      transformed3: false,
      shots: 0,
      shotNext: 0,
      mode: "",
      teleX: 0,
      parryT: 0,
      prevDPhase: 1,
      sphase: 1,
      sparryT: 0,
      sIndex: 0,
      sCount: 0,
      sNext: 0,
      sMode: "",
      sFly: 0,
      moveV: 0,
      moveLean: 0,
      bowDraw: 0,
    };
    const flaskLimit = gameMode === "pvp" ? 4 : gameMode === "coop" ? 5 : null;
    if (flaskLimit !== null) {
      playerHeroes = [heroType, heroType2];
      P.flasks = P.maxFlasks = flaskLimit;
      P.x = gameMode === "pvp" ? 510 : 470;
      P.face = 1;
      P2 = JSON.parse(JSON.stringify(P));
      const stats2 = HERO_STATS[heroType2];
      P2.x = gameMode === "pvp" ? 1290 : 650;
      P2.face = gameMode === "pvp" ? -1 : 1;
      P2.hp = P2.maxhp = P2.ghost = stats2.hp;
      P2.st = P2.maxst = stats2.st;
      P2.flasks = P2.maxFlasks = flaskLimit;
      P2.state = "free";
      P2.t = 0;
      players = [P, P2];
      if (gameMode === "coop") {
        // Two heroes deal much more combined damage, so co-op bosses get 2× HP.
        B.hp = B.maxhp = B.ghost = bossHP() * 2;
      }
      if (gameMode === "pvp") {
        B.type = "pvp";
        B.state = "idle";
        B.x = WORLD / 2;
        B.hp = B.maxhp = B.ghost = 1;
        B.introFill = 1;
      }
    } else {
      P2 = null;
      players = [P];
    }
    parts.length = 0;
    fx.length = 0;
    orbs.length = 0;
    slashes.length = 0;
    demonHazards.length = 0;
    shogunHazards.length = 0;
    shogunMinion = null;
    arrows.length = 0;
    rain.length = 0;
    regalShots.length = 0;
    regalMeteors.length = 0;
    regalBeams.length = 0;
    wizardMissiles.length = 0;
    skeletons.length = 0;
    killWaves.length = 0;
    cam = gameMode === "pvp"
      ? clamp((P.x + P2.x) * 0.5 - W / 2, 0, WORLD - W)
      : clamp(P.x * 0.6 + B.x * 0.4 - W / 2, 0, WORLD - W);
    hitstop = 0;
    shake = 0;
    screenFlash = 0;
    savePrev();
  }
  function pvpProxy(target) {
    return {
      type: "pvp",
      x: target.x,
      y: target.y,
      h: Math.max(0, GROUND - target.y),
      hw: 30,
      hh: 138,
      hp: target.hp,
      maxhp: target.maxhp,
      ghost: target.ghost,
      state: target.state === "dead" ? "dead" : "idle",
      phase: "",
      flash: target.flash,
      stunT: 0,
      combo: null,
      hitDone: false,
      execMark: null,
    };
  }
  function withPlayer(index, fn, usePvpTarget = false) {
    if (!players[index]) return;
    const oldP = P,
      oldHero = heroType,
      oldHeld = held,
      oldBuf = buf,
      oldB = B;
    activePlayerIndex = index;
    P = players[index];
    heroType = playerHeroes[index];
    held = index === 0 ? held : held2;
    buf = index === 0 ? buf : buf2;
    if (usePvpTarget && gameMode === "pvp")
      B = pvpProxy(players[index === 0 ? 1 : 0]);
    try {
      return fn();
    } finally {
      players[index] = P;
      P = oldP;
      heroType = oldHero;
      held = oldHeld;
      buf = oldBuf;
      B = oldB;
      activePlayerIndex = 0;
    }
  }
  for (let i = 0; i < 46; i++)
    motes.push({
      x: rnd(0, WORLD),
      y: rnd(80, 520),
      vx: rnd(-10, 6),
      vy: rnd(-4, 6),
      s: rnd(1, 2.6),
      ph: rnd(0, 7),
      petal: Math.random() < 0.35,
    });
  const inputOn = () =>
    phase === "fight" || phase === "won" || phase === "lost";

  /* ================= EFFECT HELPERS ================= */
  function spark(x, y, n, col, spd, life, grav) {
    if (impactMuteT > 0) return;
    n = Math.max(1, Math.round(n * qualityFactor()));
    for (let i = 0; i < n; i++) {
      const a = rnd(0, TAU),
        s = rnd(0.3, 1) * spd;
      parts.push({
        k: "spark",
        x,
        y,
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: rnd(0.5, 1) * life,
        t: 0,
        col,
        g: grav === undefined ? 700 : grav,
        drag: 1.5,
        sz: rnd(1.2, 2.6),
      });
    }
  }
  function dust(x, y, n) {
    n = Math.max(1, Math.round(n * qualityFactor()));
    for (let i = 0; i < n; i++)
      parts.push({
        k: "dot",
        x: x + rnd(-14, 14),
        y: y - 2,
        vx: rnd(-60, 60),
        vy: rnd(-60, -10),
        life: rnd(0.3, 0.6),
        t: 0,
        col: "150,140,170",
        g: 0,
        drag: 2,
        sz: rnd(3, 6),
      });
  }
  function petals(x, y, n, spd) {
    n = Math.max(1, Math.round(n * qualityFactor()));
    for (let i = 0; i < n; i++) {
      const a = rnd(-Math.PI, 0),
        s = rnd(0.2, 1) * spd;
      parts.push({
        k: "petal",
        x: x + rnd(-30, 30),
        y: y - rnd(0, 20),
        vx: Math.cos(a) * s,
        vy: Math.sin(a) * s,
        life: rnd(1.4, 2.8),
        t: 0,
        g: 60,
        drag: 0.6,
        rot: rnd(0, 7),
        vr: rnd(-6, 6),
        sz: rnd(2.5, 4.5),
      });
    }
  }
  function addArc(x, y, r, a0, a1, face, life, col, w) {
    fx.push({ k: "arc", x, y, r, a0, a1, face, life, t: 0, col, w });
  }
  function addStreak(x, y, len, col, life) {
    fx.push({ k: "streak", x, y, len, life: life || 0.13, t: 0, col });
  }
  function addRing(x, y, r0, r1, life, col, w) {
    if (impactMuteT > 0) return;
    fx.push({ k: "ring", x, y, r0, r1, life, t: 0, col, w });
  }
  function addText(x, y, txt, col, size, life) {
    fx.push({ k: "text", x, y, txt, col, size, life: life || 1, t: 0 });
  }
  function doShake(v) {
    // Camera jiggle is intentionally disabled for stable frame pacing.
    shake = 0;
  }
  function doFlash(v, col) {
    // Full-screen impact flashes are disabled to avoid white flicker and stalls.
    screenFlash = 0;
  }

  /* ================= PLAYER ================= */
  function startAttack(idx) {
    const A = ATK[idx];
    P.state = "attack";
    P.t = 0;
    P.combo = idx;
    P.hitDone = false;
    P.fxDone = false;
    P.airAtk = P.y < GROUND - 2;
    P.st = Math.max(0, P.st - A.cost);
    P.stDelay = P.st <= 0 ? 1.1 : 0.7;
    const dir = (isActionHeld("right") ? 1 : 0) - (isActionHeld("left") ? 1 : 0);
    if (dir) P.face = dir;
    buf.attack = 0;
  }
  function heroHit(A) {
    if (P.hitDone || B.state === "dead" || B.state === "intro") return;
    const lo = Math.min(P.x - P.face * 8, P.x + P.face * A.reach),
      hi = Math.max(P.x - P.face * 8, P.x + P.face * A.reach);
    const pb = GROUND - P.y;
    const bb = B.h;
    if (
      B.x + B.hw > lo &&
      B.x - B.hw < hi &&
      pb + 125 > bb &&
      pb - 20 < bb + B.hh
    ) {
      P.hitDone = true;
      const dmg = heroType === "ronin" ? (P.flameT > 0 ? 150 : 100) : 120;
      hitBoss(dmg, P.combo === 2 ? 0.08 : 0.04);
    }
  }
  function hitPvpOpponent(dmg, stop) {
    const targetIndex = activePlayerIndex === 0 ? 1 : 0,
      target = players[targetIndex];
    if (!target || target.state === "dead" || target.invuln > 0) return;
    impactMuteT = 0.12;
    // PvP damage is reduced by 50% so local duels last longer.
    dmg = Math.max(1, Math.round(dmg * (P.attackMult || 1) * 0.5));
    if (target.state === "block") dmg = Math.round(dmg * 0.75);
    target.hp = Math.max(0, target.hp - dmg);
    target.ghostDelay = 0.55;
    target.flash = 0;
    target.invuln = target.state === "block" ? 0.28 : 0.48;
    target.vx = P.face * Math.min(520, 160 + dmg * 0.8);
    if (target.state !== "block") {
      target.state = "hurt";
      target.t = 0;
    }
    addText(target.x, target.y - 125, String(dmg), targetIndex ? "#8bc5ff" : "#ffd277", 21, 0.8);
    sfx(target.state === "block" ? "block" : "hit");
    if (target.hp <= 0) {
      target.state = "dead";
      target.deadT = 0;
      pvpWinner = activePlayerIndex + 1;
      phase = "won";
      phaseT = 0;
      doShake(18);
      sfx("die");
    }
  }
  function projectileTarget(projectile) {
    if (gameMode !== "pvp") return B;
    const target = players[(projectile.owner || 0) === 0 ? 1 : 0];
    return {
      x: target.x,
      y: target.y,
      h: Math.max(0, GROUND - target.y),
      hw: 30,
      hh: 138,
      state: target.state,
      type: "pvp",
    };
  }
  function hitProjectileTarget(projectile, dmg, stop, ranged, skill) {
    if (gameMode !== "pvp") return hitBoss(dmg, stop, ranged, skill);
    const oldIndex = activePlayerIndex;
    activePlayerIndex = projectile.owner || 0;
    hitPvpOpponent(dmg, stop);
    activePlayerIndex = oldIndex;
  }
  function hitBoss(dmg, stop, ranged, skill) {
    if (gameMode === "pvp") {
      hitPvpOpponent(dmg, stop);
      return;
    }
    if (
      B.state === "dead" ||
      B.state === "intro" ||
      B.state === "transform" ||
      B.state === "stransform"
    )
      return;
    dmg = Math.max(
      1,
      Math.round(
        dmg * (P.attackMult || 1) * (skill ? P.skillAttackMult || 1 : 1),
      ),
    );
    if (B.type === "shogun" && B.sparryT <= 0 && Math.random() < 0.1) {
      B.sparryT = 0.34;
      sfx("parry");
      doFlash(0.18, B.sphase === 2 ? "80,45,100" : "255,105,35");
      addText(
        B.x,
        GROUND - 225,
        "DEFLECTED",
        B.sphase === 2 ? "#c58cff" : "#ffb16b",
        18,
        0.8,
      );
      addArc(
        B.x,
        GROUND - 105 - B.h,
        105,
        -2.4,
        0.45,
        B.face,
        0.16,
        B.sphase === 2 ? "rgba(130,70,180,.96)" : "rgba(255,105,35,.96)",
        11,
      );
      return;
    }
    if (
      B.type === "shogun" &&
      shogunMinion &&
      shogunMinion.hp > 0 &&
      shogunMinion.state !== "dead" &&
      Math.abs(shogunMinion.x - B.x) < 300
    ) {
      damageShogunMinion(dmg);
      return;
    }
    if (ranged && B.type === "demon" && B.dphase === 3 && Math.random() < 0.1) {
      B.parryT = 0.34;
      sfx("parry");
      doFlash(0.22, "255,70,45");
      addText(B.x, GROUND - 245, "PROJECTILE PARRIED", "#ff8d75", 18, 1);
      addArc(
        B.x,
        GROUND - 110,
        95,
        -2.4,
        0.5,
        B.face,
        0.18,
        "rgba(255,70,45,.95)",
        10,
      );
      return;
    }
    B.hp = Math.max(0, B.hp - dmg);
    impactMuteT = 0.12;
    B.flash = 0;
    B.ghostDelay = 0.6;
    hitstop = Math.max(hitstop, stop || 0.06);
    doShake(5);
    sfx("hit");
    const sx = B.x - B.face * 26,
      sy = GROUND - rnd(70, 110);
    spark(sx, sy, 14, "#ffe2a0", 420, 0.45);
    spark(sx, sy, 6, "#c68bff", 260, 0.5);
    addText(B.x + rnd(-20, 20), GROUND - 165, String(dmg), "#ffd98a", 22, 0.8);
    if (B.type === "demon" && B.hp > 0) {
      if (B.dphase === 1 && B.hp <= B.maxhp * 0.7) beginDemonPhase(2);
      else if (B.dphase === 2 && B.hp <= B.maxhp * 0.3) beginDemonPhase(3);
    } else if (
      B.type === "shogun" &&
      B.sphase === 1 &&
      B.hp <= B.maxhp * 0.5 &&
      B.hp > 0
    ) {
      beginShogunPhase2();
    } else if (
      B.type !== "shogun" &&
      !B.rage &&
      B.hp <= B.maxhp * 0.5 &&
      B.hp > 0
    ) {
      B.rage = true;
      musicIntensify();
      const art = B.type === "art";
      doFlash(0.5, art ? "120,170,255" : "170,80,255");
      doShake(16);
      sfx("roar");
      addText(
        B.x,
        GROUND - 200 - (art ? 30 : 0),
        art ? "PHASE TWO  +40% DAMAGE" : "THE SENTINEL IS ENRAGED",
        art ? "#a9cdff" : "#d9a8ff",
        20,
        2,
      );
      addRing(
        B.x,
        GROUND - 70,
        20,
        300,
        0.7,
        art ? "rgba(140,190,255,.9)" : "rgba(190,120,255,.9)",
        8,
      );
    }
    if (B.hp <= 0) bossDie();
  }
  function bossDie() {
    awardCoins(200);
    orbs.length = 0;
    demonHazards.length = 0;
    shogunHazards.length = 0;
    shogunMinion = null;
    B.state = "dead";
    B.dieT = 0;
    B.phase = "";
    hitstop = 0.35;
    doShake(20);
    doFlash(0.7, "255,255,255");
    sfx("die");
    phase = "won";
    phaseT = 0;
  }
  function startDodge(dir) {
    P.state = "dodge";
    P.t = 0;
    P.dodgeDir = dir || P.face;
    P.face = P.dodgeDir;
    P.invuln = Math.max(P.invuln, 0.27);
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.55;
    buf.dodge = 0;
    sfx("dodge");
    dust(P.x, GROUND, 5);
  }
  function startAirDodge(dir) {
    P.state = "airdash";
    P.t = 0;
    P.airDodged = true;
    P.dodgeDir = dir || P.face;
    P.face = P.dodgeDir;
    P.invuln = Math.max(P.invuln, 0.24);
    P.st = Math.max(0, P.st - 20);
    P.stDelay = 0.55;
    buf.dodge = 0;
    P.vy = 0;
    sfx("dodge");
    spark(P.x, P.y - 55, 10, "#ffe2a0", 300, 0.3, 0);
  }
  function startParry() {
    P.state = "parry";
    P.t = 0;
    P.parrySucc = false;
    P.endT = heroType === "ronin" ? 0.72 : 0.62;
    P.st = Math.max(0, P.st - 8);
    P.stDelay = 0.5;
    buf.parry = 0;
    P.vx *= 0.3;
    const dir = (isActionHeld("right") ? 1 : 0) - (isActionHeld("left") ? 1 : 0);
    if (dir) P.face = dir;
    tone(700, 0.1, "triangle", 0.06, 200);
  }
  function startPlunge() {
    P.state = "plunge";
    P.t = 0;
    P.vy = 1050;
    P.vx = 0;
    P.plungeHit = false;
    P.st = Math.max(0, P.st - 18);
    P.stDelay = 0.7;
    buf.attack = 0;
    sfx("plunge");
  }
  function startHeal() {
    P.state = "heal";
    P.t = 0;
    P.healed = false;
    buf.heal = 0;
  }
  function startSkill1(dir) {
    P.state = "skill1";
    P.t = 0;
    P.skill1Fired = false;
    P.skill1CD = SKILL1_CD;
    buf.skill1 = 0;
    if (dir) P.face = dir;
    P.vx *= 0.3;
  }
  function fireSlash() {
    sfx("skill1");
    const pb = GROUND - P.y;
    slashes.push({
      owner: activePlayerIndex,
      x: P.x + P.face * 30,
      y: P.y - 78,
      face: P.face,
      vx: P.face * 1500,
      life: 1.1,
      t: 0,
      hit: false,
      pb,
      rot: 0,
    });
    addArc(
      P.x,
      P.y - 82,
      92,
      P.face > 0 ? -2.3 : -0.85,
      P.face > 0 ? 0.85 : 2.3,
      P.face,
      0.16,
      "rgba(255,232,140,.95)",
      10,
    );
    spark(P.x + P.face * 26, P.y - 78, 16, "#fff3b0", 460, 0.4);
  }
  function startSkill2(dir) {
    P.state = "skill2";
    P.t = 0;
    P.skill2Fired = false;
    P.skill2Hit = false;
    P.skill2CD = SKILL2_CD;
    buf.skill2 = 0;
    if (dir) P.face = dir;
    P.vx = 0;
    sfx("charge");
  }
  function releaseSkill2() {
    sfx("skill2");
    doShake(22);
    doFlash(0.6, "255,170,90");
    const ox = P.x + P.face * 34,
      oy = P.y - 46,
      R = 200;
    addRing(ox, oy, 16, R, 0.5, "rgba(255,200,120,.95)", 11);
    addRing(ox, oy, 8, R * 0.7, 0.4, "rgba(255,90,40,.85)", 15);
    spark(ox, oy, 46, "#ffcf7a", 700, 0.7, 260);
    spark(ox, oy, 22, "#ff5a30", 520, 0.55, 300);
    dust(ox, GROUND, 20);
    petals(ox, GROUND, 30, 500);
    const reach = B.hw + 150,
      bb = B.h;
    const pb = GROUND - P.y;
    if (
      B.state !== "dead" &&
      B.state !== "intro" &&
      Math.abs(B.x - ox) < reach &&
      pb + 140 > bb &&
      pb - 30 < bb + B.hh
    ) {
      P.skill2Hit = true;
      hitBoss(800, 0.16, false, true);
      if (B.state !== "dead") {
        B.state = "stunned";
        B.stunT = 2.2;
        B.phase = "";
        B.combo = null;
        B.hitDone = true;
      }
      addText(
        B.x,
        GROUND - (B.type === "art" ? 195 : 175),
        "STAGGERED",
        "#ffcf7a",
        24,
        1.1,
      );
    }
  }
  function hurtPlayer(dmg, srcX, heavy) {
    if (P.state === "dead" || P.invuln > 0) return false;
    impactMuteT = 0.12;
    if (heroType === "wizard" && skeletons.length) {
      let guard = null,
        best = Infinity;
      for (const s of skeletons) {
        if (s.hp <= 0 || s.state === "spawn") continue;
        const d = Math.abs(s.x - srcX);
        if (d < best && d < 145) {
          guard = s;
          best = d;
        }
      }
      if (guard) {
        damageSkeleton(guard, dmg);
        return true;
      }
    }
    if (
      heroType === "ronin" &&
      P.state === "parry" &&
      !P.parrySucc &&
      P.t < RONIN_DEFLECT_WIN
    ) {
      roninDeflectSuccess(P.x + P.face * 24, P.y - 68);
      return true;
    }
    dmg = Math.max(
      0,
      Math.round(dmg * (P.defenseMult == null ? 1 : P.defenseMult) * (heroType === "killnux" && P.killArmorT > 0 ? 0.8 : 1)),
    );
    if (P.state === "block") {
      dmg = Math.round(dmg * 0.75);
      P.hp = Math.max(0, P.hp - dmg);
      P.ghostDelay = 0.6;
      P.invuln = heavy ? 0.6 : 0.35;
      P.blockFlash = 0.2;
      P.vx = (P.x < srcX ? -1 : 1) * (heavy ? 420 : 200);
      sfx("block");
      addText(P.x, P.y - 118, String(dmg), "#9fd0ff", 22, 0.8);
      if (P.hp <= 0) {
        P.state = "dead";
        P.deadT = 0;
        sfx("die");
        if (!(gameMode === "coop" && players.some((p) => p !== P && p.hp > 0))) {
          phase = "lost";
          phaseT = 0;
        }
      }
      return true;
    }
    P.hp = Math.max(0, P.hp - dmg);
    P.flash = 0;
    P.ghostDelay = 0.6;
    P.invuln = heavy ? 0.8 : 0.5;
    if (P.state === "rskill1") B.execMark = null;
    P.state = "hurt";
    P.t = 0;
    P.vx = (P.x < srcX ? -1 : 1) * (heavy ? 520 : 280);
    if (heavy) P.vy = -330;
    sfx("hurt");
    addText(P.x, P.y - 118, String(dmg), "#ff6a5a", 24, 0.9);
    if (P.hp <= 0) {
      P.state = "dead";
      P.deadT = 0;
      sfx("die");
      if (!(gameMode === "coop" && players.some((p) => p !== P && p.hp > 0))) {
        phase = "lost";
        phaseT = 0;
      }
    }
    return true;
  }
  function roninDeflectSuccess(hx, hy) {
    P.parrySucc = true;
    P.endT = P.t + 0.24;
    P.st = Math.min(P.maxst, P.st + 18);
    P.parryFlash = 0.3;
    P.invuln = Math.max(P.invuln, 0.18);
    P.deflects = (P.deflects || 0) + 1;
    hitstop = 0.14;
    doShake(8);
    doFlash(0.25, "255,65,85");
    sfx("parry");
    spark(hx, hy, 30, "#ffb2bc", 620, 0.55);
    spark(hx, hy, 18, "#ff244c", 460, 0.5);
    addRing(hx, hy, 5, 82, 0.3, "rgba(255,55,85,.95)", 5);
    if (P.deflects >= 15) {
      P.deflects = 0;
      hitBoss(600, 0.2);
      if (B.state !== "dead") {
        B.state = "stunned";
        B.stunT = 2.5;
        B.phase = "";
        B.combo = null;
        B.hitDone = true;
      }
      addText(
        B.x,
        GROUND - (B.type === "art" ? 205 : B.type === "demon" ? 245 : 180),
        "15 DEFLECTS — 600",
        "#ff697f",
        24,
        1.25,
      );
      doShake(18);
    } else
      addText(
        P.x,
        P.y - 132,
        "DEFLECT " + P.deflects + " / 15",
        "#ff91a2",
        21,
        0.9,
      );
  }
  function parrySuccess(hx, hy) {
    P.parrySucc = true;
    P.endT = P.t + 0.22;
    P.st = Math.min(P.maxst, P.st + 30);
    P.parryFlash = 0.25;
    B.state = "stunned";
    B.stunT = 2.0;
    B.phase = "";
    B.combo = null;
    B.hitDone = true;
    hitstop = 0.17;
    doShake(11);
    doFlash(0.4, "255,235,190");
    sfx("parry");
    spark(hx, hy, 30, "#fff2c8", 620, 0.6);
    spark(hx, hy, 14, "#ffb84a", 420, 0.5);
    addRing(hx, hy, 6, 90, 0.35, "rgba(255,240,190,.95)", 5);
    addText(P.x, P.y - 130, "PARRIED", "#ffe9a8", 26, 1.1);
  }
  function updatePlayer(dt) {
    const live = inputOn();
    const dir = live ? (isActionHeld("right") ? 1 : 0) - (isActionHeld("left") ? 1 : 0) : 0;
    if (!live) {
      buf.attack = buf.parry = buf.dodge = buf.jump = buf.heal = 0;
    }
    if (P.state === "dead") {
      P.deadT += dt;
      P.vx *= 0.9;
      physics(dt);
      return;
    }
    P.t += dt;
    P.invuln = Math.max(0, P.invuln - dt);
    P.flash = Math.max(0, P.flash - dt);
    P.parryFlash = Math.max(0, P.parryFlash - dt);
    P.blockFlash = Math.max(0, P.blockFlash - dt);
    P.landT = Math.max(0, P.landT - dt);
    const grounded = P.y >= GROUND - 0.5;
    P.stride += (grounded ? Math.abs(P.vx) : 0) * dt * 0.05;
    if (P.stDelay > 0) P.stDelay -= dt;
    else if (
      P.state !== "dodge" &&
      P.state !== "attack" &&
      P.state !== "airdash"
    )
      P.st = Math.min(
        P.maxst,
        P.st +
          (P.state === "free" ? 40 : P.state === "block" ? 32 : 22) *
            (P.staminaRegenMult || 1) *
            dt,
      );
    const cdStep = dt * (P.skillRate || 1);
    P.skill1CD = Math.max(0, P.skill1CD - cdStep);
    P.skill2CD = Math.max(0, P.skill2CD - cdStep);
    P.flameT = Math.max(0, (P.flameT || 0) - dt);
    P.killArmorT = Math.max(0, (P.killArmorT || 0) - dt);

    switch (P.state) {
      case "free": {
        const target = dir * 250;
        P.vx += (target - P.vx) * Math.min(1, dt * (grounded ? 16 : 7));
        if (dir) P.face = dir;
        if (buf.jump > 0 && grounded) {
          P.vy = -JUMPV;
          buf.jump = 0;
          sfx("jump");
          dust(P.x, GROUND, 4);
        }
        if (buf.dodge > 0 && P.st > 0 && (grounded || !P.airDodged)) {
          if (heroType === "killnux" && grounded) startKillDodge(dir);
          else if (heroType === "ronin" || heroType === "wizard") startRoninDodge(dir);
          else if (grounded) startDodge(dir);
          else startAirDodge(dir);
        } else if (heroType === "killnux") {
          if (buf.attack > 0 && grounded && P.st >= 30) startKillAttack(0);
          else if (buf.heal > 0 && grounded && P.flasks > 0 && P.hp < P.maxhp) startHeal();
          else if (buf.skill1 > 0 && grounded && P.skill1CD <= 0) startKillSkill1(dir);
          else if (buf.skill2 > 0 && grounded && P.skill2CD <= 0) startKillSkill2();
          else if (isActionHeld("block") && grounded) { P.state = "block"; P.t = 0; }
        } else if (heroType === "shadow") {
          if (buf.parry > 0 && grounded && P.st > 0) startTeleport(dir);
          else if (buf.attack > 0 && P.st > 0) startShot(dir);
          else if (buf.heal > 0 && grounded && P.flasks > 0 && P.hp < P.maxhp)
            startHeal();
          else if (buf.skill1 > 0 && grounded && P.skill1CD <= 0)
            startRangerSkill1();
          else if (buf.skill2 > 0 && grounded && P.skill2CD <= 0)
            startRangerSkill2();
          else if (isActionHeld("block") && grounded) {
            P.state = "block";
            P.t = 0;
          }
        } else if (heroType === "ronin") {
          if (buf.parry > 0 && grounded) startParry();
          else if (buf.attack > 0 && P.st > 0) startAttack(0);
          else if (buf.heal > 0 && grounded && P.flasks > 0 && P.hp < P.maxhp)
            startHeal();
          else if (buf.skill1 > 0 && grounded && P.skill1CD <= 0)
            startRoninSkill1();
          else if (buf.skill2 > 0 && grounded && P.skill2CD <= 0)
            startRoninSkill2();
          else if (isActionHeld("block") && grounded) {
            P.state = "block";
            P.t = 0;
          }
        } else if (heroType === "regal") {
          if (buf.parry > 0 && P.st >= 20) startRegalGun(dir);
          else if (buf.attack > 0 && P.st >= 20) startRegalSword(dir);
          else if (buf.heal > 0 && grounded && P.flasks > 0 && P.hp < P.maxhp)
            startHeal();
          else if (buf.skill1 > 0 && grounded && P.skill1CD <= 0)
            startRegalSkill1();
          else if (buf.skill2 > 0 && grounded && P.skill2CD <= 0)
            startRegalSkill2();
          else if (isActionHeld("block") && grounded) {
            P.state = "block";
            P.t = 0;
          }
        } else if (heroType === "wizard") {
          if (buf.parry > 0 && grounded && P.st >= 10) startWizardSword(dir);
          else if (buf.attack > 0 && P.st >= 20) startWizardMissile(dir);
          else if (buf.heal > 0 && grounded && P.flasks > 0 && P.hp < P.maxhp)
            startHeal();
          else if (buf.skill1 > 0 && grounded && P.skill1CD <= 0)
            startWizardSummon();
          else if (buf.skill2 > 0 && grounded && P.skill2CD <= 0)
            startWizardBeam();
          else if (isActionHeld("block") && grounded) {
            P.state = "block";
            P.t = 0;
          }
        } else {
          if (buf.parry > 0 && grounded && P.st > 0) startParry();
          else if (buf.attack > 0 && P.st > 0) {
            if (!grounded && isActionHeld("down")) startPlunge();
            else startAttack(0);
          } else if (buf.heal > 0 && grounded && P.flasks > 0 && P.hp < P.maxhp)
            startHeal();
          else if (buf.skill1 > 0 && grounded && P.skill1CD <= 0)
            startSkill1(dir);
          else if (buf.skill2 > 0 && grounded && P.skill2CD <= 0)
            startSkill2(dir);
          else if (isActionHeld("block") && grounded) {
            P.state = "block";
            P.t = 0;
          }
        }
        break;
      }
      case "attack": {
        const A = ATK[P.combo],
          tot = A.w + A.a + A.r;
        if (P.t < A.w + A.a)
          P.vx = P.airAtk ? P.vx * 0.98 : (P.face * A.lunge) / (A.w + A.a);
        else P.vx *= 0.8;
        if (
          !P.airAtk &&
          B.state !== "dead" &&
          (B.x - P.x) * P.face > 0 &&
          Math.abs(B.x - P.x) < 62
        )
          P.vx = 0;
        if (!P.fxDone && P.t >= A.w) {
          P.fxDone = true;
          sfx("swing");
          const roninFx = heroType === "ronin";
          if (A.thrust)
            addStreak(
              P.x + P.face * 24,
              P.y - 64,
              P.face * (A.reach - 20),
              roninFx ? "rgba(255,35,70,.98)" : "rgba(255,232,170,.95)",
            );
          else {
            addArc(
              P.x,
              P.y - 82,
              84,
              A.a0,
              A.a1,
              P.face,
              0.13,
              roninFx ? "rgba(255,35,70,.96)" : "rgba(255,214,140,.9)",
              9,
            );
            if (roninFx)
              addArc(
                P.x,
                P.y - 70,
                72,
                -A.a1,
                -A.a0,
                P.face,
                0.13,
                "rgba(255,115,135,.85)",
                7,
              );
          }
        }
        if (P.t >= A.w && P.t < A.w + A.a) heroHit(A);
        if (
          P.t >= A.w + A.a + A.r * 0.6 &&
          buf.attack > 0 &&
          P.st > 0 &&
          P.combo < 2
        ) {
          startAttack(P.combo + 1);
          break;
        }
        if (
          P.t >= A.w + A.a &&
          buf.dodge > 0 &&
          P.st > 0 &&
          (grounded || !P.airDodged)
        ) {
          if (heroType === "ronin") startRoninDodge(dir);
          else if (grounded) startDodge(dir);
          else startAirDodge(dir);
          break;
        }
        if (P.t >= A.w + A.a && buf.parry > 0 && grounded && P.st > 0) {
          startParry();
          break;
        }
        if (P.t >= tot) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "killSkill1": {
        P.vx *= .75;
        if (!P.killSkillFired && P.t >= .52) { P.killSkillFired = true; releaseKillWave(); }
        if (P.t >= 1.16) { P.state = "free"; P.t = 0; }
        break;
      }
      case "killTransform": {
        P.vx = 0;
        if (Math.random() < .85) {
          const a=rnd(0,TAU), rr=rnd(35,95);
          parts.push({k:"gather",sx:P.x+Math.cos(a)*rr,sy:P.y-70+Math.sin(a)*rr,tx:P.x,ty:P.y-72,life:.38,t:0,x:0,y:0,gc:"45,35,60"});
        }
        if (!P.killSkillFired && P.t >= .65) {
          P.killSkillFired = true; P.killArmorT = 20;
          doShake(18); doFlash(.5,"25,20,35"); sfx("demonRoar");
          addRing(P.x,P.y-72,12,150,.55,"rgba(55,45,70,.9)",10);
          spark(P.x,P.y-70,48,"#51455f",600,.8,-60);
          addText(P.x,P.y-145,"BLACK ARMOUR","#c7b9d6",22,1.2);
        }
        if (P.t >= 1.35) { P.state = "free"; P.t = 0; }
        break;
      }
      case "killAttack": {
        const A = KILL_ATK[P.combo], total = A.w + A.a + A.r;
        if (P.t < A.w) P.vx *= 0.84;
        else if (P.t < A.w + A.a) P.vx = P.face * A.lunge / A.a;
        else P.vx *= 0.76;
        if (!P.fxDone && P.t >= A.w) {
          P.fxDone = true; sfx("swing"); doShake(5);
          addArc(P.x + P.face * 10, P.y - 82, 122, A.a0, A.a1, P.face, .2, "rgba(210,220,230,.9)", 15);
          addArc(P.x + P.face * 8, P.y - 82, 104, A.a0, A.a1, P.face, .16, "rgba(75,82,92,.75)", 7);
        }
        if (P.t >= A.w && P.t < A.w + A.a) killnuxStrike(A);
        if (P.t >= A.w + A.a + A.r * .62 && buf.attack > 0 && P.combo < 2 && P.st >= 30) {
          startKillAttack(P.combo + 1); break;
        }
        if (P.t >= A.w + A.a && buf.dodge > 0 && P.st >= 20) { startKillDodge(dir); break; }
        if (P.t >= total) { P.state = "free"; P.t = 0; }
        break;
      }
      case "killDodge": {
        const k = clamp(P.t / .4, 0, 1);
        P.vx = P.dodgeDir * 840 * (1 - k * .4);
        if (Math.random() < .7) dust(P.x - P.dodgeDir * 16, GROUND, 1);
        if (P.t >= .4) { P.state = "free"; P.t = 0; P.vx *= .28; }
        break;
      }
case "airdash": {
        const k = P.t / 0.26;
        P.vx = P.dodgeDir * 680 * (1 - k * 0.45);
        P.vy = 0;
        parts.push({
          k: "dot",
          x: P.x,
          y: P.y - rnd(30, 80),
          vx: 0,
          vy: 0,
          life: 0.28,
          t: 0,
          col: "255,224,160",
          g: 0,
          drag: 1,
          sz: rnd(4, 8),
        });
        if (P.t >= 0.26) {
          P.state = "free";
          P.t = 0;
          P.vx *= 0.45;
          P.vy = 80;
        }
        break;
      }
      case "wizardMissile": {
        P.vx *= 0.84;
        if (!P.shotFired && P.t >= 0.11) {
          P.shotFired = true;
          fireWizardMissile();
        }
        if (P.t >= 0.3) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "wizardSword": {
        P.vx *= 0.8;
        if (!P.wizardFx && P.t >= 0.07) {
          P.wizardFx = true;
          addArc(
            P.x + P.face * 12,
            P.y - 70,
            95,
            -2.1,
            0.75,
            P.face,
            0.22,
            "rgba(100,215,255,.95)",
            10,
          );
          sfx("swing");
        }
        if (
          !P.wizardHit &&
          P.t >= 0.12 &&
          Math.abs(B.x - P.x) < B.hw + 105 &&
          B.state !== "dead"
        ) {
          P.wizardHit = true;
          hitBoss(70, 0.055, false, false);
          spark(B.x, P.y - 72, 16, "#8de7ff", 360, 0.38, 0);
        }
        if (P.t >= 0.36) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "wizardSummon": {
        P.vx = 0;
        if (!P.skill1Fired && P.t >= 0.4) {
          P.skill1Fired = true;
          summonSkeletons();
        }
        if (P.t >= 0.82) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "wizardBeam": {
        P.vx = 0;
        P.face = B.x >= P.x ? 1 : -1;
        if (!P.skill2Hit && P.t >= 1.05) {
          P.skill2Hit = true;
          hitBoss(1000, 0.18, true, true);
          spark(B.x, GROUND - 95, 55, "#69d9ff", 720, 0.62, 0);
          addRing(B.x, GROUND - 95, 12, 105, 0.45, "rgba(100,220,255,.95)", 8);
          doShake(14);
          doFlash(0.26, "90,190,255");
          sfx("explode");
        }
        if (P.t >= 1.65) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "regalSword": {
        P.vx *= 0.82;
        if (!P.regalFx && P.t >= 0.1) {
          P.regalFx = true;
          sfx("swing");
          addArc(
            P.x,
            P.y - 76,
            92,
            -2.4,
            0.9,
            P.face,
            0.18,
            "rgba(255,210,105,.96)",
            10,
          );
        }
        if (
          !P.regalHit &&
          P.t >= 0.12 &&
          P.t < 0.27 &&
          B.state !== "dead" &&
          B.state !== "intro" &&
          Math.abs(B.x - (P.x + P.face * 55)) < B.hw + 76
        ) {
          P.regalHit = true;
          hitBoss(90, 0.07, false, false);
        }
        if (P.t >= 0.38) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "regalGun": {
        P.vx *= 0.86;
        if (!P.shotFired && P.t >= 0.09) {
          P.shotFired = true;
          fireRegalShot();
        }
        if (P.t >= 0.28) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "regalOrb": {
        P.vx = 0;
        if (P.t < 0.28 && Math.random() < 0.8)
          parts.push({
            k: "gather",
            sx: P.x + rnd(-80, 80),
            sy: P.y - rnd(30, 130),
            tx: P.x + P.face * 28,
            ty: P.y - 88,
            life: 0.3,
            t: 0,
            gc: "120,70,190",
          });
        if (!P.regalOrbFired && P.t >= 0.28) {
          P.regalOrbFired = true;
          castRegalOrb();
        }
        if (P.t >= 0.6) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "regalBeam": {
        P.vx = 0;
        if (P.t < 0.18 && Math.random() < 0.9)
          parts.push({
            k: "gather",
            sx: P.x + rnd(-100, 100),
            sy: P.y - rnd(15, 145),
            tx: P.x + P.face * 30,
            ty: P.y - 72,
            life: 0.2,
            t: 0,
            gc: "95,40,150",
          });
        if (!P.regalBeamFired && P.t >= 0.18) {
          P.regalBeamFired = true;
          fireRegalBeam();
        }
        if (P.t >= 0.55) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "shot": {
        P.vx *= 0.85;
        if (!P.shotFired && P.t >= 0.06) {
          P.shotFired = true;
          fireBasicArrow();
        }
        if (P.t >= 0.16) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "teleport": {
        P.vx = 0;
        P.vy = 0;
        if (P.rt === "wind") {
          if (P.t >= 0.07) {
            P.rt = "jump";
            const oldX = P.x,
              dist = 260 * P.teleDir;
            P.x = clamp(P.x + dist, 40, WORLD - 40);
            const rc = heroType === "ronin",
              wc = heroType === "wizard";
            spark(
              oldX,
              P.y - 55,
              20,
              rc ? "#ff244c" : wc ? "#258cff" : "#5a3aa8",
              380,
              0.5,
              0,
            );
            spark(
              P.x,
              P.y - 55,
              16,
              rc ? "#ff9aaa" : wc ? "#9ce8ff" : "#bdf3f0",
              420,
              0.45,
              0,
            );
            addRing(
              oldX,
              P.y - 58,
              6,
              70,
              0.35,
              rc
                ? "rgba(255,25,65,.75)"
                : wc
                  ? "rgba(35,145,255,.85)"
                  : "rgba(90,50,180,.7)",
              4,
            );
            addRing(
              P.x,
              P.y - 58,
              6,
              82,
              0.35,
              rc
                ? "rgba(255,110,135,.9)"
                : wc
                  ? "rgba(145,230,255,.95)"
                  : "rgba(150,240,235,.9)",
              5,
            );
            sfx("dodge");
            P.t = 0;
          }
        } else if (P.t >= 0.16) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "rskill1": {
        if (P.rPhase === "dash") {
          const k = Math.min(1, P.t / 0.22);
          P.x = lerp(P.rStartX, P.rTargetX, easeOut(k));
          P.vx = 0;
          if (Math.random() < 0.8)
            parts.push({
              k: "dot",
              x: P.x,
              y: P.y - rnd(20, 70),
              vx: 0,
              vy: 0,
              life: 0.22,
              t: 0,
              col: "120,80,200",
              g: 0,
              drag: 1,
              sz: rnd(3, 7),
            });
          if (
            !P.rHit100 &&
            k >= 0.5 &&
            B.state !== "dead" &&
            B.state !== "intro"
          ) {
            P.rHit100 = true;
            hitBoss(100, 0.08, false, true);
            spark(B.x, GROUND - 90, 16, "#bdf3f0", 420, 0.4);
          }
          if (k >= 1) {
            P.rPhase = "barrage";
            P.t = 0;
            P.rArrows = 0;
            P.rNextArrow = 0;
          }
        } else if (P.rPhase === "barrage") {
          P.vx = 0;
          if (P.rArrows < 20 && P.t >= P.rNextArrow) {
            P.rArrows++;
            P.rNextArrow = P.t + 0.045;
            if (B.state !== "dead" && B.state !== "intro") {
              const pb = GROUND - P.y;
              arrows.push({
                owner: activePlayerIndex,
                x: P.x + P.face * 26,
                y: P.y - 82 + rnd(-8, 8),
                vx: P.face * 1500,
                life: 0.6,
                t: 0,
                hit: false,
                pb,
                dmg: 20,
                kind: "barrage",
              });
            }
            B.execMark = P.rArrows / 20;
            sfx("shot");
          }
          if (P.rArrows >= 20 && P.t >= P.rNextArrow + 0.05) {
            P.rPhase = "drop";
            P.t = 0;
          }
        } else if (P.rPhase === "drop") {
          if (P.t >= 0.18 && !P.rDropped) {
            P.rDropped = true;
            if (B.state !== "dead" && B.state !== "intro") {
              B.state = "stunned";
              B.stunT = 2.2;
              B.phase = "";
              B.combo = null;
              B.hitDone = true;
              addText(
                B.x,
                GROUND - (B.type === "art" ? 195 : 175),
                "EXPOSED",
                "#8ef0ea",
                24,
                1.1,
              );
            }
            B.execMark = null;
            doShake(14);
            doFlash(0.4, "140,230,225");
          }
          if (P.t >= 0.34) {
            P.state = "free";
            P.t = 0;
            P.rPhase = "";
          }
        }
        break;
      }
      case "rain2": {
        P.vx *= 0.7;
        if (!P.rainFired && P.t >= 0.3) {
          P.rainFired = true;
          launchRain();
        }
        if (P.t >= 0.42) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "roninLunge": {
        const k = Math.min(1, P.t / 0.34);
        P.x = lerp(P.roninStartX, P.roninTargetX, easeOut(k));
        P.vx = 0;
        if (Math.random() < 0.9)
          parts.push({
            k: "dot",
            x: P.x - P.face * rnd(5, 48),
            y: P.y - rnd(25, 95),
            vx: -P.face * rnd(80, 220),
            vy: rnd(-20, 20),
            life: 0.24,
            t: 0,
            col: "255,35,70",
            g: 0,
            drag: 1,
            sz: rnd(2, 6),
          });
        if (
          !P.roninHit &&
          k >= 0.48 &&
          B.state !== "dead" &&
          B.state !== "intro"
        ) {
          P.roninHit = true;
          if (Math.abs(B.x - P.x) < B.hw + 150) hitBoss(300, 0.14, false, true);
          addStreak(
            P.x - P.face * 35,
            P.y - 78,
            P.face * 190,
            "rgba(255,40,75,.98)",
            0.2,
          );
          addArc(
            B.x,
            GROUND - 100,
            120,
            -2.5,
            0.55,
            P.face,
            0.2,
            "rgba(255,70,95,.95)",
            13,
          );
        }
        if (k >= 1) {
          P.state = "free";
          P.t = 0;
          P.vx = P.face * 80;
        }
        break;
      }
      case "roninFlame": {
        P.vx = 0;
        const k = clamp(P.t / 0.72, 0, 1);
        if (Math.random() < 0.9)
          spark(
            P.x + rnd(-22, 22),
            P.y - rnd(35, 100),
            1,
            Math.random() < 0.5 ? "#ff244c" : "#ff9a45",
            150,
            0.35,
            -80,
          );
        if (P.t >= 0.48 && P.flameT <= 0) {
          P.flameT = 20;
          doFlash(0.38, "255,35,65");
          doShake(10);
          sfx("skill2");
          addText(
            P.x,
            P.y - 140,
            "BLOODFLAME — +50 DAMAGE",
            "#ff657d",
            20,
            1.2,
          );
        }
        if (P.t >= 0.72) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "skill1": {
        P.vx *= 0.8;
        if (!P.skill1Fired && P.t >= 0.1) {
          P.skill1Fired = true;
          fireSlash();
        }
        if (P.t >= 0.3) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "skill2": {
        P.vx *= 0.7;
        if (P.t < 0.55 && Math.random() < 0.7)
          parts.push({
            k: "dot",
            x: P.x + P.face * 14 + rnd(-6, 6),
            y: P.y - 62 + rnd(-8, 8),
            vx: rnd(-8, 8),
            vy: rnd(-32, -6),
            life: 0.35,
            t: 0,
            col: "255,150,60",
            g: 0,
            drag: 1,
            sz: rnd(2, 5),
          });
        if (!P.skill2Fired && P.t >= 0.55) {
          P.skill2Fired = true;
          releaseSkill2();
        }
        if (P.t >= 0.82) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "block": {
        if (dir) P.face = dir;
        P.vx += (dir * 90 - P.vx) * Math.min(1, dt * 14);
        if (buf.jump > 0 && grounded) {
          P.vy = -JUMPV;
          buf.jump = 0;
          sfx("jump");
          dust(P.x, GROUND, 4);
          P.state = "free";
          P.t = 0;
          break;
        }
        if (buf.dodge > 0 && P.st > 0) {
          if (heroType === "killnux") startKillDodge(dir);
          else if (heroType === "ronin" || heroType === "wizard") startRoninDodge(dir);
          else startDodge(dir);
          break;
        }
        if (heroType === "killnux") {
          if (buf.attack > 0 && P.st >= 30) { startKillAttack(0); break; }
          if (buf.heal > 0 && P.flasks > 0 && P.hp < P.maxhp) { startHeal(); break; }
          if (buf.skill1 > 0 && P.skill1CD <= 0) { startKillSkill1(dir); break; }
          if (buf.skill2 > 0 && P.skill2CD <= 0) { startKillSkill2(); break; }
        } else if (heroType === "shadow") {
          if (buf.parry > 0 && P.st > 0) {
            startTeleport(dir);
            break;
          }
          if (buf.attack > 0 && P.st > 0) {
            startShot(dir);
            break;
          }
          if (buf.heal > 0 && P.flasks > 0 && P.hp < P.maxhp) {
            startHeal();
            break;
          }
          if (buf.skill1 > 0 && P.skill1CD <= 0) {
            startRangerSkill1();
            break;
          }
          if (buf.skill2 > 0 && P.skill2CD <= 0) {
            startRangerSkill2();
            break;
          }
        } else if (heroType === "ronin") {
          if (buf.parry > 0) {
            startParry();
            break;
          }
          if (buf.attack > 0 && P.st > 0) {
            startAttack(0);
            break;
          }
          if (buf.heal > 0 && P.flasks > 0 && P.hp < P.maxhp) {
            startHeal();
            break;
          }
          if (buf.skill1 > 0 && P.skill1CD <= 0) {
            startRoninSkill1();
            break;
          }
          if (buf.skill2 > 0 && P.skill2CD <= 0) {
            startRoninSkill2();
            break;
          }
        } else if (heroType === "regal") {
          if (buf.parry > 0 && P.st >= 20) {
            startRegalGun(dir);
            break;
          }
          if (buf.attack > 0 && P.st >= 20) {
            startRegalSword(dir);
            break;
          }
          if (buf.heal > 0 && P.flasks > 0 && P.hp < P.maxhp) {
            startHeal();
            break;
          }
          if (buf.skill1 > 0 && P.skill1CD <= 0) {
            startRegalSkill1();
            break;
          }
          if (buf.skill2 > 0 && P.skill2CD <= 0) {
            startRegalSkill2();
            break;
          }
        } else if (heroType === "wizard") {
          if (buf.parry > 0 && P.st >= 10) {
            startWizardSword(dir);
            break;
          }
          if (buf.attack > 0 && P.st >= 20) {
            startWizardMissile(dir);
            break;
          }
          if (buf.heal > 0 && P.flasks > 0 && P.hp < P.maxhp) {
            startHeal();
            break;
          }
          if (buf.skill1 > 0 && P.skill1CD <= 0) {
            startWizardSummon();
            break;
          }
          if (buf.skill2 > 0 && P.skill2CD <= 0) {
            startWizardBeam();
            break;
          }
        } else {
          if (buf.parry > 0 && P.st > 0) {
            startParry();
            break;
          }
          if (buf.attack > 0 && P.st > 0) {
            startAttack(0);
            break;
          }
          if (buf.heal > 0 && P.flasks > 0 && P.hp < P.maxhp) {
            startHeal();
            break;
          }
          if (buf.skill1 > 0 && P.skill1CD <= 0) {
            startSkill1(dir);
            break;
          }
          if (buf.skill2 > 0 && P.skill2CD <= 0) {
            startSkill2(dir);
            break;
          }
        }
        if (!isActionHeld("block") || !grounded) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "dodge": {
        const k = P.t / 0.34;
        P.vx = P.dodgeDir * 720 * (1 - k * 0.55);
        if (Math.random() < 0.5) dust(P.x - P.dodgeDir * 10, GROUND, 1);
        if (P.t >= 0.34) {
          P.state = "free";
          P.t = 0;
          P.vx *= 0.3;
        }
        break;
      }
      case "parry": {
        P.vx *= 0.8;
        if (P.t >= P.endT) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "plunge": {
        P.vx = 0;
        P.vy = 1050;
        const pb = GROUND - P.y;
        if (
          !P.plungeHit &&
          B.state !== "dead" &&
          B.state !== "intro" &&
          Math.abs(P.x - B.x) < B.hw + 18 &&
          pb < B.h + B.hh + 4 &&
          pb > B.h + 10
        ) {
          P.plungeHit = true;
          hitBoss(120, 0.09);
          P.state = "free";
          P.t = 0;
          P.vy = -560;
          P.vx = -P.face * 120;
          spark(P.x, P.y, 10, "#ffe2a0", 400, 0.4);
        }
        break;
      }
      case "hurt": {
        P.vx *= 0.92;
        if (P.t > 0.3) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
      case "heal": {
        P.vx = dir * 60;
        if (!P.healed && P.t >= 0.5) {
          P.healed = true;
          P.flasks--;
          const before = P.hp;
          P.hp = Math.min(
            P.maxhp,
            P.hp + Math.round(P.maxhp * 0.7 * (P.healMult || 1)),
          );
          sfx("heal");
          addText(
            P.x,
            P.y - 125,
            "+" + Math.round(P.hp - before),
            "#8ef07a",
            24,
            1,
          );
          for (let i = 0; i < 26; i++)
            parts.push({
              k: "dot",
              x: P.x + rnd(-16, 16),
              y: P.y - rnd(10, 80),
              vx: rnd(-20, 20),
              vy: rnd(-90, -30),
              life: rnd(0.6, 1.1),
              t: 0,
              col: "140,240,120",
              g: 0,
              drag: 1,
              sz: rnd(2, 4),
            });
        }
        if (P.t >= 0.85) {
          P.state = "free";
          P.t = 0;
        }
        break;
      }
    }
    physics(dt);
    if (P.state === "plunge" && P.y >= GROUND) {
      P.y = GROUND;
      P.vy = 0;
      sfx("boom");
      doShake(9);
      dust(P.x, GROUND, 14);
      petals(P.x, GROUND, 14, 300);
      addRing(P.x, GROUND - 4, 8, 110, 0.3, "rgba(255,225,160,.8)", 4);
      if (
        !P.plungeHit &&
        B.state !== "dead" &&
        B.state !== "intro" &&
        Math.abs(P.x - B.x) < 120
      ) {
        P.plungeHit = true;
        hitBoss(120, 0.09);
      }
      P.state = "free";
      P.t = 0;
    }
  }
  function physics(dt) {
    const wasAir = P.y < GROUND - 1;
    if (
      P.state !== "plunge" &&
      P.state !== "airdash" &&
      P.state !== "teleport" &&
      !(P.state === "rskill1" && P.rPhase === "dash")
    )
      P.vy += GRAV * dt;
    P.y += P.vy * dt;
    P.x = clamp(P.x + P.vx * dt, 40, WORLD - 40);
    if (P.y >= GROUND) {
      if (wasAir && P.vy > 300) {
        dust(P.x, GROUND, 6);
        P.landT = 0.14;
      }
      if (wasAir) P.airDodged = false;
      P.y = GROUND;
      P.vy = 0;
    }
  }

  /* ================= BOSS AI ================= */
  function bossCombatTarget() {
    let target = P,
      best = Infinity;
    if (heroType === "wizard") {
      for (const s of skeletons) {
        if (s.hp <= 0 || s.state === "spawn") continue;
        const d = Math.abs(s.x - B.x);
        if (d < best) {
          best = d;
          target = s;
        }
      }
    }
    B.targetSkeleton = target === P ? null : target;
    return target;
  }
  function damageSkeletonsInRange(x, radius, dmg) {
    let hit = false;
    if (heroType !== "wizard") return hit;
    for (const s of skeletons) {
      if (s.hp > 0 && s.state !== "spawn" && Math.abs(s.x - x) <= radius) {
        damageSkeleton(s, dmg);
        hit = true;
      }
    }
    return hit;
  }
  function bossFace() {
    const target = bossCombatTarget();
    B.face = target.x >= B.x ? 1 : -1;
  }
  function startBossAtk() {
    B.atk = B.combo.atks[B.ci];
    B.phase = "wind";
    B.pt = 0;
    B.hitDone = false;
  }
  function bossChoose() {
    const d = Math.abs(bossCombatTarget().x - B.x),
      r = Math.random();
    let pick;
    if (d > 430) pick = r < 0.55 ? "kame" : "walk";
    else if (d > 210)
      pick =
        r < 0.55 ? "combo" : r < 0.75 ? "kame" : r < 0.87 ? "explode" : "walk";
    else pick = r < 0.65 ? "combo" : r < 0.9 ? "explode" : "kame";
    if (pick === B.last && pick !== "walk" && Math.random() < 0.75)
      pick = pick === "combo" ? (d > 300 ? "kame" : "explode") : "combo";
    B.last = pick;
    if (pick === "walk") {
      B.cool = rnd(0.3, 0.6);
      return;
    }
    if (pick === "combo") {
      let i;
      do {
        i = Math.floor(Math.random() * COMBOS.length);
      } while (i === B.lastCombo);
      B.lastCombo = i;
      B.combo = COMBOS[i];
      B.ci = 0;
      B.state = "combo";
      startBossAtk();
    } else if (pick === "kame") {
      B.state = "kame";
      B.phase = "charge";
      B.pt = 0;
      B.beamHit = false;
      sfx("charge");
    } else {
      B.state = "explode";
      B.phase = "charge";
      B.pt = 0;
      B.expR = 0;
      sfx("charge");
    }
  }
  function bossStrike(a) {
    if (B.hitDone) return;
    const f = B.face,
      R = a.rect;
    const lo = Math.min(B.x + f * R.x0, B.x + f * R.x1),
      hi = Math.max(B.x + f * R.x0, B.x + f * R.x1);
    if (heroType === "wizard") {
      for (const s of skeletons) {
        if (s.hp > 0 && s.x + 14 > lo && s.x - 14 < hi) {
          damageSkeleton(s, a.dmg ? bd(a.dmg) : 75);
          B.hitDone = true;
          return;
        }
      }
    }
    const pb = GROUND - P.y,
      pt = pb + 100;
    const overY = pt > R.h0 && pb < R.h1;
    const parryWindow = heroType === "ronin" ? RONIN_DEFLECT_WIN : PARRY_WIN;
    if (
      P.state === "parry" &&
      !P.parrySucc &&
      P.t < parryWindow &&
      (heroType === "ronin" || P.face === -f)
    ) {
      const pl = Math.min(P.x - 16, P.x + P.face * 34),
        pr = Math.max(P.x + 16, P.x + P.face * 34);
      if (pr > lo && pl < hi && overY) {
        if (heroType === "ronin")
          roninDeflectSuccess((B.x + P.x) / 2 + P.face * 6, P.y - 66);
        else parrySuccess((B.x + P.x) / 2 + P.face * 6, P.y - 66);
        return;
      }
    }
    if (P.x + 15 > lo && P.x - 15 < hi && overY) {
      if (P.invuln > 0) return;
      if (hurtPlayer(a.dmg ? bd(a.dmg) : 75, B.x, false)) B.hitDone = true;
    }
  }
  function bossSlashFx(a) {
    const f = B.face,
      art = B.type === "art",
      demon = B.type === "demon",
      sc = demon ? 1.58 : art ? 1.5 : 1.42,
      sy = GROUND - 79 * sc;
    const col = demon
      ? "rgba(255,72,38,.96)"
      : art
        ? "rgba(150,195,255,.92)"
        : "rgba(184,110,255,.9)";
    if (a.type === "thrust")
      addStreak(
        B.x + f * 30,
        GROUND - ((80 * sc) / 1.42) * 1.1,
        f * (demon ? 235 : 200),
        col,
        0.16,
      );
    else {
      const K = BK[a.type];
      addArc(
        B.x,
        sy,
        demon ? 158 : art ? 170 : 138,
        K.aw,
        K.a1,
        f,
        0.2,
        col,
        demon ? 16 : 14,
      );
    }
    sfx("bswing");
  }
  function updateBoss(dt) {
    B.flash = Math.max(0, B.flash - dt);
    if (B.ghostDelay > 0) B.ghostDelay -= dt;
    else if (B.ghost > B.hp) B.ghost = Math.max(B.hp, B.ghost - 700 * dt);
    if (P.ghostDelay > 0) P.ghostDelay -= dt;
    else if (P.ghost > P.hp) P.ghost = Math.max(P.hp, P.ghost - 260 * dt);
    else P.ghost = P.hp;
    B.moving = false;
    if (B.type === "shogun") {
      updateShogun(dt);
      B.x = clamp(B.x, 60, WORLD - 60);
      return;
    }
    if (B.type === "art") {
      updateArt(dt);
      B.x = clamp(B.x, 60, WORLD - 60);
      return;
    }
    if (B.type === "demon") {
      updateDemon(dt);
      B.x = clamp(B.x, 80, WORLD - 80);
      return;
    }
    const rage = B.rage,
      spd = rage ? 130 : 96;
    switch (B.state) {
      case "intro":
        B.introFill = Math.min(1, phaseT / 1.6);
        if (!B.roared && phaseT > 0.5) {
          B.roared = true;
          sfx("roar");
          doShake(14);
          addRing(B.x, GROUND - 60, 10, 280, 0.8, "rgba(180,110,255,.8)", 6);
          petals(B.x, GROUND, 40, 420);
        }
        break;
      case "idle": {
        bossFace();
        const dx = Math.abs(bossCombatTarget().x - B.x);
        if (dx > 118 && B.cool > -5) {
          B.x += B.face * spd * dt;
          B.moving = true;
          B.stride += spd * dt * 0.06;
        }
        B.cool -= dt;
        if (B.cool <= 0 && phase === "fight" && P.state !== "dead")
          bossChoose();
        break;
      }
      case "combo": {
        const a = B.atk;
        B.pt += dt;
        const wS = a.w * (rage ? 0.86 : 1);
        if (B.phase === "wind") {
          if (B.pt < wS * 0.5) bossFace();
          if (B.pt > wS * 0.3 && Math.abs(bossCombatTarget().x - B.x) > a.stop)
            B.x += B.face * (a.lunge / (wS * 0.7)) * dt;
          if (B.pt >= wS) {
            B.phase = "act";
            B.pt = 0;
            B.hitDone = false;
            bossSlashFx(a);
          }
        } else if (B.phase === "act") {
          bossStrike(a);
          if (B.state !== "combo") break;
          if (B.pt >= a.a) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else {
          if (B.pt >= a.r * (rage ? 0.85 : 1)) {
            B.ci++;
            if (B.ci >= B.combo.atks.length) {
              B.state = "idle";
              B.cool = rnd(0.55, 1.05) * (rage ? 0.65 : 1);
            } else startBossAtk();
          }
        }
        B.x = clamp(B.x, 60, WORLD - 60);
        break;
      }
      case "kame": {
        B.pt += dt;
        const charge = rage ? 0.95 : 1.15,
          fireT = 0.36,
          rec = 0.85;
        const hx = B.x + B.face * 51,
          hy = GROUND - 51;
        if (B.phase === "charge") {
          if (B.pt < charge * 0.65) bossFace();
          if (Math.random() < 0.9) {
            const a = rnd(0, TAU),
              rr = rnd(60, 110);
            parts.push({
              k: "gather",
              sx: hx + Math.cos(a) * rr,
              sy: hy + Math.sin(a) * rr,
              tx: hx,
              ty: hy,
              life: 0.4,
              t: 0,
              x: 0,
              y: 0,
            });
          }
          if (B.pt >= charge) {
            B.phase = "fire";
            B.pt = 0;
            B.beamHit = false;
            sfx("beam");
            doShake(10);
          }
        } else if (B.phase === "fire") {
          doShake(6);
          const reach = Math.min(WORLD * 1.2, 4200 * B.pt + 40),
            f = B.face;
          const x0 = B.x + f * 40,
            x1 = x0 + f * reach;
          const lo = Math.min(x0, x1),
            hi = Math.max(x0, x1);
          if (!B.beamHit && heroType === "wizard") {
            for (const s of skeletons) {
              if (
                s.hp > 0 &&
                s.state !== "spawn" &&
                s.x + 12 > lo &&
                s.x - 12 < hi
              ) {
                damageSkeleton(s, 200);
                B.beamHit = true;
                break;
              }
            }
          }
          if (
            !B.beamHit &&
            P.x + 12 > lo &&
            P.x - 12 < hi &&
            GROUND - P.y < BEAM_H &&
            P.invuln <= 0 &&
            P.state !== "dead"
          ) {
            if (hurtPlayer(200, B.x, true)) B.beamHit = true;
          }
          if (Math.random() < 0.8)
            spark(
              x0 + f * rnd(0, Math.min(reach, 900)),
              GROUND - rnd(0, 10),
              1,
              "#d9b8ff",
              260,
              0.35,
              300,
            );
          if (B.pt >= fireT) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt >= rec) {
          B.state = "idle";
          B.cool = rnd(0.7, 1.2) * (rage ? 0.7 : 1);
        }
        break;
      }
      case "explode": {
        B.pt += dt;
        const charge = rage ? 1.0 : 1.2,
          burstT = 0.55,
          rec = 0.9;
        if (B.phase === "charge") {
          B.expR = 250 * Math.min(1, B.pt / charge);
          if (Math.random() < 0.8) {
            const a = rnd(0, TAU),
              rr = rnd(100, 200);
            parts.push({
              k: "gather",
              sx: B.x + Math.cos(a) * rr,
              sy: GROUND - 70 + Math.sin(a) * rr * 0.8,
              tx: B.x,
              ty: GROUND - 70,
              life: 0.45,
              t: 0,
              x: 0,
              y: 0,
            });
          }
          if (B.pt >= charge) {
            B.phase = "burst";
            B.pt = 0;
            sfx("boom");
            doShake(24);
            doFlash(0.65, "220,180,255");
            hitstop = 0.08;
            addRing(
              B.x,
              GROUND - 70,
              20,
              270,
              0.5,
              "rgba(230,200,255,.95)",
              10,
            );
            addRing(B.x, GROUND - 70, 10, 200, 0.4, "rgba(160,90,255,.8)", 14);
            spark(B.x, GROUND - 70, 60, "#e6c8ff", 800, 0.9, 200);
            petals(B.x, GROUND, 90, 700);
            dust(B.x, GROUND, 24);
            const dist = Math.hypot(P.x - B.x, P.y - 50 - (GROUND - 70));
            damageSkeletonsInRange(B.x, 250, 200);
            if (dist <= 250 && P.invuln <= 0 && P.state !== "dead")
              hurtPlayer(200, B.x, true);
          }
        } else if (B.phase === "burst") {
          if (B.pt >= burstT) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt >= rec) {
          B.state = "idle";
          B.cool = rnd(0.7, 1.2) * (rage ? 0.7 : 1);
        }
        break;
      }
      case "stunned":
        B.stunT -= dt;
        if (B.stunT <= 0) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "dead":
        B.dieT += dt;
        if (B.dieT > 0.8 && Math.random() < 0.9) {
          parts.push({
            k: "dot",
            x: B.x + rnd(-40, 40),
            y: GROUND - rnd(0, 140),
            vx: rnd(-20, 20),
            vy: rnd(-120, -40),
            life: rnd(0.8, 1.6),
            t: 0,
            col: "190,120,255",
            g: -20,
            drag: 0.5,
            sz: rnd(2, 5),
          });
        }
        if (B.dieT > 1 && Math.random() < 0.3) petals(B.x, GROUND - 60, 2, 200);
        break;
    }
    B.x = clamp(B.x, 60, WORLD - 60);
  }

  /* ================= FX UPDATE ================= */
  function updateFx(dt) {
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      p.t += dt;
      if (p.t >= p.life) {
        parts.splice(i, 1);
        continue;
      }
      if (p.k === "gather") continue;
      p.vy += (p.g || 0) * dt;
      if (p.drag) {
        const d = Math.max(0, 1 - p.drag * dt);
        p.vx *= d;
        p.vy *= d;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.rot !== undefined) p.rot += p.vr * dt;
    }
    for (let i = fx.length - 1; i >= 0; i--) {
      const f = fx[i];
      f.t += dt;
      if (f.t >= f.life) fx.splice(i, 1);
    }
    for (const m of motes) {
      m.x += (m.vx + Math.sin(time * 0.6 + m.ph) * 6) * dt;
      m.y += (m.vy + Math.cos(time * 0.5 + m.ph) * 4) * dt;
      if (m.x < 0) m.x += WORLD;
      if (m.x > WORLD) m.x -= WORLD;
      if (m.y < 60) m.y = 520;
      if (m.y > 525) m.y = 70;
    }
  }

  /* ================= MAIN STEP ================= */
  function step(dt) {
    savePrev();
    if (paused) return;
    time += dt;
    impactMuteT = Math.max(0, impactMuteT - dt);
    hitstop = 0;
    if (phase === "title") {
      updateFx(dt);
      cam = clamp(P.x * 0.6 + B.x * 0.4 - W / 2, 0, WORLD - W);
      return;
    }
    phaseT += dt;
    for (const k in buf) buf[k] = Math.max(0, buf[k] - dt);
    if (gameMode !== "solo")
      for (const k in buf2) buf2[k] = Math.max(0, buf2[k] - dt);
    if (phase === "intro" && phaseT > 2.8) {
      phase = "fight";
      phaseT = 0;
      B.state = "idle";
      B.cool = 0.9;
      musicPlay(
        bossType === "art" || bossType === "demon" || bossType === "shogun"
          ? "battleArt"
          : "battleSent",
      );
    }
    if (gameMode === "solo") {
      updatePlayer(dt);
      updateBoss(dt);
      updateDemonHazards(dt);
      updateShogunHazards(dt);
      updateShogunMinion(dt);
    } else {
      withPlayer(0, () => updatePlayer(dt), gameMode === "pvp");
      withPlayer(1, () => updatePlayer(dt), gameMode === "pvp");
      P = players[0];
      if (gameMode === "coop") {
        let target = players[0].state === "dead" ? 1 : 0;
        if (
          players[1].state !== "dead" &&
          Math.abs(players[1].x - B.x) < Math.abs(players[target].x - B.x)
        )
          target = 1;
        withPlayer(target, () => {
          updateBoss(dt);
          updateDemonHazards(dt);
          updateShogunHazards(dt);
          updateShogunMinion(dt);
        });
      }
    }
    updateOrbs(dt);
    updateSlashes(dt);
    updateKillWaves(dt);
    updateArrows(dt);
    updateRain(dt);
    updateRegalProjectiles(dt);
    updateWizardSystems(dt);
    updateFx(dt);
    let focusX = P.x * 0.62 + B.x * 0.38;
    if (gameMode === "coop")
      focusX = (players[0].x + players[1].x + B.x) / 3;
    else if (gameMode === "pvp")
      focusX = (players[0].x + players[1].x) / 2;
    const tx = clamp(focusX - W / 2, 0, WORLD - W);
    cam += (tx - cam) * Math.min(1, dt * 4);
    shake *= 0.88;
    if (shake < 0.2) shake = 0;
    screenFlash = Math.max(0, screenFlash - dt * 1.6);
    if ((phase === "lost" || phase === "won") && !B.musicCut) {
      B.musicCut = true;
      musicStop(phase === "won" ? 1.6 : 2.4);
    }
    if (phase === "lost" && phaseT > 2.0) {
      phase = "lostUI";
      showEnd(false);
      musicPlay("title");
    }
    if (phase === "won" && phaseT > 4.2) {
      phase = "wonUI";
      showEnd(true);
      sfx("win");
      musicPlay("victory");
    }
  }
  function showEnd(win) {
    $("pauseBtn").classList.add("hide");
    if (gameMode === "pvp") {
      $("endTitle").textContent = "PLAYER " + pvpWinner + " WINS";
      $("endSub").textContent =
        "Local duel complete. Four flasks each. Change champions in the multiplayer lobby for the next match.";
      $("endBtn").textContent = "Rematch";
      $("end").className = "ov win";
      return;
    }
    const art = B.type === "art",
      demon = B.type === "demon";
    $("endTitle").textContent = win
      ? demon
        ? "THE DEMON IS SHATTERED"
        : art
          ? "ARTORIAS HAS FALLEN"
          : "THE SENTINEL HAS FALLEN"
      : "THOU HAST FALLEN";
    $("endSub").textContent = win
      ? (demon
          ? "The ruin beneath the volcano is silent."
          : art
            ? "The Abysswalker rests at last."
            : "The lilies bloom once more in the moonlit nave.") +
        "  +200 coins earned."
      : demon
        ? "The shattered flame consumes another challenger."
        : art
          ? "The abyss claims another. Rise and try again."
          : "The violet moon watches. Rise and try again.";
    $("endBtn").textContent = win ? "Duel again" : "Try again";
    $("end").className = "ov " + (win ? "win" : "lose");
  }

  /* ================= SPRITE RENDERER ================= */
  const PAL_H = {
    dark: "#3b2410",
    mid: "#a8743a",
    light: "#f0c47f",
    trim: "#ffd98f",
    cloth: "#e3dac2",
    cloth2: "#b9ac8d",
    outline: "#150c06",
    leg: "#8a5a2c",
    legFar: "#5e3d1e",
    blade: "#e7dcc0",
    bladeD: "#a8926a",
    grip: "#5b3a1c",
    guard: "#c9903e",
  };
  const PAL_B = {
    dark: "#070a18",
    mid: "#1b2647",
    light: "#42568f",
    trim: "#d1a94c",
    cloak: "#43206f",
    cloakDark: "#1e0d3a",
    outline: "#03040a",
    leg: "#141c38",
    legFar: "#0b1124",
    blade: "#b06aff",
    bladeD: "#4a1aa0",
    grip: "#2a1746",
    guard: "#c9a24a",
  };

  function ik(sx, sy, tx, ty, l1, l2, dir) {
    let dx = tx - sx,
      dy = ty - sy,
      d = Math.hypot(dx, dy);
    const maxd = l1 + l2 - 0.01;
    if (d > maxd) {
      dx *= maxd / d;
      dy *= maxd / d;
      d = maxd;
      tx = sx + dx;
      ty = sy + dy;
    }
    if (d < 0.001) d = 0.001;
    const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d),
      h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
    const mx = sx + (dx * a) / d,
      my = sy + (dy * a) / d;
    return { x: mx + dir * h * (-dy / d), y: my + dir * h * (dx / d), tx, ty };
  }
  function strokePoly(c, p) {
    c.beginPath();
    c.moveTo(p[0].x, p[0].y);
    for (let i = 1; i < p.length; i++) c.lineTo(p[i].x, p[i].y);
    c.stroke();
  }
  function limb(c, pts, w, dark, mid, light) {
    c.lineCap = "round";
    c.lineJoin = "round";
    c.strokeStyle = dark;
    c.lineWidth = w + 3;
    strokePoly(c, pts);
    c.strokeStyle = mid;
    c.lineWidth = w;
    strokePoly(c, pts);
    c.strokeStyle = light;
    c.lineWidth = w * 0.28;
    c.save();
    c.translate(-w * 0.16, -w * 0.16);
    strokePoly(c, pts);
    c.restore();
  }
  function poly(c, pts, fill, stroke, lw) {
    c.beginPath();
    c.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0], pts[i][1]);
    c.closePath();
    if (fill) {
      c.fillStyle = fill;
      c.fill();
    }
    if (stroke) {
      c.strokeStyle = stroke;
      c.lineWidth = lw || 1.4;
      c.stroke();
    }
  }
  function drawSword(c, hx, hy, A, len, p, boss, glow) {
    c.save();
    c.translate(hx, hy);
    c.rotate(A);
    c.fillStyle = p.grip;
    c.fillRect(-12, -2, 13, 4);
    c.fillStyle = p.guard;
    c.beginPath();
    c.arc(-13, 0, 3.2, 0, TAU);
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(0, -10);
    c.quadraticCurveTo(4, -6, 4, 0);
    c.quadraticCurveTo(4, 6, 0, 10);
    c.lineTo(-2, 7);
    c.lineTo(-2, -7);
    c.closePath();
    c.fillStyle = p.guard;
    c.fill();
    c.stroke();
    if (boss) {
      c.fillStyle = "#7d3ff0";
      c.beginPath();
      c.arc(1.5, 0, 2.2, 0, TAU);
      c.fill();
    }
    const bw = boss ? 4.8 : 3.8;
    if (glow) {
      c.shadowColor = boss ? "#b46bff" : "#ffd28a";
      c.shadowBlur = glow;
    }
    const g = c.createLinearGradient(0, -bw, 0, bw);
    g.addColorStop(0, p.bladeD);
    g.addColorStop(0.5, p.blade);
    g.addColorStop(1, p.bladeD);
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(4, -bw);
    c.lineTo(len - 14, -bw);
    c.lineTo(len, 0);
    c.lineTo(len - 14, bw);
    c.lineTo(4, bw);
    c.closePath();
    c.fill();
    c.shadowBlur = 0;
    c.strokeStyle = p.outline;
    c.lineWidth = 1;
    c.stroke();
    c.globalAlpha *= 0.65;
    c.strokeStyle = boss ? "#ecd2ff" : "#fff4d6";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(9, 0);
    c.lineTo(len - 22, 0);
    c.stroke();
    if (boss) {
      c.globalAlpha *= 0.7;
      c.strokeStyle = "#2a0e58";
      for (let i = 0; i < 6; i++) {
        const x = 16 + i * 10;
        c.beginPath();
        c.moveTo(x, -2.4);
        c.lineTo(x + 3, 2.4);
        c.stroke();
      }
    }
    c.restore();
  }
  function drawShield(c, x, y, r, k, glowing) {
    c.save();
    c.translate(x, y);
    c.scale(lerp(0.95, 0.5, k), 1);
    const g = c.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
    g.addColorStop(0, "#f2cf98");
    g.addColorStop(0.6, "#b37a3c");
    g.addColorStop(1, "#6a4220");
    c.fillStyle = g;
    c.beginPath();
    c.arc(0, 0, r, 0, TAU);
    c.fill();
    c.strokeStyle = "#2a170a";
    c.lineWidth = 1.8;
    c.stroke();
    c.strokeStyle = "#ffe0a0";
    c.lineWidth = 1.2;
    c.beginPath();
    c.arc(0, 0, r * 0.82, 0, TAU);
    c.stroke();
    c.strokeStyle = "#5a3616";
    c.lineWidth = 1.3;
    for (let i = 0; i < 20; i++) {
      const a = (i / 20) * TAU,
        r1 = r * 0.86,
        r2 = r * 0.96;
      c.beginPath();
      c.moveTo(Math.cos(a) * r1, Math.sin(a) * r1);
      c.lineTo(Math.cos(a) * r2, Math.sin(a) * r2);
      c.stroke();
    }
    c.fillStyle = "#93622f";
    c.beginPath();
    c.arc(0, 0, r * 0.56, 0, TAU);
    c.fill();
    c.strokeStyle = "#ffe0a0";
    c.lineWidth = 1;
    c.stroke();
    c.strokeStyle = "#ffe6b0";
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * TAU;
      c.beginPath();
      c.moveTo(Math.cos(a) * r * 0.22, Math.sin(a) * r * 0.22);
      c.lineTo(Math.cos(a) * r * 0.5, Math.sin(a) * r * 0.5);
      c.stroke();
    }
    c.fillStyle = "#e9b866";
    c.beginPath();
    c.arc(0, 0, r * 0.2, 0, TAU);
    c.fill();
    if (glowing) {
      const gc = typeof glowing === "string" ? glowing : "#ffd97a";
      c.strokeStyle = gc;
      c.lineWidth = 3;
      c.shadowColor = gc;
      c.shadowBlur = 16;
      c.beginPath();
      c.arc(0, 0, r * 1.1, 0, TAU);
      c.stroke();
    }
    c.restore();
  }

  function drawKnight(c, o) {
    const p = o.pal,
      boss = o.kind === "boss",
      t = o.t,
      run = o.run || 0,
      air = o.air,
      crouch = o.crouch || 0,
      lean = o.lean || 0;
    c.save();
    c.translate(o.x, o.y);
    c.scale(o.face * o.scale, o.scale);
    if (o.rot) c.rotate(o.rot);
    c.globalAlpha = o.alpha === undefined ? 1 : o.alpha;
    if (o.flash) c.filter = "brightness(2.6) saturate(.35)";
    const hipY = -44 + crouch * 0.9;
    let fA, fB;
    if (air) {
      fA = { x: -7, y: -16 };
      fB = { x: 11, y: -26 };
    } else if (o.slide) {
      fA = { x: -16, y: -2 };
      fB = { x: 22, y: -1 };
    } else if (o.kneel) {
      fA = { x: -22, y: -2 };
      fB = { x: 12, y: 0 };
    } else {
      const ph = o.phase !== undefined ? o.phase : t * (o.runSpeed || 9),
        rx = 17 * run;
      fA = {
        x: -9 * (1 - run) + Math.sin(ph) * rx,
        y: -Math.max(0, Math.cos(ph)) * 10 * run,
      };
      fB = {
        x: 9 * (1 - run) + Math.sin(ph + Math.PI) * rx,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 10 * run,
      };
    }
    const drawLeg = (hx, f, far) => {
      const k = ik(hx, hipY, f.x, f.y, 23, 23, -1);
      limb(
        c,
        [
          { x: hx, y: hipY },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        11,
        p.outline,
        far ? p.legFar : p.leg,
        p.light,
      );
      c.fillStyle = p.dark;
      c.strokeStyle = p.outline;
      c.lineWidth = 1;
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 2, 9, 4.6, 0, 0, TAU);
      c.fill();
      c.stroke();
      c.fillStyle = boss ? p.trim : p.light;
      c.beginPath();
      c.arc(k.x + 2, k.y, 4.2, 0, TAU);
      c.fill();
      c.strokeStyle = p.outline;
      c.stroke();
    };
    drawLeg(-4, fA, true);
    drawLeg(4, fB, false);

    // lower cloth
    const sw = Math.sin(t * 1.7) * 1.5 + run * -6 + (o.clothSway || 0);
    if (!boss) {
      poly(
        c,
        [
          [-9, hipY - 2],
          [-6, hipY - 2],
          [-13 + sw, hipY + 30],
          [-18 + sw, hipY + 34],
        ],
        p.cloth2,
        p.outline,
        1,
      );
      poly(
        c,
        [
          [-7, hipY - 3],
          [12, hipY - 3],
          [15 + sw, hipY + 34],
          [-5 + sw, hipY + 38],
        ],
        p.cloth,
        p.outline,
        1.2,
      );
      c.strokeStyle = p.trim;
      c.lineWidth = 1.2;
      c.beginPath();
      c.moveTo(3, hipY);
      c.lineTo(5 + sw, hipY + 36);
      c.stroke();
      c.strokeStyle = "rgba(150,120,70,.6)";
      c.lineWidth = 0.8;
      c.beginPath();
      c.moveTo(-3, hipY + 2);
      c.lineTo(-2 + sw, hipY + 34);
      c.moveTo(9, hipY + 2);
      c.lineTo(11 + sw, hipY + 34);
      c.stroke();
    } else {
      poly(
        c,
        [
          [-8, hipY - 3],
          [11, hipY - 3],
          [13 + sw, hipY + 30],
          [8 + sw, hipY + 27],
          [3 + sw, hipY + 33],
          [-3 + sw, hipY + 27],
          [-8 + sw, hipY + 32],
        ],
        p.cloak,
        p.outline,
        1.2,
      );
      c.fillStyle = "rgba(0,0,0,.35)";
      for (let i = 0; i < 5; i++)
        for (let j = 0; j < 3; j++) {
          c.beginPath();
          c.arc(-5 + i * 4, hipY - 1 + j * 5, 0.9, 0, TAU);
          c.fill();
        }
    }

    // upper body
    c.save();
    c.translate(0, crouch);
    c.translate(0, -44);
    c.rotate(lean);
    c.translate(0, 44);

    if (boss) {
      const w1 = Math.sin(t * 3) * 3 + run * 9 + (o.capeBack || 0),
        w2 = Math.sin(t * 3 + 1) * 4 + run * 12 + (o.capeBack || 0) * 1.4;
      poly(
        c,
        [
          [-4, -85],
          [-15, -72],
          [-21 - w1, -46],
          [-27 - w2, -8],
          [-22 - w2, -1],
          [-18 - w1, -9],
          [-13 - w2 * 0.7, 0],
          [-8 - w1 * 0.5, -8],
          [-3, -2],
          [1, -44],
        ],
        p.cloak,
        p.outline,
        1.4,
      );
      poly(
        c,
        [
          [-4, -80],
          [-12, -66],
          [-16 - w1 * 0.8, -40],
          [-20 - w2 * 0.8, -14],
          [-8, -10],
          [-2, -44],
        ],
        p.cloakDark,
        null,
      );
      // far arm (off hand) rests behind body
      if (!o.offTarget) {
        const S = { x: -5, y: -78 },
          tgt = { x: -8 + Math.sin(t * 2) * 0.6, y: -52 };
        const e = ik(S.x, S.y, tgt.x, tgt.y, 17, 17, 1);
        limb(
          c,
          [S, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
          9.5,
          p.outline,
          p.mid,
          p.light,
        );
        c.fillStyle = p.dark;
        c.beginPath();
        c.arc(e.tx, e.ty, 4.6, 0, TAU);
        c.fill();
      }
    }
    if (!boss && o.shieldK === -1) drawShield(c, -12, -60, 19, 0, false);

    // torso
    const tg = c.createLinearGradient(-12, 0, 14, 0);
    tg.addColorStop(0, p.dark);
    tg.addColorStop(0.5, p.mid);
    tg.addColorStop(1, p.light);
    c.beginPath();
    c.moveTo(-10, -80);
    c.quadraticCurveTo(1, -89, 11, -80);
    c.quadraticCurveTo(16, -64, 10, -46);
    c.lineTo(-9, -46);
    c.quadraticCurveTo(-14, -64, -10, -80);
    c.closePath();
    c.fillStyle = tg;
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.5;
    c.stroke();
    c.strokeStyle = "rgba(0,0,0,.35)";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-9, -70);
    c.quadraticCurveTo(2, -66, 12, -70);
    c.moveTo(-9, -58);
    c.quadraticCurveTo(2, -55, 11, -58);
    c.stroke();
    if (boss) {
      c.fillStyle = p.trim;
      c.beginPath();
      c.arc(6, -71, 4.6, 0, TAU);
      c.fill();
      c.strokeStyle = p.outline;
      c.lineWidth = 1;
      c.stroke();
      c.fillStyle = "#b877ff";
      c.beginPath();
      c.arc(6, -71, 2.6, 0, TAU);
      c.fill();
      c.fillStyle = p.trim;
      for (let i = 0; i < 5; i++) {
        c.beginPath();
        c.arc(-5 + i * 3.8, -62, 0.9, 0, TAU);
        c.fill();
      }
    } else {
      c.strokeStyle = p.trim;
      c.lineWidth = 1.3;
      c.beginPath();
      c.arc(5, -66, 4.5, 0, TAU);
      c.moveTo(1, -66);
      c.lineTo(9, -66);
      c.moveTo(5, -70.5);
      c.lineTo(5, -61.5);
      c.stroke();
      c.strokeStyle = "rgba(255,217,143,.55)";
      c.beginPath();
      c.moveTo(-7, -76);
      c.quadraticCurveTo(0, -72, 9, -76);
      c.stroke();
    }
    // belt
    c.fillStyle = boss ? "#1a1030" : p.dark;
    c.fillRect(-10, -50, 21, 5.5);
    c.strokeStyle = p.outline;
    c.lineWidth = 1;
    c.strokeRect(-10, -50, 21, 5.5);
    c.fillStyle = p.trim;
    c.beginPath();
    c.arc(1, -47.3, 3.4, 0, TAU);
    c.fill();
    c.stroke();

    // neck + head
    c.fillStyle = p.dark;
    c.fillRect(-2, -87, 7, 8);
    if (!boss) {
      c.strokeStyle = p.trim;
      c.lineWidth = 1.6;
      c.beginPath();
      c.arc(0, -105, 14, Math.PI * 1.02, Math.PI * 1.98);
      c.stroke();
      for (let i = 0; i < 7; i++) {
        const a = Math.PI * 1.08 + i * ((0.82 * Math.PI) / 6);
        c.beginPath();
        c.moveTo(Math.cos(a) * 14, -105 + Math.sin(a) * 14);
        c.lineTo(Math.cos(a) * 19.5, -105 + Math.sin(a) * 19.5);
        c.stroke();
      }
      const hg = c.createLinearGradient(-9, -110, 13, -84);
      hg.addColorStop(0, p.light);
      hg.addColorStop(0.55, p.mid);
      hg.addColorStop(1, p.dark);
      c.beginPath();
      c.moveTo(-9, -87);
      c.quadraticCurveTo(-11, -107, 2, -109);
      c.quadraticCurveTo(14, -107, 14, -93);
      c.lineTo(12, -84);
      c.lineTo(-6, -84);
      c.closePath();
      c.fillStyle = hg;
      c.fill();
      c.strokeStyle = p.outline;
      c.lineWidth = 1.5;
      c.stroke();
      c.fillStyle = "#0a0705";
      c.fillRect(3, -96, 11, 2.8);
      c.fillStyle = "rgba(0,0,0,.6)";
      for (let i = 0; i < 3; i++) c.fillRect(6 + i * 2.6, -91, 1.2, 4);
      c.strokeStyle = p.trim;
      c.lineWidth = 1.2;
      c.beginPath();
      c.moveTo(-8, -100);
      c.quadraticCurveTo(3, -102, 14, -98);
      c.stroke();
      c.strokeStyle = p.light;
      c.beginPath();
      c.moveTo(-6, -105);
      c.quadraticCurveTo(2, -109, 10, -106);
      c.stroke();
    } else {
      poly(
        c,
        [
          [-13, -78],
          [-14, -104],
          [-2, -115],
          [10, -114],
          [15, -98],
          [10, -88],
          [-2, -82],
        ],
        p.cloakDark,
        p.outline,
        1.5,
      );
      poly(
        c,
        [
          [-11, -80],
          [-11, -102],
          [-3, -111],
          [4, -108],
          [-2, -90],
        ],
        "#2b1352",
        null,
      );
      poly(
        c,
        [
          [3, -104],
          [12, -105],
          [21, -96],
          [23, -89],
          [14, -88],
          [5, -88],
        ],
        "#080b1a",
        p.outline,
        1.2,
      );
      c.fillStyle = "#e0b3ff";
      c.shadowColor = "#c07bff";
      c.shadowBlur = 9;
      c.beginPath();
      c.ellipse(9.5, -98, 2.8, 1.5, -0.15, 0, TAU);
      c.fill();
      c.beginPath();
      c.ellipse(15, -96.5, 2.2, 1.2, -0.15, 0, TAU);
      c.fill();
      c.shadowBlur = 0;
      c.strokeStyle = p.trim;
      c.lineWidth = 1;
      c.beginPath();
      c.moveTo(-12, -84);
      c.quadraticCurveTo(0, -80, 11, -87);
      c.stroke();
    }
    // pauldron
    const pr = boss ? 13 : 10.5,
      pg = c.createRadialGradient(-2, -83, 1, 2, -78, pr + 2);
    pg.addColorStop(0, p.light);
    pg.addColorStop(0.7, p.mid);
    pg.addColorStop(1, p.dark);
    c.fillStyle = pg;
    c.beginPath();
    c.arc(1, -78, pr, 0, TAU);
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.5;
    c.stroke();
    c.strokeStyle = p.trim;
    c.lineWidth = 1.2;
    c.beginPath();
    c.arc(1, -78, pr - 3, 0.3, 2.6);
    c.stroke();
    if (boss) {
      c.fillStyle = p.trim;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * TAU;
        c.beginPath();
        c.arc(
          1 + Math.cos(a) * (pr - 1.6),
          -78 + Math.sin(a) * (pr - 1.6),
          0.9,
          0,
          TAU,
        );
        c.fill();
      }
    }

    // shield (hero)
    if (!boss && o.shieldK !== -1) {
      const k = o.shieldK || 0;
      drawShield(
        c,
        lerp(11, 27, k),
        lerp(-58, -68, k),
        lerp(19, 22, k),
        k,
        o.shieldGlow,
      );
    }
    // off-hand arm (front)
    if (o.offTarget) {
      const S = { x: 2, y: -78 },
        e = ik(S.x, S.y, o.offTarget.x, o.offTarget.y, 17, 17, 1);
      limb(
        c,
        [S, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
        9.5,
        p.outline,
        p.mid,
        p.light,
      );
      c.fillStyle = p.dark;
      c.beginPath();
      c.arc(e.tx, e.ty, 5, 0, TAU);
      c.fill();
      c.strokeStyle = p.trim;
      c.lineWidth = 1;
      c.stroke();
    }
    if (o.drink > 0) {
      const fx0 = 16,
        fy0 = -92;
      c.save();
      c.translate(fx0, fy0);
      c.rotate(-0.9 * Math.min(1, o.drink));
      c.fillStyle = "#8bf07a";
      c.strokeStyle = p.outline;
      c.lineWidth = 1;
      c.beginPath();
      c.ellipse(0, 4, 5, 6, 0, 0, TAU);
      c.fill();
      c.stroke();
      c.fillStyle = "#d9d0b8";
      c.fillRect(-2, -5, 4, 5);
      c.strokeRect(-2, -5, 4, 5);
      c.fillStyle = "#7a4a22";
      c.fillRect(-2.6, -8, 5.2, 3.4);
      c.restore();
    }
    // sword arm + sword
    const S = { x: 3, y: -79 },
      R = o.handR === undefined ? 28 : o.handR,
      A = o.swordA;
    const hand = { x: S.x + Math.cos(A) * R, y: S.y + Math.sin(A) * R };
    const el = ik(S.x, S.y, hand.x, hand.y, 17, 17, 1);
    limb(
      c,
      [S, { x: el.x, y: el.y }, { x: el.tx, y: el.ty }],
      9.5,
      p.outline,
      p.mid,
      p.light,
    );
    drawSword(c, el.tx, el.ty, A, boss ? 86 : 64, p, boss, o.glow || 0);
    c.fillStyle = p.dark;
    c.strokeStyle = p.trim;
    c.lineWidth = 1;
    c.beginPath();
    c.arc(el.tx, el.ty, 5, 0, TAU);
    c.fill();
    c.stroke();
    c.restore();
    c.restore();
  }

  function heroObj() {
    const air = P.y < GROUND - 3;
    const o = {
      kind: "hero",
      pal: PAL_H,
      scale: 1.05,
      x: P.x,
      y: P.y,
      face: P.face,
      t: time,
      run: 0,
      air,
      swordA: 1.3,
      handR: 28,
      crouch: 0,
      lean: 0,
      shieldK: 0,
      flash: P.flash > 0,
      alpha: 1,
      glow: 0,
      runSpeed: 10,
      clothSway: 0,
      phase: P.stride,
    };
    o.run = P.state === "free" && !air ? Math.min(1, Math.abs(P.vx) / 240) : 0;
    o.swordA = 1.3 + Math.sin(time * 2) * 0.03 - o.run * 0.35;
    o.lean = o.run * 0.09;
    o.crouch = P.state === "free" && !air ? 9 * (P.landT / 0.14) : 0;
    switch (P.state) {
      case "attack": {
        const A = ATK[P.combo],
          t = P.t;
        let a;
        if (t < A.w) a = lerp(1.3, A.a0, easeOut(t / A.w));
        else if (t < A.w + A.a) {
          const k = (t - A.w) / A.a;
          a = lerp(A.a0, A.a1, ease(k));
          o.lean = 0.16 * ease(k);
          if (A.thrust) o.handR = lerp(12, 38, k);
          o.glow = 14;
        } else {
          const k = Math.min(1, (t - A.w - A.a) / A.r);
          a = lerp(A.a1, 1.3, k * k);
          o.lean = 0.16 * (1 - k);
          if (A.thrust) o.handR = lerp(38, 28, k);
        }
        o.swordA = a;
        o.run = 0;
        break;
      }
      case "dodge":
        o.slide = true;
        o.crouch = 22;
        o.lean = 0.6;
        o.swordA = 2.7;
        o.run = 0;
        o.air = false;
        break;
      case "parry":
        o.shieldK = Math.min(1, P.t / 0.07);
        o.swordA = 2.3;
        o.lean = 0.06;
        o.shieldGlow = (P.t < PARRY_WIN && !P.parrySucc) || P.parryFlash > 0;
        o.run = 0;
        break;
      case "hurt":
        o.lean = -0.28;
        o.swordA = 1.9;
        o.run = 0;
        break;
      case "airdash":
        o.air = true;
        o.lean = 0.55;
        o.swordA = 2.6;
        o.run = 0;
        o.clothSway = -8;
        break;
      case "block":
        o.shieldK = 0.8;
        o.swordA = 2.2;
        o.lean = 0.04;
        o.crouch = 4;
        o.run = Math.min(1, Math.abs(P.vx) / 120) * 0.5;
        o.shieldGlow = P.blockFlash > 0 ? "#bfe0ff" : false;
        break;
      case "heal":
        o.drink = Math.min(1, P.t / 0.5);
        o.crouch = 5;
        o.lean = 0.1;
        o.shieldK = -1;
        o.offTarget = { x: 14, y: -88 };
        o.swordA = 1.55;
        o.run = 0;
        break;
      case "skill1": {
        const k = clamp(P.t / 0.3, 0, 1);
        o.swordA =
          k < 0.33
            ? lerp(1.3, -2.1, easeOut(k / 0.33))
            : k < 0.5
              ? lerp(-2.1, 0.9, (k - 0.33) / 0.17)
              : lerp(0.9, 1.3, (k - 0.5) / 0.5);
        o.lean = 0.1 * Math.sin(k * Math.PI);
        o.glow = k < 0.5 ? 16 : 0;
        o.run = 0;
        break;
      }
      case "skill2": {
        const chargeT = 0.55,
          k = Math.min(1, P.t / chargeT);
        if (P.t < chargeT) {
          o.crouch = 6 * k;
          o.lean = -0.08 * k;
          o.swordA = lerp(1.3, 1.05, k);
          o.shieldK = -1;
          o.offTarget = { x: lerp(6, -8, k), y: lerp(-70, -56, k) };
          o.glow = 4 + 14 * k;
        } else {
          const k2 = Math.min(1, (P.t - chargeT) / 0.27);
          o.lean = 0.28 * (1 - k2);
          o.swordA = lerp(-0.3, 1.3, k2);
          o.offTarget = { x: 10, y: -60 };
          o.glow = 18 * (1 - k2);
        }
        o.run = 0;
        break;
      }
      case "plunge":
        o.swordA = 1.5;
        o.lean = 0.12;
        o.handR = 30;
        o.air = true;
        break;
      case "dead":
        o.rot = -Math.min(1.5, P.deadT * 3.5);
        o.run = 0;
        o.alpha = clamp(1 - (P.deadT - 1) * 0.8, 0.25, 1);
        break;
      case "free":
        if (air) {
          o.swordA = 1.1;
          o.lean = 0.05;
        }
        break;
    }
    return o;
  }
  function bossObj() {
    const o = {
      kind: "boss",
      pal: PAL_B,
      scale: 1.42,
      x: B.x,
      y: B.y,
      face: B.face,
      t: time,
      run: B.moving ? 0.5 : 0,
      air: false,
      swordA: 1.35 + Math.sin(time * 1.6) * 0.03,
      handR: 28,
      crouch: 0,
      lean: 0,
      flash: B.flash > 0,
      alpha: 1,
      glow: B.rage ? 10 : 3,
      runSpeed: 7,
      phase: B.stride,
    };
    if (B.moving) o.runSpeed = B.rage ? 9 : 7;
    switch (B.state) {
      case "intro": {
        const k =
          clamp((phaseT - 0.4) / 0.5, 0, 1) *
          (1 - clamp((phaseT - 1.9) / 0.6, 0, 1));
        o.swordA = lerp(1.5, -1.9, k);
        o.lean = -0.2 * k;
        o.offTarget =
          k > 0.05 ? { x: lerp(-8, 20, k), y: lerp(-52, -118, k) } : null;
        o.capeBack = 8 * k;
        o.glow = 8 + 14 * k;
        break;
      }
      case "combo": {
        const a = B.atk,
          K = BK[a.type],
          wS = a.w * (B.rage ? 0.86 : 1);
        let ang;
        if (B.phase === "wind") {
          const k = Math.min(1, B.pt / wS);
          ang = lerp(1.35, K.aw, easeOut(k));
          o.lean = K.wl * k;
          o.handR = lerp(28, K.rw, k);
          o.glow = 6 + k * 10;
          o.capeBack = 5 * k;
        } else if (B.phase === "act") {
          const k = Math.min(1, B.pt / a.a);
          ang = lerp(K.aw, K.a1, ease(k));
          o.lean = lerp(K.wl, K.sl, k);
          o.handR = lerp(K.rw, K.rs, k);
          o.glow = 22;
          o.capeBack = 10;
        } else {
          const k = Math.min(1, B.pt / a.r);
          ang = lerp(K.a1, 1.35, k * k);
          o.lean = K.sl * (1 - k);
          o.handR = lerp(K.rs, 28, k);
        }
        o.swordA = ang;
        o.run = 0;
        break;
      }
      case "kame": {
        const charge = B.rage ? 0.95 : 1.15,
          k = B.phase === "charge" ? B.pt / charge : 1;
        o.crouch = 26 * Math.min(1, k * 1.6);
        o.lean = B.phase === "fire" ? 0.28 : lerp(-0.1, 0.12, k);
        o.swordA = 1.55;
        o.handR = 28;
        o.offTarget = { x: 36, y: -62 + o.crouch * 0 };
        o.glow = 8 + 10 * k;
        o.capeBack = 8 + 8 * k;
        o.run = 0;
        break;
      }
      case "explode": {
        const charge = B.rage ? 1.0 : 1.2;
        if (B.phase === "charge") {
          const k = B.pt / charge;
          o.swordA = lerp(1.35, -1.75, easeOut(Math.min(1, k * 2)));
          o.offTarget = {
            x: lerp(-8, 8, k),
            y: lerp(-52, -126, easeOut(Math.min(1, k * 2))),
          };
          o.crouch = 8 * k;
          o.lean = -0.12;
          o.glow = 8 + 16 * k;
          o.capeBack = 10 * k;
          o.shakeX = Math.sin(time * 70) * 1.2 * k;
        } else {
          const k = Math.min(1, B.pt / 0.5);
          o.swordA = lerp(-1.75, 0.5, easeOut(Math.min(1, k * 4)));
          o.offTarget = { x: -14, y: -80 };
          o.lean = 0.25 * (1 - k);
          o.glow = 20;
          o.capeBack = 14;
        }
        o.run = 0;
        break;
      }
      case "stunned":
        o.kneel = true;
        o.crouch = 26;
        o.lean = 0.32;
        o.swordA = 1.75;
        o.handR = 26;
        o.glow = 0;
        o.run = 0;
        o.shakeX = Math.sin(time * 40) * 0.8;
        break;
      case "dead": {
        const k = Math.min(1, B.dieT / 1.2);
        o.kneel = k < 1;
        o.crouch = 26 * Math.min(1, k * 3);
        o.lean = 0.32 + k * 0.3;
        o.swordA = 1.75;
        o.glow = 0;
        o.run = 0;
        o.alpha = clamp(1 - (B.dieT - 1.2) / 2.4, 0, 1);
        if (B.dieT > 1.2) o.flash = Math.floor(time * 20) % 2 === 0;
        break;
      }
    }
    if (o.shakeX) o.x += o.shakeX;
    return o;
  }

  /* ================= ARTORIAS (boss 2) ================= */
  const PAL_A = {
    dark: "#2a2d3a",
    mid: "#7d8395",
    light: "#cfd3e0",
    trim: "#a9b0c6",
    outline: "#090a11",
    leg: "#6a7081",
    legFar: "#43485a",
    cloak: "#2b58cf",
    cloakDark: "#173080",
    hair: "#121716",
    belt: "#7a4a2a",
    gold: "#c9a45a",
  };
  const RECT_A = {
    sweep: { x0: 8, x1: 215, h0: 0, h1: 65 },
    over: { x0: 8, x1: 190, h0: 0, h1: 170 },
    rise: { x0: -10, x1: 195, h0: 0, h1: 170 },
  };
  const STOP_A = { sweep: 120, over: 112, rise: 112 };
  const mkAA = (type, w, a, r, lunge) => ({
    type,
    w,
    a,
    r,
    lunge,
    rect: RECT_A[type],
    stop: STOP_A[type],
    dmg: 100,
  });
  const COMBOS_A = [
    {
      name: "Twin Swing",
      atks: [
        mkAA("over", 0.6, 0.13, 0.3, 80),
        mkAA("sweep", 0.46, 0.13, 0.95, 70),
      ],
    },
    {
      name: "Cross Swing",
      atks: [
        mkAA("sweep", 0.55, 0.13, 0.28, 80),
        mkAA("rise", 0.48, 0.13, 0.95, 60),
      ],
    },
    {
      name: "Triple Swing",
      atks: [
        mkAA("sweep", 0.52, 0.13, 0.26, 70),
        mkAA("over", 0.4, 0.13, 0.28, 70),
        mkAA("rise", 0.56, 0.13, 1.0, 60),
      ],
    },
    {
      name: "Abyss Triple",
      atks: [
        mkAA("over", 0.58, 0.13, 0.3, 80),
        mkAA("rise", 0.36, 0.13, 0.26, 60),
        mkAA("sweep", 0.66, 0.13, 1.05, 80),
      ],
    },
  ];
  // Phase 2 (below half health) raises every Artorias damage number by 40%.
  function bd(base) {
    return Math.round(
      base *
        (B.type === "art" && B.rage
          ? 1.4
          : B.type === "demon" && B.dphase === 3
            ? 1.3
            : B.type === "shogun" && B.sphase === 2
              ? 1.2
              : 1),
    );
  }
  function cropFrac(img, fx, fy, fw, fh, x, y, s) {
    if (img.complete && img.naturalWidth) {
      const w = img.naturalWidth,
        h = img.naturalHeight;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(img, fx * w, fy * h, fw * w, fh * h, x, y, s, s);
      ctx.imageSmoothingEnabled = true;
    } else {
      ctx.fillStyle = "#221a2a";
      ctx.fillRect(x, y, s, s);
    }
  }
  function artChoose() {
    const d = Math.abs(bossCombatTarget().x - B.x),
      r = Math.random();
    let pick;
    if (d > 420)
      pick =
        r < 0.35 ? "rush" : r < 0.65 ? "jump" : r < 0.8 ? "explode" : "walk";
    else if (d > 190)
      pick =
        r < 0.3 ? "combo" : r < 0.55 ? "jump" : r < 0.78 ? "rush" : "explode";
    else
      pick =
        r < 0.48 ? "combo" : r < 0.68 ? "explode" : r < 0.84 ? "jump" : "rush";
    if (pick === B.last && pick !== "walk" && Math.random() < 0.7)
      pick = pick === "combo" ? (d > 300 ? "jump" : "explode") : "combo";
    B.last = pick;
    if (pick === "walk") {
      B.cool = rnd(0.3, 0.6);
      return;
    }
    if (pick === "combo") {
      const three = Math.random() < 0.5;
      let i;
      do {
        i = (three ? 2 : 0) + Math.floor(Math.random() * 2);
      } while (i === B.lastCombo);
      B.lastCombo = i;
      B.combo = COMBOS_A[i];
      B.ci = 0;
      B.state = "combo";
      startBossAtk();
    } else if (pick === "jump") {
      B.state = "jump";
      B.phase = "crouch";
      B.pt = 0;
      B.jn = Math.random() < 0.45 ? 2 : 1;
      B.jfirst = true;
      B.h = 0;
    } else if (pick === "rush") {
      B.state = "rush";
      B.phase = "wind";
      B.pt = 0;
      B.rn = Math.random() < 0.5 ? 2 : 1;
      B.rfirst = true;
    } else {
      B.state = "explode";
      B.phase = "charge";
      B.pt = 0;
      B.expR = 0;
      sfx("charge");
    }
  }
  function artSlam() {
    sfx("boom");
    doShake(15);
    dust(B.x, GROUND, 14);
    petals(B.x, GROUND, 24, 420);
    addRing(B.x, GROUND - 4, 10, 190, 0.4, "rgba(160,200,255,.9)", 7);
    spark(B.x + B.face * 100, GROUND - 10, 20, "#bcd8ff", 500, 0.5);
    const f = B.face,
      lo = Math.min(B.x - f * 40, B.x + f * 205),
      hi = Math.max(B.x - f * 40, B.x + f * 205);
    if (heroType === "wizard") {
      for (const s of skeletons)
        if (s.hp > 0 && s.x + 14 > lo && s.x - 14 < hi)
          damageSkeleton(s, bd(200));
    }
    if (
      P.x + 15 > lo &&
      P.x - 15 < hi &&
      GROUND - P.y < 170 &&
      P.invuln <= 0 &&
      P.state !== "dead"
    )
      hurtPlayer(bd(200), B.x, true);
  }
  function artBlast() {
    sfx("boom");
    doShake(24);
    doFlash(0.65, "190,215,255");
    hitstop = 0.08;
    addRing(B.x, GROUND - 70, 20, 270, 0.5, "rgba(210,230,255,.95)", 10);
    addRing(B.x, GROUND - 70, 10, 200, 0.4, "rgba(90,140,255,.8)", 14);
    spark(B.x, GROUND - 70, 60, "#cfe2ff", 800, 0.9, 200);
    petals(B.x, GROUND, 90, 700);
    dust(B.x, GROUND, 24);
    const dist = Math.hypot(P.x - B.x, P.y - 50 - (GROUND - 70));
    damageSkeletonsInRange(B.x, 250, bd(300));
    if (dist <= 250 && P.invuln <= 0 && P.state !== "dead")
      hurtPlayer(bd(300), B.x, true);
    // small energy balls flying off in different directions (50 damage each)
    const n = B.rage ? 18 : 14;
    for (let i = 0; i < n; i++) {
      let o;
      if (i < 4) {
        const dir = i % 2 ? 1 : -1;
        o = {
          x: B.x,
          y: GROUND - 26 - (i > 1 ? 24 : 0),
          vx: dir * rnd(430, 540),
          vy: 0,
          g: 0,
        };
      } else {
        const a = -rnd(0.12, Math.PI - 0.12),
          s = rnd(300, 620);
        o = {
          x: B.x,
          y: GROUND - 70,
          vx: Math.cos(a) * s,
          vy: Math.sin(a) * s,
          g: 800,
        };
      }
      o.r = 12;
      o.life = 4;
      o.t = 0;
      o.dmg = bd(50);
      orbs.push(o);
    }
  }
  function updateArtCombo(dt) {
    const a = B.atk,
      rage = B.rage;
    B.pt += dt;
    const wS = a.w * (rage ? 0.86 : 1);
    if (B.phase === "wind") {
      if (B.pt < wS * 0.5) bossFace();
      if (B.pt > wS * 0.3 && Math.abs(bossCombatTarget().x - B.x) > a.stop)
        B.x += B.face * (a.lunge / (wS * 0.7)) * dt;
      if (B.pt >= wS) {
        B.phase = "act";
        B.pt = 0;
        B.hitDone = false;
        bossSlashFx(a);
      }
    } else if (B.phase === "act") {
      bossStrike(a);
      if (B.state !== "combo") return;
      if (B.pt >= a.a) {
        B.phase = "rec";
        B.pt = 0;
      }
    } else if (B.pt >= a.r * (rage ? 0.85 : 1)) {
      B.ci++;
      if (B.ci >= B.combo.atks.length) {
        B.state = "idle";
        B.cool = rnd(0.5, 0.95) * (rage ? 0.65 : 1);
      } else startBossAtk();
    }
  }
  function updateArt(dt) {
    const rage = B.rage,
      spd = rage ? 150 : 112;
    if (rage && B.state !== "dead" && Math.random() < 0.5)
      parts.push({
        k: "dot",
        x: B.x + rnd(-30, 30),
        y: GROUND - B.h - rnd(0, 150),
        vx: rnd(-15, 15),
        vy: rnd(-90, -30),
        life: rnd(0.5, 1),
        t: 0,
        col: "130,180,255",
        g: 0,
        drag: 1,
        sz: rnd(2, 4),
      });
    switch (B.state) {
      case "intro":
        B.introFill = Math.min(1, phaseT / 1.6);
        if (!B.roared && phaseT > 0.5) {
          B.roared = true;
          sfx("roar");
          doShake(14);
          addRing(B.x, GROUND - 60, 10, 280, 0.8, "rgba(140,190,255,.8)", 6);
          petals(B.x, GROUND, 40, 420);
        }
        break;
      case "idle":
        bossFace();
        if (Math.abs(bossCombatTarget().x - B.x) > 130) {
          B.x += B.face * spd * dt;
          B.moving = true;
          B.stride += spd * dt * 0.06;
        }
        B.cool -= dt;
        if (B.cool <= 0 && phase === "fight" && P.state !== "dead") artChoose();
        break;
      case "combo":
        updateArtCombo(dt);
        break;
      case "jump": {
        // Lion's Claw style leap-and-slam, once or twice in a row
        B.pt += dt;
        const durC = B.jfirst ? (rage ? 0.45 : 0.55) : 0.26;
        if (B.phase === "crouch") {
          if (B.pt < durC * 0.75) bossFace();
          if (B.pt >= durC) {
            B.phase = "air";
            B.pt = 0;
            B.jx0 = B.x;
            B.jx1 = clamp(bossCombatTarget().x - B.face * 75, 80, WORLD - 80);
            sfx("roar");
            dust(B.x, GROUND, 10);
          }
        } else if (B.phase === "air") {
          const T = rage ? 0.52 : 0.62,
            k = Math.min(1, B.pt / T);
          B.x = lerp(B.jx0, B.jx1, k);
          B.h = 4 * 240 * k * (1 - k);
          if (k >= 1) {
            B.phase = "slam";
            B.pt = 0;
            B.h = 0;
            artSlam();
          }
        } else if (B.phase === "slam") {
          if (B.pt >= 0.22) {
            B.jn--;
            B.jfirst = false;
            if (B.jn > 0) {
              B.phase = "crouch";
              B.pt = 0;
            } else {
              B.phase = "rec";
              B.pt = 0;
            }
          }
        } else if (B.pt >= (rage ? 0.65 : 0.85)) {
          B.state = "idle";
          B.cool = rnd(0.6, 1.1) * (rage ? 0.65 : 1);
          B.h = 0;
        }
        break;
      }
      case "rush": {
        // sword-first charge, once or twice in a row
        B.pt += dt;
        const windT = B.rfirst ? (rage ? 0.42 : 0.55) : 0.24;
        if (B.phase === "wind") {
          if (B.pt < windT * 0.8) bossFace();
          if (B.pt >= windT) {
            B.phase = "dash";
            B.pt = 0;
            B.hitDone = false;
            B.rdir = B.face;
            B.rdist = Math.max(420, Math.abs(bossCombatTarget().x - B.x) + 160);
            B.rmoved = 0;
            sfx("bswing");
            doShake(6);
          }
        } else if (B.phase === "dash") {
          const stepD = 1250 * dt;
          B.x += B.rdir * stepD;
          B.rmoved += stepD;
          parts.push({
            k: "dot",
            x: B.x,
            y: GROUND - rnd(20, 140),
            vx: 0,
            vy: 0,
            life: 0.3,
            t: 0,
            col: "150,195,255",
            g: 0,
            drag: 1,
            sz: rnd(6, 12),
          });
          if (!B.hitDone && P.state !== "dead") {
            const lo = Math.min(B.x - B.rdir * 20, B.x + B.rdir * 165),
              hi = Math.max(B.x - B.rdir * 20, B.x + B.rdir * 165);
            if (heroType === "wizard") {
              for (const s of skeletons) {
                if (s.hp > 0 && s.x + 14 > lo && s.x - 14 < hi) {
                  damageSkeleton(s, bd(150));
                  B.hitDone = true;
                  break;
                }
              }
            }
            const pb = GROUND - P.y;
            if (
              !B.hitDone &&
              P.x + 15 > lo &&
              P.x - 15 < hi &&
              pb < 112 &&
              P.invuln <= 0
            ) {
              if (hurtPlayer(bd(150), B.x, true)) B.hitDone = true;
            }
          }
          if (
            B.rmoved >= B.rdist ||
            B.pt > 0.5 ||
            B.x <= 70 ||
            B.x >= WORLD - 70
          ) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else {
          const recT = B.rn > 1 ? 0.12 : 0.8;
          if (B.pt >= recT) {
            B.rn--;
            B.rfirst = false;
            if (B.rn > 0) {
              B.phase = "wind";
              B.pt = 0;
            } else {
              B.state = "idle";
              B.cool = rnd(0.6, 1.1) * (rage ? 0.65 : 1);
            }
          }
        }
        break;
      }
      case "explode": {
        // blast (300) followed by energy balls (50 each)
        B.pt += dt;
        const charge = rage ? 0.95 : 1.15,
          burstT = 0.5,
          rec = 0.9;
        if (B.phase === "charge") {
          B.expR = 250 * Math.min(1, B.pt / charge);
          if (Math.random() < 0.8) {
            const a = rnd(0, TAU),
              rr = rnd(100, 200);
            parts.push({
              k: "gather",
              sx: B.x + Math.cos(a) * rr,
              sy: GROUND - 70 + Math.sin(a) * rr * 0.8,
              tx: B.x,
              ty: GROUND - 70,
              life: 0.45,
              t: 0,
              x: 0,
              y: 0,
              gc: "170,205,255",
            });
          }
          if (B.pt >= charge) {
            B.phase = "burst";
            B.pt = 0;
            artBlast();
          }
        } else if (B.phase === "burst") {
          if (B.pt >= burstT) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt >= rec) {
          B.state = "idle";
          B.cool = rnd(0.7, 1.2) * (rage ? 0.65 : 1);
        }
        break;
      }
      case "stunned":
        B.stunT -= dt;
        if (B.stunT <= 0) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "dead":
        B.dieT += dt;
        if (B.dieT > 0.8 && Math.random() < 0.9)
          parts.push({
            k: "dot",
            x: B.x + rnd(-40, 40),
            y: GROUND - rnd(0, 150),
            vx: rnd(-20, 20),
            vy: rnd(-120, -40),
            life: rnd(0.8, 1.6),
            t: 0,
            col: "150,195,255",
            g: -20,
            drag: 0.5,
            sz: rnd(2, 5),
          });
        if (B.dieT > 1 && Math.random() < 0.3) petals(B.x, GROUND - 60, 2, 200);
        break;
    }
  }
  /* ================= INFERNAL SHOGUN (boss 4) ================= */
  const SHOGUN_COMBOS = [
    { name: "Blazing Cross", count: 2 },
    { name: "Ember Trinity", count: 3 },
    { name: "Fourfold Judgment", count: 4 },
  ];
  function shogunHaz(kind, x, y, vx, vy, dmg, extra = {}) {
    shogunHazards.push({
      kind,
      x,
      y,
      vx,
      vy,
      dmg,
      t: 0,
      life: extra.life || 3,
      r: extra.r || 16,
      g: extra.g || 0,
      delay: extra.delay || 0,
      hit: false,
      index: extra.index || 0,
    });
  }
  function shogunTarget() {
    return bossCombatTarget();
  }
  function shogunDirectHit(dmg, range = 170) {
    const target = shogunTarget();
    if (target !== P) {
      if (target.hp > 0 && Math.abs(target.x - B.x) < range + 35)
        damageSkeleton(target, bd(dmg));
      return;
    }
    if (Math.abs(P.x - B.x) < range && GROUND - P.y < 155 && P.invuln <= 0)
      hurtPlayer(bd(dmg), B.x, true);
  }
  function beginShogunPhase2() {
    B.sphase = 2;
    B.state = "stransform";
    B.phase = "rise";
    B.pt = 0;
    B.h = 0;
    B.cool = 1;
    shogunHazards.length = 0;
    musicIntensify();
    sfx("demonRoar");
    doShake(24);
    doFlash(0.7, "35,10,45");
    addText(
      B.x,
      GROUND - 245,
      "BLACK-FLAME ASCENSION  +20% DAMAGE",
      "#c58cff",
      20,
      2.5,
    );
    addRing(B.x, GROUND - 85, 18, 360, 0.85, "rgba(70,20,95,.96)", 12);
    spark(B.x, GROUND - 90, 75, "#56206f", 850, 1.2, -60);
  }
  function damageShogunMinion(dmg) {
    if (!shogunMinion || shogunMinion.hp <= 0) return;
    shogunMinion.hp = Math.max(0, shogunMinion.hp - dmg);
    shogunMinion.flash = 0.16;
    addText(
      shogunMinion.x,
      GROUND - 130,
      "-" + Math.round(dmg),
      "#ff8f79",
      14,
      0.6,
    );
    spark(shogunMinion.x, GROUND - 70, 12, "#ff4c38", 300, 0.4, 220);
    if (shogunMinion.hp <= 0) {
      shogunMinion.state = "dead";
      shogunMinion.t = 0;
      sfx("hurt");
    }
  }
  function summonShogunMinion() {
    const side = B.face > 0 ? -1 : 1;
    shogunMinion = {
      x: clamp(B.x + side * 95, 50, WORLD - 50),
      hp: 500,
      maxhp: 500,
      face: -side,
      state: "spawn",
      t: 0,
      stride: 0,
      flash: 0,
      attackCD: 0.4,
      alpha: 0,
    };
    addRing(shogunMinion.x, GROUND - 3, 8, 58, 0.6, "rgba(255,45,30,.85)", 5);
    spark(shogunMinion.x, GROUND - 55, 28, "#ff4930", 360, 0.8, -80);
    sfx("skill1");
  }
  function shogunChoose() {
    const r = Math.random(),
      ph = B.sphase,
      d = Math.abs(shogunTarget().x - B.x);
    let pick;
    if (ph === 1) {
      if (d > 430) pick = r < 0.58 ? "arrows" : r < 0.78 ? "lunge" : r < 0.9 ? "lightning" : "rush";
      else pick = r < 0.34 ? "arrows" : ["combo2", "combo3", "lunge", "wave", "lightning", "rush"][Math.floor((r - 0.34) / 0.66 * 6)];
    } else {
      pick = r < 0.30 ? "arrows" : r < 0.45 ? "flyrain" : ["combo3", "combo4", "lunge", "wave", "lightning", "rush", "tele", "darkwaves", "summon"][Math.floor((r - 0.45) / 0.55 * 9)];
      if (pick === "summon" && shogunMinion && shogunMinion.hp > 0) pick = "darkwaves";
    }
    if (pick === B.last && Math.random() < 0.7) pick = d > 300 ? "arrows" : "combo3";
    B.last = pick;
    B.pt = 0;
    B.hitDone = false;
    B.sIndex = 0;
    B.sNext = 0;
    if (pick.startsWith("combo")) {
      B.state = "scombo";
      B.phase = "wind";
      B.sCount = Number(pick.slice(-1));
    } else if (pick === "lunge") {
      B.state = "slunge";
      B.phase = "wind";
      B.sCount = 1 + Math.floor(Math.random() * 2);
    } else if (pick === "wave") {
      B.state = "swave";
      B.phase = "charge";
    } else if (pick === "lightning") {
      B.state = "slightning";
      B.phase = "cast";
      B.sCount = 5;
    } else if (pick === "arrows") {
      B.state = "sarrows";
      B.phase = "draw";
      B.sCount = ph === 2 ? 8 : 6;
    } else if (pick === "rush") {
      B.state = "srush";
      B.phase = "vanish";
    } else if (pick === "tele") {
      B.state = "stele";
      B.phase = "vanish";
    } else if (pick === "flyrain") {
      B.state = "sflyrain";
      B.phase = "rise";
      B.sCount = 8;
    } else if (pick === "darkwaves") {
      B.state = "sdarkwaves";
      B.phase = "cast";
      B.sCount = 6;
    } else {
      B.state = "ssummon";
      B.phase = "cast";
    }
    sfx(pick === "rush" || pick === "tele" ? "dodge" : "charge");
  }
  function updateShogunMinion(dt) {
    const m = shogunMinion;
    if (!m) return;
    m.t += dt;
    m.flash = Math.max(0, m.flash - dt);
    if (m.state === "dead") {
      m.alpha -= dt * 0.75;
      if (m.alpha <= 0) shogunMinion = null;
      return;
    }
    if (m.state === "spawn") {
      m.alpha = Math.min(1, m.alpha + dt * 2.2);
      if (m.t > 0.75) {
        m.state = "walk";
        m.t = 0;
      }
      return;
    }
    m.face = P.x >= m.x ? 1 : -1;
    const d = Math.abs(P.x - m.x);
    m.attackCD = Math.max(0, m.attackCD - dt);
    if (m.state === "attack") {
      if (m.t >= 0.22 && m.t - dt < 0.22 && d < 92 && P.invuln <= 0) {
        hurtPlayer(70, m.x, false);
        addArc(
          m.x,
          GROUND - 70,
          75,
          -2.1,
          0.75,
          m.face,
          0.17,
          "rgba(255,55,40,.9)",
          7,
        );
      }
      if (m.t > 0.58) {
        m.state = "walk";
        m.t = 0;
        m.attackCD = 0.5;
      }
    } else if (d > 72) {
      m.x += m.face * 145 * dt;
      m.stride += dt * 9;
    } else if (m.attackCD <= 0) {
      m.state = "attack";
      m.t = 0;
    }
  }
  function updateShogunHazards(dt) {
    for (let i = shogunHazards.length - 1; i >= 0; i--) {
      const h = shogunHazards[i];
      h.t += dt;
      let dead = h.t > h.life;
      if (h.kind === "lightning") {
        if (h.t >= h.delay && h.t - dt < h.delay) {
          doShake(7);
          sfx("crack");
          spark(
            h.x,
            GROUND - 60,
            28,
            h.index % 2 ? "#b882ff" : "#ffd36b",
            520,
            0.45,
            0,
          );
          damageSkeletonsInRange(h.x, 48, bd(200));
          if (Math.abs(P.x - h.x) < 45 && GROUND - P.y < 170 && P.invuln <= 0)
            hurtPlayer(bd(200), h.x, true);
        }
      } else {
        h.vy += h.g * dt;
        h.x += h.vx * dt;
        h.y += h.vy * dt;
        if (h.kind === "rain" && h.y >= GROUND - 8) {
          damageSkeletonsInRange(h.x, 55, bd(100));
          if (Math.abs(P.x - h.x) < 48 && GROUND - P.y < 110 && P.invuln <= 0)
            hurtPlayer(bd(100), h.x, true);
          spark(h.x, GROUND - 10, 18, "#7d3a9b", 420, 0.4, 120);
          dead = true;
        }
        if (!dead && !h.hit && heroType === "wizard") {
          for (const s of skeletons) {
            if (
              s.hp > 0 &&
              Math.abs(s.x - h.x) < h.r + 15 &&
              Math.abs(GROUND - 60 - h.y) < h.r + 55
            ) {
              damageSkeleton(s, h.dmg);
              h.hit = true;
              dead = true;
              break;
            }
          }
        }
        if (!dead && !h.hit && P.invuln <= 0 && P.state !== "dead") {
          const dx = Math.abs(P.x - h.x),
            dy = Math.abs(P.y - 55 - h.y);
          let hit = dx < h.r + 15 && dy < h.r + 52;
          if (h.kind === "firewave" || h.kind === "darklow")
            hit = dx < h.r + 18 && GROUND - P.y < 78;
          if (h.kind === "darkhigh")
            hit = dx < h.r + 18 && GROUND - P.y > 55 && GROUND - P.y < 155;
          if (hit) {
            hurtPlayer(
              h.dmg,
              h.x,
              h.kind.includes("wave") || h.kind.includes("dark"),
            );
            h.hit = true;
            dead = true;
          }
        }
        if (h.x < -80 || h.x > WORLD + 80 || h.y > GROUND + 80) dead = true;
      }
      if (dead) shogunHazards.splice(i, 1);
    }
  }
  function updateShogun(dt) {
    B.sparryT = Math.max(0, B.sparryT - dt);
    B.moving = false;
    const target = shogunTarget(),
      spd = B.sphase === 2 ? 165 : 125;
    if (B.sphase === 2 && B.state !== "dead" && Math.random() < dt * 24)
      parts.push({
        k: "dot",
        x: B.x + rnd(-35, 35),
        y: GROUND - B.h - rnd(35, 175),
        vx: rnd(-25, 25),
        vy: rnd(-100, -30),
        life: rnd(0.4, 0.9),
        t: 0,
        col: "65,20,85",
        g: -20,
        drag: 1,
        sz: rnd(2, 5),
      });
    switch (B.state) {
      case "intro":
        B.introFill = Math.min(1, phaseT / 1.6);
        if (!B.roared && phaseT > 0.5) {
          B.roared = true;
          sfx("roar");
          doShake(14);
          addRing(B.x, GROUND - 70, 10, 280, 0.8, "rgba(255,85,35,.85)", 7);
        }
        break;
      case "idle": {
        bossFace();
        const dist = Math.abs(target.x - B.x),
          desired = dist > 360 ? B.face * spd : dist < 220 ? -B.face * spd * 0.55 : 0;
        B.moveV += (desired - B.moveV) * Math.min(1, dt * 6.2);
        if (!desired) B.moveV *= Math.max(0, 1 - dt * 8);
        B.x += B.moveV * dt;
        B.moving = Math.abs(B.moveV) > 7;
        B.stride += Math.abs(B.moveV) * dt * 0.047;
        B.moveLean += ((B.moveV / Math.max(1, spd)) * 0.12 - B.moveLean) * Math.min(1, dt * 8);
        if ((B.cool -= dt) <= 0 && phase === "fight" && P.state !== "dead") shogunChoose();
        break;
      }
      case "stransform":
        B.pt += dt;
        B.h = 55 * Math.sin(Math.min(1, B.pt / 2.3) * Math.PI);
        if (Math.random() < 0.8)
          spark(
            B.x + rnd(-45, 45),
            GROUND - B.h - rnd(20, 180),
            1,
            "#4d175f",
            380,
            0.5,
            -80,
          );
        if (B.pt >= 2.65) {
          B.h = 0;
          B.state = "idle";
          B.cool = 0.6;
        }
        break;
      case "scombo": {
        B.pt += dt;
        const wind = B.sIndex === 0 ? 0.56 : 0.46,
          act = 0.18,
          rec = B.sIndex === B.sCount - 1 ? 0.68 : 0.31;
        if (B.phase === "wind") {
          bossFace();
          if (Math.abs(target.x - B.x) > 145) B.x += B.face * 155 * dt;
          if (B.pt >= wind) {
            B.phase = "act";
            B.pt = 0;
            B.hitDone = false;
            sfx("bswing");
            addArc(
              B.x,
              GROUND - 105,
              155,
              B.sIndex % 2 ? -2.5 : 2.5,
              B.sIndex % 2 ? 0.55 : -0.45,
              B.face,
              0.2,
              B.sphase === 2 ? "rgba(90,35,120,.95)" : "rgba(255,90,30,.95)",
              13,
            );
          }
        } else if (B.phase === "act") {
          if (!B.hitDone && B.pt > 0.075) {
            B.hitDone = true;
            shogunDirectHit(130, 185);
          }
          if (B.pt >= act) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt >= rec) {
          if (++B.sIndex >= B.sCount) {
            B.state = "idle";
            B.cool = 0.62;
          } else {
            B.phase = "wind";
            B.pt = 0;
          }
        }
        break;
      }
      case "slunge":
        B.pt += dt;
        if (B.phase === "wind") {
          bossFace();
          if (B.pt > 0.42) {
            B.phase = "dash";
            B.pt = 0;
            B.hitDone = false;
            sfx("bswing");
          }
        } else if (B.phase === "dash") {
          B.x += B.face * 950 * dt;
          addStreak(
            B.x - B.face * 70,
            GROUND - 92,
            B.face * 150,
            B.sphase === 2 ? "rgba(90,30,120,.9)" : "rgba(255,95,30,.9)",
            0.14,
          );
          if (!B.hitDone && Math.abs(target.x - B.x) < 150) {
            B.hitDone = true;
            shogunDirectHit(150, 170);
          }
          if (B.pt > 0.22) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt > 0.26) {
          if (++B.sIndex < B.sCount) {
            B.phase = "wind";
            B.pt = 0;
          } else {
            B.state = "idle";
            B.cool = 0.5;
          }
        }
        break;
      case "swave":
        B.pt += dt;
        bossFace();
        if (B.phase === "charge" && B.pt > 0.6) {
          B.phase = "rec";
          B.pt = 0;
          shogunHaz(
            "firewave",
            B.x + B.face * 70,
            GROUND - 28,
            B.face * 570,
            0,
            bd(200),
            { r: 30, life: 3 },
          );
          sfx("boom");
          addRing(B.x, GROUND - 25, 8, 95, 0.3, "rgba(255,80,25,.9)", 7);
        } else if (B.phase === "rec" && B.pt > 0.65) {
          B.state = "idle";
          B.cool = 0.55;
        }
        break;
      case "sballs":
        B.pt += dt;
        bossFace();
        if (B.phase === "charge" && B.pt > 0.42) {
          B.phase = "fire";
          B.pt = 0;
          B.sNext = 0;
        } else if (
          B.phase === "fire" &&
          B.sIndex < B.sCount &&
          B.pt >= B.sNext
        ) {
          B.sNext += 0.2;
          B.sIndex++;
          const t = shogunTarget(),
            ox = B.x + B.face * 58,
            oy = GROUND - B.h - 118,
            a = Math.atan2((t === P ? P.y - 55 : GROUND - 60) - oy, t.x + (t === P ? P.vx * 0.12 : 0) - ox);
          shogunHaz(
            "fireball",
            ox,
            oy,
            Math.cos(a) * 600,
            Math.sin(a) * 600,
            bd(100),
            { r: 16, life: 3 },
          );
          sfx("beam");
        } else if (
          B.phase === "fire" &&
          B.sIndex >= B.sCount &&
          B.pt > B.sNext + 0.25
        ) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "slightning":
        B.pt += dt;
        if (B.phase === "cast" && B.pt > 0.35) {
          const tx = target.x;
          for (let i = 0; i < 5; i++)
            shogunHaz(
              "lightning",
              clamp(tx + rnd(-380, 380), 50, WORLD - 50),
              GROUND,
              0,
              0,
              bd(200),
              { delay: 1.5 + i * 0.08, life: 2, index: i },
            );
          B.phase = "rec";
          B.pt = 0;
          sfx("charge");
        } else if (B.phase === "rec" && B.pt > 2) {
          B.state = "idle";
          B.cool = 0.65;
        }
        break;
      case "sarrows":
        B.pt += dt;
        bossFace();
        if (B.phase === "draw" && B.pt > 0.62) {
          B.phase = "fire";
          B.pt = 0;
          B.sNext = 0;
        } else if (B.phase === "fire" && B.sIndex < B.sCount && B.pt >= B.sNext) {
          B.sNext += 0.16;
          B.sIndex++;
          const t = shogunTarget(),
            ox = B.x + B.face * 48,
            oy = GROUND - 128,
            a = Math.atan2((t === P ? P.y - 55 : GROUND - 60) - oy, t.x - ox);
          shogunHaz(
            "arrow",
            ox,
            oy,
            Math.cos(a) * 820,
            Math.sin(a) * 820,
            bd(80),
            { r: 8, life: 2.8 },
          );
          sfx("shot");
        } else if (
          B.phase === "fire" &&
          B.sIndex >= B.sCount &&
          B.pt > B.sNext + 0.25
        ) {
          B.state = "idle";
          B.cool = 0.48;
        }
        break;
      case "srush":
        B.pt += dt;
        if (B.phase === "vanish" && B.pt > 0.18) {
          B.x = clamp(target.x - B.face * 135, 60, WORLD - 60);
          B.face = target.x >= B.x ? 1 : -1;
          B.phase = "appear";
          B.pt = 0;
          sfx("dodge");
          addRing(B.x, GROUND - 75, 6, 85, 0.25, "rgba(255,75,25,.8)", 5);
        } else if (B.phase === "appear" && B.pt > 0.24) {
          B.state = "idle";
          B.cool = 0.25;
        }
        break;
      case "stele":
        B.pt += dt;
        if (B.phase === "vanish" && B.pt > 0.28) {
          B.x = clamp(
            target.x + (target === P ? -P.face : -B.face) * 105,
            60,
            WORLD - 60,
          );
          B.face = target.x >= B.x ? 1 : -1;
          B.phase = "slash";
          B.pt = 0;
          B.hitDone = false;
          doFlash(0.2, "45,10,60");
        } else if (B.phase === "slash" && !B.hitDone && B.pt > 0.16) {
          B.hitDone = true;
          shogunDirectHit(150, 175);
          addArc(
            B.x,
            GROUND - 105,
            165,
            -2.4,
            0.7,
            B.face,
            0.2,
            "rgba(90,35,125,.98)",
            15,
          );
        } else if (B.phase === "slash" && B.pt > 0.58) {
          B.state = "idle";
          B.cool = 0.45;
        }
        break;
      case "sflyrain":
        B.pt += dt;
        if (B.phase === "rise") {
          B.h = Math.min(185, B.h + 300 * dt);
          if (B.h >= 185) {
            B.phase = "rain";
            B.pt = 0;
            B.sIndex = 0;
            B.sNext = 0;
          }
        } else if (B.phase === "rain" && B.sIndex < 8 && B.pt >= B.sNext) {
          B.sNext += 0.18;
          B.sIndex++;
          shogunHaz(
            "rain",
            clamp(target.x + rnd(-270, 270), 45, WORLD - 45),
            -80 - rnd(0, 100),
            rnd(-30, 30),
            rnd(340, 440),
            bd(100),
            { r: 18, g: 180, life: 4 },
          );
          sfx("beam");
        } else if (
          B.phase === "rain" &&
          B.sIndex >= 8 &&
          B.pt > B.sNext + 0.25
        ) {
          B.phase = "land";
          B.pt = 0;
        } else if (B.phase === "land") {
          B.h = Math.max(0, B.h - 380 * dt);
          if (B.h <= 0) {
            dust(B.x, GROUND, 12);
            B.state = "idle";
            B.cool = 0.6;
          }
        }
        break;
      case "sdarkwaves":
        B.pt += dt;
        bossFace();
        if (B.sIndex < 6 && B.pt >= B.sNext) {
          B.sNext += 0.42;
          const high = B.sIndex % 2 === 1;
          B.sIndex++;
          shogunHaz(
            high ? "darkhigh" : "darklow",
            B.x + B.face * 72,
            high ? GROUND - 118 : GROUND - 28,
            B.face * 510,
            0,
            bd(100),
            { r: high ? 34 : 38, life: 3 },
          );
          sfx("beam");
        } else if (B.sIndex >= 6 && B.pt > B.sNext + 0.35) {
          B.state = "idle";
          B.cool = 0.6;
        }
        break;
      case "ssummon":
        B.pt += dt;
        if (B.pt > 0.58 && !shogunMinion) {
          summonShogunMinion();
        }
        if (B.pt > 1) {
          B.state = "idle";
          B.cool = 0.6;
        }
        break;
      case "stunned":
        if ((B.stunT -= dt) <= 0) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "dead":
        B.dieT += dt;
        break;
    }
    B.x = clamp(B.x, 60, WORLD - 60);
  }
  function drawShogunKatana(c, x, y, a, dark = false, size = 1) {
    c.save();
    c.translate(x, y);
    c.rotate(a);
    c.scale(size, size);
    c.strokeStyle = "#120a0b";
    c.lineWidth = 8;
    c.beginPath();
    c.moveTo(-15, 0);
    c.lineTo(6, 0);
    c.stroke();
    c.strokeStyle = "#d0a14d";
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(1, -8);
    c.lineTo(1, 8);
    c.stroke();
    const g = c.createLinearGradient(5, 0, 100, 0);
    g.addColorStop(0, "#fff7dc");
    g.addColorStop(0.35, dark ? "#74358d" : "#ffbb55");
    g.addColorStop(0.75, dark ? "#1c102b" : "#ff4d22");
    g.addColorStop(1, "rgba(255,255,255,.2)");
    c.strokeStyle = g;
    c.shadowColor = dark ? "#6e2c91" : "#ff5525";
    c.shadowBlur = 18;
    c.lineWidth = 7;
    c.beginPath();
    c.moveTo(5, 0);
    c.quadraticCurveTo(58, -4, 100, -12);
    c.stroke();
    c.shadowBlur = 0;
    c.strokeStyle = "#fff6d5";
    c.lineWidth = 1.3;
    c.beginPath();
    c.moveTo(9, -2);
    c.quadraticCurveTo(58, -5, 94, -12);
    c.stroke();
    c.restore();
  }
  function shogunObj() {
    const st = B.state,
      idleA = 0.92;
    const o = {
      x: B.x,
      y: GROUND - B.h,
      face: B.face,
      scale: 1.43,
      run: B.moving ? 0.78 : 0,
      phase: B.stride,
      swordA: idleA + Math.sin(time * 1.7) * 0.025,
      offA: 1.42,
      handR: 31,
      crouch: 5,
      lean: B.moveLean || 0,
      cast: 0,
      bow: false,
      bowDraw: 0,
      wingSpread: B.sphase === 2 ? 0.34 : 0.13,
      dark: B.sphase === 2,
      alpha: (st === "srush" || st === "stele") && B.phase === "vanish" ? 0.22 : 1,
      flash: B.flash > 0 || B.sparryT > 0,
      rot: 0,
    };
    if (st === "scombo") {
      const first = B.sIndex === 0,
        wind = first ? 0.56 : 0.46,
        rec = B.sIndex === B.sCount - 1 ? 0.68 : 0.31,
        windA = [-2.08, 2.42, -1.72, 2.72][B.sIndex % 4],
        hitA = [0.72, -0.58, 1.02, -0.78][B.sIndex % 4];
      if (B.phase === "wind") {
        const k = easeOut(clamp(B.pt / wind, 0, 1));
        o.swordA = lerp(idleA, windA, k);
        o.handR = lerp(31, 25, k);
        o.crouch = 5 + 8 * k;
        o.lean -= 0.16 * k;
      } else if (B.phase === "act") {
        const k = ease(clamp(B.pt / 0.18, 0, 1));
        o.swordA = lerp(windA, hitA, k);
        o.handR = lerp(25, 43, k);
        o.crouch = 10 - 4 * k;
        o.lean += lerp(-0.1, 0.3, k);
      } else {
        const k = easeOut(clamp(B.pt / rec, 0, 1));
        o.swordA = lerp(hitA, idleA, k);
        o.handR = lerp(43, 31, k);
        o.lean += 0.19 * (1 - k);
      }
      o.run = 0;
    } else if (st === "slunge") {
      const k = B.phase === "wind" ? ease(clamp(B.pt / 0.42, 0, 1)) : 1;
      o.swordA = lerp(idleA, -0.04, k);
      o.handR = lerp(31, 48, k);
      o.crouch = B.phase === "dash" ? 17 : 5 + 10 * k;
      o.lean += B.phase === "dash" ? 0.46 : -0.14 * k;
      o.run = 0;
      o.wingSpread += B.phase === "dash" ? 0.22 : 0;
    } else if (st === "sarrows") {
      o.bow = true;
      o.bowDraw = B.phase === "draw"
        ? ease(clamp(B.pt / 0.62, 0, 1))
        : Math.max(0.08, 1 - (B.pt % 0.16) / 0.1);
      o.crouch = 7;
      o.lean -= 0.08 + o.bowDraw * 0.04;
      o.run = 0;
    } else if (st === "sflyrain") {
      o.bow = true;
      o.bowDraw = B.phase === "rain" ? 0.82 : 0.35;
      o.crouch = 2;
      o.lean += 0.06;
      o.wingSpread = 1;
      o.run = 0;
    } else if (st === "stele") {
      o.swordA = B.phase === "slash" ? lerp(-2.35, 0.72, ease(clamp(B.pt / 0.25, 0, 1))) : -1.6;
      o.handR = 42;
      o.crouch = 10;
      o.lean += 0.28;
      o.run = 0;
      o.wingSpread += 0.25;
    } else if (st === "swave" || st === "sdarkwaves") {
      o.swordA = -1.28;
      o.offA = -0.72;
      o.cast = 1;
      o.crouch = 8;
      o.lean -= 0.1;
      o.run = 0;
    } else if (st === "slightning" || st === "ssummon" || st === "sballs") {
      o.offA = -1.12;
      o.swordA = 1.3;
      o.cast = 1;
      o.crouch = 7;
      o.run = 0;
    } else if (st === "stransform") {
      o.swordA = -1.55;
      o.offA = -1.72;
      o.crouch = 10;
      o.lean -= 0.12;
      o.wingSpread = ease(clamp(B.pt / 1.4, 0, 1));
      o.cast = 1;
      o.run = 0;
    } else if (st === "stunned") {
      o.swordA = 1.68;
      o.offA = 0.8;
      o.crouch = 27;
      o.lean += 0.34;
      o.run = 0;
    } else if (st === "dead") {
      o.swordA = 1.65;
      o.crouch = 28;
      o.lean += 0.42;
      o.rot = -Math.min(1.15, B.dieT * 0.65);
      o.alpha *= clamp(1 - (B.dieT - 1.1) / 2.2, 0, 1);
      o.run = 0;
    }
    return o;
  }
  function drawShogun(c, o = shogunObj()) {
    const run = o.run || 0,
      ph = o.phase || 0,
      crouch = o.crouch || 0,
      hipY = -43 + crouch * 0.72,
      stepBob = run * Math.abs(Math.sin(ph)) * 2.7,
      p = {
        ink: "#040507",
        black: o.dark ? "#070812" : "#0a0b0f",
        lacquer: o.dark ? "#171426" : "#25151a",
        red: o.dark ? "#421449" : "#771d24",
        red2: o.dark ? "#713066" : "#b13638",
        gold: "#bc8f47",
        gold2: "#f0ce82",
        silver: "#d9d7ca",
        steel: "#77808b",
      };
    c.save();
    c.translate(o.x, o.y - stepBob);
    c.scale(o.face * o.scale, o.scale);
    c.rotate((o.lean || 0) + (o.rot || 0) + Math.sin(ph) * run * 0.014);
    c.globalAlpha = o.alpha;
    if (o.flash) c.filter = "brightness(2.25) saturate(.45)";

    // Articulated feathered wings. Folded in neutral poses, fully opened only in flight/phase actions.
    const ws = clamp(o.wingSpread || 0, 0, 1),
      beat = Math.sin(time * (ws > 0.7 ? 6.2 : 2.15) + ph * 0.18),
      lift = beat * (4 + ws * 12);
    c.save();
    c.globalAlpha *= 0.66 + ws * 0.25;
    for (const side of [-1, 1]) {
      const root = { x: side * 9, y: -92 },
        elbow = { x: side * (17 + ws * 47), y: -118 - lift * side },
        tip = { x: side * (26 + ws * 95), y: -66 - ws * 48 - lift * side };
      c.strokeStyle = p.ink;
      c.lineWidth = 8;
      c.beginPath(); c.moveTo(root.x, root.y); c.quadraticCurveTo(elbow.x, elbow.y, tip.x, tip.y); c.stroke();
      c.strokeStyle = o.dark ? "#515672" : "#69303a";
      c.lineWidth = 4;
      c.stroke();
      for (let i = 0; i < 8; i++) {
        const q = i / 7,
          bx = lerp(root.x, tip.x, q),
          by = lerp(root.y, tip.y, q) + Math.sin(q * Math.PI) * -18,
          len = (17 + i * 4.5) * (0.48 + ws * 0.52),
          tx = bx + side * len,
          ty = by + 23 + i * 3.5 + lift * side * q;
        c.fillStyle = i % 2 ? p.black : p.lacquer;
        c.strokeStyle = p.ink;
        c.lineWidth = 1.1;
        c.beginPath();
        c.moveTo(bx, by);
        c.quadraticCurveTo(bx + side * len * .58, by - 7, tx, ty);
        c.quadraticCurveTo(bx + side * len * .42, by + 9, bx, by);
        c.fill(); c.stroke();
        c.strokeStyle = "rgba(179,72,78,.28)";
        c.beginPath(); c.moveTo(bx + side * 4, by + 1); c.lineTo(tx - side * 4, ty - 1); c.stroke();
      }
    }
    c.restore();

    // Torn crimson scarf/cape responds to locomotion and attacks.
    const cloth = Math.sin(time * 2.7 + ph * 0.1) * 4 - run * 12 - (B.state === "slunge" ? 18 : 0);
    c.save();
    const cg = c.createLinearGradient(-8, -97, -55, -18);
    cg.addColorStop(0, p.red2); cg.addColorStop(.52, p.red); cg.addColorStop(1, "#18070b");
    c.fillStyle = cg; c.strokeStyle = p.ink; c.lineWidth = 1.6;
    c.beginPath();
    c.moveTo(-11, -94); c.lineTo(12, -92); c.lineTo(18 + cloth, -52);
    c.lineTo(30 + cloth, -11); c.lineTo(17 + cloth, 2); c.lineTo(7 + cloth, -7);
    c.lineTo(-3 + cloth, 5); c.lineTo(-12 + cloth, -8); c.lineTo(-25 + cloth, -1);
    c.lineTo(-27 + cloth, -49); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle = "rgba(238,88,82,.36)"; c.lineWidth = 1;
    for (let i = 0; i < 3; i++) { c.beginPath(); c.moveTo(-5 + i * 7, -88); c.quadraticCurveTo(-8 + cloth, -45, -10 + cloth + i * 9, -8); c.stroke(); }
    c.restore();

    // Legs use the same IK system as Heroes 3 and 4.
    let f1 = { x: -9 + Math.sin(ph) * 17 * run, y: -Math.max(0, Math.cos(ph)) * 9 * run },
      f2 = { x: 9 + Math.sin(ph + Math.PI) * 17 * run, y: -Math.max(0, Math.cos(ph + Math.PI)) * 9 * run };
    if (B.h > 5) { f1 = { x: -15, y: -16 }; f2 = { x: 18, y: -25 }; }
    if (B.state === "slunge" && B.phase === "dash") { f1 = { x: -24, y: -2 }; f2 = { x: 23, y: -1 }; }
    const leg = (hx, f, far) => {
      const k = ik(hx, hipY, f.x, f.y, 25, 26, -1);
      limb(c, [{x:hx,y:hipY},{x:k.x,y:k.y},{x:k.tx,y:k.ty}], 12, p.ink, far ? "#111117" : p.lacquer, p.steel);
      // layered greave
      c.save(); c.translate(k.x,k.y); c.rotate(Math.atan2(k.ty-k.y,k.tx-k.x));
      poly(c,[[-5,-7],[17,-7],[23,0],[17,7],[-5,7]],far?"#17131a":"#2c1a20",p.ink,1.2);
      c.strokeStyle=p.gold; c.lineWidth=1; for(let x=2;x<18;x+=6){c.beginPath();c.moveTo(x,-6);c.lineTo(x,6);c.stroke();}
      c.restore();
      c.fillStyle=p.black; c.strokeStyle=p.ink; c.lineWidth=1;
      c.beginPath(); c.ellipse(k.tx+4,k.ty-2,12,4.7,0,0,TAU); c.fill(); c.stroke();
    };
    leg(-6,f1,true); leg(6,f2,false);

    // Hakama and plated waist move independently from the legs.
    const skirtSway = Math.sin(time * 2.2 + ph * .1) * 2 - run * 5;
    poly(c,[[-18,hipY-5],[18,hipY-5],[27+skirtSway,1],[14+skirtSway,-5],[6+skirtSway,4],[-3+skirtSway,-6],[-14+skirtSway,3],[-27+skirtSway,-5]],p.black,p.ink,1.5);
    for(let i=-2;i<=2;i++) poly(c,[[i*8-5,hipY-3],[i*8+4,hipY-3],[i*8+7,-17],[i*8,-11],[i*8-7,-18]],i%2?p.lacquer:p.red,p.gold,1);

    c.save();
    c.translate(0,crouch*.55);
    // Layered black-lacquer torso with red lacing and gold trim.
    const armorG=c.createLinearGradient(-22,-92,23,-43);
    armorG.addColorStop(0,p.black); armorG.addColorStop(.45,p.lacquer); armorG.addColorStop(1,"#09090d");
    c.fillStyle=armorG; c.strokeStyle=p.ink; c.lineWidth=1.8;
    c.beginPath(); c.moveTo(-23,-82); c.quadraticCurveTo(0,-100,24,-82); c.lineTo(18,-45); c.quadraticCurveTo(0,-35,-18,-46); c.closePath(); c.fill(); c.stroke();
    c.strokeStyle=p.gold; c.lineWidth=1.5;
    for(let y=-80;y<=-50;y+=8){c.beginPath();c.moveTo(-18,y);c.quadraticCurveTo(0,y+5,18,y);c.stroke();}
    c.strokeStyle=p.red2; c.lineWidth=2;
    for(let x=-12;x<=12;x+=8){c.beginPath();c.moveTo(x-4,-84);c.lineTo(x+4,-47);c.stroke();}
    c.fillStyle=p.gold2; c.beginPath(); c.arc(0,-45,4.5,0,TAU); c.fill(); c.strokeStyle=p.ink; c.stroke();

    // Multi-layer shoulder armor creates a stronger samurai silhouette.
    const shoulderPlate=(x,y,far)=>{
      for(let i=0;i<3;i++){
        const yy=y+i*7, out=x+(x<0?-i*4:i*4);
        poly(c,[[out-14,yy-6],[out+14,yy-5],[out+12,yy+5],[out-12,yy+6]],i===0?p.gold:(far?p.lacquer:p.red),p.ink,1.2);
        c.strokeStyle=i===0?p.gold2:p.gold; c.lineWidth=.9; c.beginPath();c.moveTo(out-10,yy-3);c.lineTo(out+10,yy-2);c.stroke();
      }
    };
    shoulderPlate(-23,-82,true); shoulderPlate(23,-82,false);

    // Hair knot and wind-reactive black mane behind the mask.
    c.fillStyle="#050609"; c.beginPath(); c.ellipse(-2,-116,21,25,0,0,TAU); c.fill();
    const hairWind=Math.sin(time*3+ph*.12)*3-run*8-(B.state==="slunge"?10:0);
    c.lineCap="round";
    for(let i=0;i<6;i++){c.strokeStyle=i%2?"#08090d":"#15131a";c.lineWidth=5-i*.45;c.beginPath();c.moveTo(-8,-118+i*4);c.bezierCurveTo(-22,-125+i*4,-30+hairWind,-110+i*6,-40+hairWind-i*2,-99+i*8);c.stroke();}
    c.lineCap="butt";
    c.fillStyle=p.black; c.strokeStyle=p.ink; c.lineWidth=1.3;
    c.beginPath(); c.ellipse(1,-139,6.5,11,-0.12,0,TAU); c.fill(); c.stroke();
    c.strokeStyle=p.red2; c.lineWidth=2.4; c.beginPath(); c.moveTo(-5,-135); c.lineTo(7,-137); c.stroke();
    c.strokeStyle="#15131a"; c.lineWidth=5; c.lineCap="round"; c.beginPath(); c.moveTo(2,-147); c.quadraticCurveTo(11,-157,5,-164); c.stroke(); c.lineCap="butt";

    // Silver-gold oni mask based on the supplied reference, with readable eyes and jaw.
    const mg=c.createLinearGradient(-16,-124,17,-91); mg.addColorStop(0,"#fff7dc");mg.addColorStop(.45,p.silver);mg.addColorStop(1,"#706b61");
    c.fillStyle=mg;c.strokeStyle=p.ink;c.lineWidth=1.7;
    c.beginPath();c.moveTo(-16,-121);c.lineTo(-9,-130);c.lineTo(0,-126);c.lineTo(10,-130);c.lineTo(17,-119);c.lineTo(14,-102);c.lineTo(7,-91);c.lineTo(0,-86);c.lineTo(-8,-92);c.lineTo(-15,-103);c.closePath();c.fill();c.stroke();
    // brow horns and engraved curls
    poly(c,[[-12,-122],[-23,-133],[-16,-113]],p.gold2,p.ink,1); poly(c,[[12,-122],[23,-133],[16,-113]],p.gold2,p.ink,1);
    c.strokeStyle=p.gold;c.lineWidth=1.4;
    c.beginPath();c.moveTo(0,-125);c.lineTo(0,-89);c.moveTo(-12,-105);c.quadraticCurveTo(0,-97,12,-105);c.moveTo(-10,-115);c.quadraticCurveTo(-4,-121,0,-113);c.quadraticCurveTo(5,-121,11,-114);c.stroke();
    poly(c,[[-14,-108],[-5,-104],[-7,-97],[-15,-101]],"#aaa99f",p.ink,.9);
    poly(c,[[14,-108],[5,-104],[7,-97],[15,-101]],"#8f8d84",p.ink,.9);
    poly(c,[[-3,-113],[3,-113],[5,-101],[0,-96],[-5,-101]],p.gold2,p.ink,.9);
    c.fillStyle=o.dark?"#cf83ef":"#ff3b31";c.shadowColor=c.fillStyle;c.shadowBlur=9;
    c.beginPath();c.ellipse(-6,-111,3.4,2.2,-.15,0,TAU);c.ellipse(7,-111,3.4,2.2,.15,0,TAU);c.fill();c.shadowBlur=0;
    c.fillStyle="#171016";c.beginPath();c.moveTo(-8,-98);c.quadraticCurveTo(0,-90,9,-98);c.lineTo(5,-89);c.lineTo(0,-86);c.lineTo(-5,-90);c.closePath();c.fill();
    c.fillStyle="#eee7d5"; for(let i=0;i<4;i++){const xx=-5+i*3.2;c.beginPath();c.moveTo(xx,-96);c.lineTo(xx+1.2,-91);c.lineTo(xx+2.1,-96);c.fill();}

    const frontS={x:20,y:-80}, backS={x:-20,y:-79};
    const drawArm=(S,T,far)=>{const e=ik(S.x,S.y,T.x,T.y,19,20,far?-1:1);limb(c,[S,{x:e.x,y:e.y},{x:e.tx,y:e.ty}],12,p.ink,far?p.black:p.lacquer,p.steel);c.fillStyle=p.gold;c.beginPath();c.arc(T.x,T.y,4.5,0,TAU);c.fill();return e;};
    if(o.bow){
      const draw=clamp(o.bowDraw||0,0,1), bowHand={x:40,y:-91}, stringHand={x:5-draw*24,y:-91};
      drawArm(backS,stringHand,true); drawArm(frontS,bowHand,false);
      drawDemonBow(c,bowHand.x+2,bowHand.y,0,draw,o.dark?12:7);
    }else{
      const swordHand={x:frontS.x+Math.cos(o.swordA)*o.handR,y:frontS.y+Math.sin(o.swordA)*o.handR};
      drawArm(backS,{x:backS.x+Math.cos(o.offA)*27,y:backS.y+Math.sin(o.offA)*27},true);
      drawArm(frontS,swordHand,false);
      drawShogunKatana(c,swordHand.x,swordHand.y,o.swordA,o.dark,1.02);
      if(o.cast){const gg=c.createRadialGradient(backS.x,backS.y,1,backS.x,backS.y,24);gg.addColorStop(0,"#fff");gg.addColorStop(.25,o.dark?"#b77bdd":"#ffb75b");gg.addColorStop(1,"rgba(80,20,100,0)");c.fillStyle=gg;c.beginPath();c.arc(backS.x+Math.cos(o.offA)*27,backS.y+Math.sin(o.offA)*27,24,0,TAU);c.fill();}
    }
    c.restore();
    c.restore();
  }
  function drawShogunMinion(c, m) {
    if (!m) return;
    const spawn = m.state === "spawn" ? ease(clamp(m.t / 0.75, 0, 1)) : 1,
      dead = m.state === "dead",
      run = m.state === "walk" ? 1 : 0,
      atk = m.state === "attack" ? clamp(m.t / 0.35, 0, 1) : 0;
    c.save();
    c.translate(m.x, GROUND + (1 - spawn) * 55);
    c.scale(m.face * 0.82, 0.82);
    c.globalAlpha = m.alpha;
    if (m.flash > 0) c.filter = "brightness(3)";
    if (dead) c.rotate(-1.2 * clamp(m.t / 0.6, 0, 1));
    c.translate(
      Math.sin(atk * Math.PI) * 15,
      -run * Math.abs(Math.sin(m.stride)) * 3,
    );
    let f1 = { x: -8 + Math.sin(m.stride) * 14 * run, y: 0 },
      f2 = { x: 8 + Math.sin(m.stride + Math.PI) * 14 * run, y: 0 };
    const leg = (hx, f) => {
      const k = ik(hx, -35, f.x, f.y, 20, 21, -1);
      limb(
        c,
        [
          { x: hx, y: -35 },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        9,
        "#08070a",
        "#24171d",
        "#4d2831",
      );
    };
    leg(-4, f1);
    leg(4, f2);
    poly(
      c,
      [
        [-12, -40],
        [12, -40],
        [20, -2],
        [8, -10],
        [2, 2],
        [-7, -9],
        [-17, -1],
      ],
      "#17131a",
      "#050407",
      1.4,
    );
    poly(
      c,
      [
        [-17, -85],
        [17, -85],
        [20, -47],
        [-18, -47],
      ],
      "#28212a",
      "#080609",
      1.5,
    );
    c.strokeStyle = "#8c2630";
    for (let y = -79; y < -50; y += 8) {
      c.beginPath();
      c.moveTo(-15, y);
      c.lineTo(15, y);
      c.stroke();
    }
    const a = m.state === "attack" ? lerp(-2.2, 0.7, ease(atk)) : -0.6,
      sh = { x: 14, y: -75 },
      h = { x: sh.x + Math.cos(a) * 35, y: sh.y + Math.sin(a) * 35 },
      e = ik(sh.x, sh.y, h.x, h.y, 18, 18, -1);
    limb(
      c,
      [
        { x: sh.x, y: sh.y },
        { x: e.x, y: e.y },
        { x: h.x, y: h.y },
      ],
      10,
      "#080609",
      "#2a2028",
      "#59404b",
    );
    drawShogunKatana(c, h.x, h.y, a, false, 0.72);
    c.fillStyle = "#d8d0bd";
    c.strokeStyle = "#25232a";
    c.lineWidth = 1.6;
    c.beginPath();
    c.ellipse(0, -101, 14, 17, 0, 0, TAU);
    c.fill();
    c.stroke();
    c.fillStyle = "#111018";
    c.beginPath();
    c.ellipse(-5, -105, 3, 4, 0, 0, TAU);
    c.ellipse(5, -105, 3, 4, 0, 0, TAU);
    c.fill();
    poly(
      c,
      [
        [-18, -119],
        [-8, -128],
        [0, -122],
        [10, -129],
        [18, -117],
      ],
      "#211820",
      "#080609",
      1.4,
    );
    c.scale(m.face, 1);
    if (m.hp < m.maxhp && !dead) {
      c.fillStyle = "rgba(0,0,0,.8)";
      c.fillRect(-25, -142, 50, 5);
      c.fillStyle = "#ef4738";
      c.fillRect(-24, -141, (48 * m.hp) / m.maxhp, 3);
    }
    c.restore();
  }
  function drawShogunHazards() {
    for (const h of shogunHazards) {
      ctx.save();
      if (h.kind === "lightning") {
        const k = clamp(h.t / h.delay, 0, 1);
        ctx.strokeStyle = k > 0.75 ? "#ffe49a" : "rgba(255,100,55,.8)";
        ctx.lineWidth = 2 + 3 * k;
        ctx.setLineDash([10, 7]);
        ctx.beginPath();
        ctx.ellipse(h.x, GROUND, lerp(65, 18, k), 10, 0, 0, TAU);
        ctx.stroke();
        ctx.setLineDash([]);
        if (h.t >= h.delay && h.t < h.delay + 0.18) {
          ctx.strokeStyle = h.index % 2 ? "#c999ff" : "#fff0a5";
          ctx.shadowColor = ctx.strokeStyle;
          ctx.shadowBlur = 20;
          ctx.lineWidth = 9;
          ctx.beginPath();
          ctx.moveTo(h.x + rnd(-8, 8), 0);
          ctx.lineTo(h.x - 12, 160);
          ctx.lineTo(h.x + 9, 285);
          ctx.lineTo(h.x, GROUND);
          ctx.stroke();
        }
      } else if (h.kind === "arrow") {
        ctx.translate(h.x, h.y);
        ctx.rotate(Math.atan2(h.vy, h.vx));
        ctx.strokeStyle = "#ff6338";
        ctx.shadowColor = "#ff421f";
        ctx.shadowBlur = 9;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-18, 0);
        ctx.lineTo(15, 0);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(15, 0);
        ctx.lineTo(8, -5);
        ctx.lineTo(8, 5);
        ctx.closePath();
        ctx.fillStyle = "#ffd080";
        ctx.fill();
      } else if (
        h.kind === "firewave" ||
        h.kind === "darklow" ||
        h.kind === "darkhigh"
      ) {
        const dark = h.kind !== "firewave";
        ctx.fillStyle = dark ? "rgba(55,18,78,.8)" : "rgba(255,70,25,.8)";
        ctx.shadowColor = dark ? "#6f2b91" : "#ff4c22";
        ctx.shadowBlur = 16;
        ctx.beginPath();
        ctx.moveTo(h.x - h.vx * 0.07, h.y + 25);
        ctx.quadraticCurveTo(
          h.x,
          h.y - 68 - Math.sin(time * 14) * 12,
          h.x + h.vx * 0.065,
          h.y + 22,
        );
        ctx.closePath();
        ctx.fill();
      } else {
        const dark = h.kind === "rain";
        const g = ctx.createRadialGradient(h.x, h.y, 2, h.x, h.y, h.r * 1.8);
        g.addColorStop(0, "#fff");
        g.addColorStop(0.28, dark ? "#a569c8" : "#ffb45c");
        g.addColorStop(1, dark ? "rgba(45,10,65,0)" : "rgba(255,45,20,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(h.x, h.y, h.r * 1.8, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  // Shared bow renderer retained for the Infernal Shogun.
  function drawDemonBow(c, x, y, A, draw = 0, glow = 0) {
    c.save();
    c.translate(x, y);
    c.rotate(A);
    const pull = 13 + clamp(draw, 0, 1) * 25;
    c.shadowColor = "#9fd7ff";
    c.shadowBlur = glow + 4;
    c.strokeStyle = "#05070b";
    c.lineWidth = 8;
    c.beginPath();
    c.moveTo(0, -48);
    c.quadraticCurveTo(24, 0, 0, 48);
    c.stroke();
    const metal = c.createLinearGradient(-3, -48, 12, 48);
    metal.addColorStop(0, "#dceaf2");
    metal.addColorStop(0.35, "#536779");
    metal.addColorStop(0.7, "#111923");
    metal.addColorStop(1, "#a9c5d7");
    c.strokeStyle = metal;
    c.lineWidth = 4.5;
    c.beginPath();
    c.moveTo(0, -48);
    c.quadraticCurveTo(22, 0, 0, 48);
    c.stroke();
    c.shadowBlur = 0;
    c.strokeStyle = "rgba(220,240,255,.9)";
    c.lineWidth = 1.2;
    c.beginPath();
    c.moveTo(0, -48);
    c.lineTo(-pull, 0);
    c.lineTo(0, 48);
    c.stroke();
    c.strokeStyle = "#d6efff";
    c.lineWidth = 2.4;
    c.beginPath();
    c.moveTo(-pull - 9, 0);
    c.lineTo(69, 0);
    c.stroke();
    c.fillStyle = "#d6efff";
    c.beginPath();
    c.moveTo(73, 0);
    c.lineTo(62, -4);
    c.lineTo(64, 0);
    c.lineTo(62, 4);
    c.closePath();
    c.fill();
    c.fillStyle = "#111722";
    c.fillRect(-pull - 13, -5, 8, 10);
    c.restore();
  }
  /* ================= SHATTERED DEMON (boss 3) ================= */
  const PAL_D = {
    flesh: "#5b211f",
    flesh2: "#8f4034",
    bone: "#d2bea3",
    bone2: "#8a7767",
    dark: "#1b0b0d",
    lava: "#ff3b18",
    iron: "#34292b",
    edge: "#ff9b75",
  };
  const RECT_D = {
    sweep: { x0: 10, x1: 225, h0: 0, h1: 105 },
    over: { x0: 0, x1: 205, h0: 0, h1: 195 },
    rise: { x0: -12, x1: 205, h0: 0, h1: 190 },
    thrust: { x0: 0, x1: 220, h0: 20, h1: 165 },
  };
  const dAtk = (
    type,
    dmg,
    w = 0.52,
    a = 0.15,
    r = 0.3,
    lunge = 76,
    weapon = "hammer",
  ) => ({ type, w, a, r, lunge, rect: RECT_D[type], stop: 125, dmg, weapon });
  const DCOMBOS = [
    {
      name: "Fist Pair",
      atks: [
        dAtk("thrust", 80, 0.42, 0.13, 0.23, 72, "fist"),
        dAtk("over", 80, 0.38, 0.14, 0.72, 65, "fist"),
      ],
    },
    {
      name: "Hammer Pair",
      atks: [
        dAtk("over", 100, 0.58, 0.15, 0.26, 75),
        dAtk("sweep", 100, 0.48, 0.15, 0.8, 72),
      ],
    },
    {
      name: "Ruin Triple",
      atks: [
        dAtk("sweep", 100, 0.48),
        dAtk("over", 100, 0.38),
        dAtk("rise", 100, 0.44, 0.14, 0.82),
      ],
    },
    {
      name: "Fivefold Sentence",
      atks: [
        dAtk("over", 100, 0.48),
        dAtk("sweep", 100, 0.33),
        dAtk("rise", 100, 0.32),
        dAtk("thrust", 100, 0.31),
        dAtk("over", 100, 0.43, 0.15, 0.9),
      ],
    },
  ];
  const DBLADES = [
    {
      name: "Twin Blades",
      atks: [
        dAtk("sweep", 100, 0.38, 0.12, 0.22, 88, "blade"),
        dAtk("rise", 100, 0.31, 0.12, 0.72, 82, "blade"),
      ],
    },
    {
      name: "Tri-Cut",
      atks: [
        dAtk("over", 100, 0.38, 0.12, 0.2, 88, "blade"),
        dAtk("sweep", 100, 0.28, 0.12, 0.2, 80, "blade"),
        dAtk("rise", 100, 0.3, 0.12, 0.7, 75, "blade"),
      ],
    },
    {
      name: "Fivefold Rend",
      atks: [0, 1, 2, 3, 4].map((_, i) =>
        dAtk(
          ["sweep", "over", "rise", "thrust", "sweep"][i],
          100,
          0.27,
          0.11,
          i === 4 ? 0.75 : 0.17,
          78,
          "blade",
        ),
      ),
    },
  ];
  function beginDemonPhase(n) {
    B.prevDPhase = B.dphase;
    B.dphase = n;
    B.rage = n > 1;
    B.state = "transform";
    B.phase = "grow";
    B.pt = 0;
    B.combo = null;
    B.h = 0;
    B.hitDone = true;
    musicIntensify();
    demonHazards.length = 0;
    doShake(n === 2 ? 22 : 28);
    doFlash(0.65, n === 2 ? "180,25,15" : "255,45,20");
    sfx("demonRoar");
    addRing(B.x, GROUND - 100, 20, 360, 0.9, "rgba(255,55,25,.9)", 12);
    spark(
      B.x,
      GROUND - 110,
      70,
      n === 2 ? "#ff5a32" : "#ffb08e",
      850,
      1.1,
      100,
    );
    addText(
      B.x,
      GROUND - 260,
      n === 2 ? "WE DIDN'T EVEN START YET" : "YOU ARE NO MATCH FOR ME",
      "#ffd1bd",
      22,
      2.4,
    );
  }
  function demonDamage(n) {
    return Math.round(n * (B.dphase === 3 ? 1.3 : 1));
  }
  function dHaz(kind, x, y, vx, vy, dmg, extra = {}) {
    demonHazards.push(
      Object.assign(
        { kind, x, y, vx, vy, dmg, t: 0, life: 4, r: 15, g: 0, hit: false },
        extra,
      ),
    );
  }
  function demonChoose() {
    const d = Math.abs(bossCombatTarget().x - B.x),
      r = Math.random(),
      ph = B.dphase;
    let pick;
    if (ph === 1)
      pick =
        d > 320 ? (r < 0.6 ? "cast" : "combo") : r < 0.67 ? "combo" : "cast";
    else if (ph === 2)
      pick = ["combo", "cast", "rush", "quake", "laser", "jump", "sky"][
        Math.floor(r * 7)
      ];
    else
      pick = [
        "combo",
        "cast",
        "rush",
        "quake",
        "laser",
        "jump",
        "sky",
        "knives",
        "teleport",
      ][Math.floor(r * 9)];
    if (pick === B.last && Math.random() < 0.65) pick = "combo";
    B.last = pick;
    if (pick === "combo") {
      const pool = ph === 3 ? DBLADES : DCOMBOS;
      let choices = ph === 1 ? pool : pool;
      let i = Math.floor(Math.random() * choices.length);
      B.combo = choices[i];
      B.ci = 0;
      B.state = "combo";
      startBossAtk();
    } else if (pick === "cast") {
      B.state = "dcast";
      B.phase = "charge";
      B.pt = 0;
      B.mode = Math.random() < 0.5 ? "orb" : "wave";
      B.shots = ph === 1 ? 1 : 3;
      B.shotNext = 0;
      sfx("charge");
    } else if (pick === "rush") {
      B.state = "drush";
      B.phase = "wind";
      B.pt = 0;
      B.rn = 3;
      B.rfirst = true;
    } else if (pick === "quake") {
      B.state = "dquake";
      B.phase = "wind";
      B.pt = 0;
      B.shots = 3;
      B.shotNext = 1.5;
    } else if (pick === "laser") {
      B.state = "dlaser";
      B.phase = "charge";
      B.pt = 0;
      B.shots = 3 + Math.floor(Math.random() * 2);
      B.shotNext = 0.7;
      sfx("charge");
    } else if (pick === "jump") {
      B.state = "djump";
      B.phase = "crouch";
      B.pt = 0;
      B.jn = 2 + Math.floor(Math.random() * 2);
      B.jfirst = true;
    } else if (pick === "sky") {
      B.state = "dsky";
      B.phase = "charge";
      B.pt = 0;
      B.shots = 4 + Math.floor(Math.random() * 5);
      sfx("charge");
    } else if (pick === "knives") {
      B.state = "dknives";
      B.phase = "throw";
      B.pt = 0;
      B.shots = 7 + Math.floor(Math.random() * 5);
      B.shotNext = 0.28;
    } else {
      B.state = "dtele";
      B.phase = "vanish";
      B.pt = 0;
    }
  }
  function demonMelee(dt) {
    const a = B.atk;
    B.pt += dt;
    const w = a.w * (B.dphase === 3 ? 0.78 : B.dphase === 2 ? 0.9 : 1);
    if (B.phase === "wind") {
      if (B.pt < w * 0.55) bossFace();
      if (B.pt > w * 0.28 && Math.abs(bossCombatTarget().x - B.x) > a.stop)
        B.x += B.face * (a.lunge / (w * 0.72)) * dt;
      if (B.pt >= w) {
        B.phase = "act";
        B.pt = 0;
        B.hitDone = false;
        bossSlashFx(a);
      }
    } else if (B.phase === "act") {
      bossStrike(a);
      if (B.state !== "combo") return;
      if (B.pt >= a.a) {
        B.phase = "rec";
        B.pt = 0;
      }
    } else if (B.pt >= a.r * (B.dphase === 3 ? 0.78 : 0.9)) {
      if (++B.ci >= B.combo.atks.length) {
        B.state = "idle";
        B.cool = rnd(0.42, 0.75);
      } else startBossAtk();
    }
  }
  function demonImpact(x, dmg, wave) {
    sfx("crack");
    doShake(18);
    dust(x, GROUND, 20);
    spark(x, GROUND - 12, 28, "#ff5a32", 650, 0.55, 260);
    addRing(x, GROUND - 4, 12, 230, 0.48, "rgba(255,70,30,.95)", 9);
    if (wave) {
      const dir = P.x >= x ? 1 : -1;
      dHaz("wave", x + dir * 35, GROUND - 9, dir * 520, 0, dmg, {
        life: 3,
        r: 24,
      });
      fx.push({ k: "groundburst", x, y: GROUND, life: 0.48, t: 0, r1: 260 });
    } else {
      damageSkeletonsInRange(x, 230, demonDamage(dmg));
      if (Math.abs(P.x - x) < 230 && GROUND - P.y < 76 && P.invuln <= 0)
        hurtPlayer(demonDamage(dmg), x, true);
    }
  }
  function demonGroundQuake(dmg) {
    sfx("crack");
    doShake(25);
    doFlash(0.28, "255,70,30");
    dust(B.x, GROUND, 28);
    spark(B.x, GROUND - 8, 42, "#ff5a32", 760, 0.65, 260);
    addRing(B.x, GROUND - 2, 18, 720, 0.62, "rgba(255,72,28,.95)", 13);
    addRing(B.x, GROUND - 2, 12, 1150, 0.78, "rgba(255,165,70,.72)", 7);
    fx.push({
      k: "groundburst",
      x: B.x,
      y: GROUND,
      life: 0.82,
      t: 0,
      r1: 1100,
    });
    for (
      let x = Math.max(20, B.x - 700);
      x < Math.min(WORLD - 20, B.x + 700);
      x += 85
    )
      parts.push({
        k: "dot",
        x,
        y: GROUND - rnd(0, 8),
        vx: rnd(-80, 80),
        vy: rnd(-240, -90),
        life: rnd(0.45, 0.8),
        t: 0,
        col: "255,70,30",
        g: 520,
        drag: 1,
        sz: rnd(3, 7),
      });
    damageSkeletonsInRange(B.x, 1200, demonDamage(dmg));
    if (GROUND - P.y < 82 && P.invuln <= 0 && P.state !== "dead")
      hurtPlayer(demonDamage(dmg), B.x, true);
  }
  function updateDemon(dt) {
    B.parryT = Math.max(0, (B.parryT || 0) - dt);
    if (B.ghostDelay > 0) B.ghostDelay -= dt;
    else if (B.ghost > B.hp) B.ghost = Math.max(B.hp, B.ghost - 700 * dt);
    const spd = B.dphase === 3 ? 175 : B.dphase === 2 ? 145 : 105;
    if (B.dphase > 1 && B.state !== "dead" && Math.random() < 0.45)
      parts.push({
        k: "dot",
        x: B.x + rnd(-48, 48),
        y: GROUND - B.h - rnd(20, 205),
        vx: rnd(-20, 20),
        vy: rnd(-110, -35),
        life: rnd(0.5, 1.1),
        t: 0,
        col: B.dphase === 3 ? "255,70,30" : "170,45,30",
        g: 0,
        drag: 1,
        sz: rnd(2, 5),
      });
    switch (B.state) {
      case "intro":
        B.introFill = Math.min(1, phaseT / 1.6);
        if (!B.roared && phaseT > 0.5) {
          B.roared = true;
          sfx("demonRoar");
          doShake(20);
          addRing(B.x, GROUND - 90, 10, 330, 0.85, "rgba(255,65,30,.85)", 9);
        }
        break;
      case "transform":
        B.pt += dt;
        if (Math.random() < 0.8)
          spark(
            B.x + rnd(-60, 60),
            GROUND - rnd(10, 210),
            1,
            "#ff5a32",
            300,
            0.45,
            -60,
          );
        if (B.pt >= 2.65) {
          B.state = "idle";
          B.phase = "";
          B.cool = 0.65;
        }
        break;
      case "idle":
        bossFace();
        if (Math.abs(bossCombatTarget().x - B.x) > 155) {
          B.x += B.face * spd * dt;
          B.moving = true;
          B.stride += spd * dt * 0.055;
        }
        if ((B.cool -= dt) <= 0 && phase === "fight" && P.state !== "dead")
          demonChoose();
        break;
      case "combo":
        demonMelee(dt);
        break;
      case "dcast": {
        B.pt += dt;
        const charge = 0.82;
        if (B.phase === "charge") {
          bossFace();
          if (Math.random() < 0.8) {
            const a = rnd(0, TAU),
              rr = rnd(55, 115);
            parts.push({
              k: "gather",
              sx: B.x + Math.cos(a) * rr,
              sy: GROUND - 115 + Math.sin(a) * rr,
              tx: B.x + B.face * 58,
              ty: GROUND - 118,
              life: 0.4,
              t: 0,
              x: 0,
              y: 0,
              gc: "255,65,35",
            });
          }
          if (B.pt >= charge) {
            B.phase = "fire";
            B.pt = 0;
            B.shotNext = 0;
          }
        } else if (B.phase === "fire" && B.shots > 0 && B.pt >= B.shotNext) {
          B.shotNext += 0.31;
          B.shots--;
          if (B.mode === "orb") {
            const target = bossCombatTarget(),
              tx = target.x,
              ty = target === P ? P.y - 52 : GROUND - 58,
              ox = B.x + B.face * 62,
              oy = GROUND - 118,
              ang = Math.atan2(ty - oy, tx - ox);
            dHaz(
              "orb",
              ox,
              oy,
              Math.cos(ang) * 560,
              Math.sin(ang) * 560,
              demonDamage(100),
              { r: 17, life: 3 },
            );
            sfx("beam");
          } else {
            demonImpact(B.x, 100, true);
          }
          if (B.shots <= 0) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.phase === "rec" && B.pt > 0.72) {
          B.state = "idle";
          B.cool = 0.45;
        }
        break;
      }
      case "drush": {
        B.pt += dt;
        if (B.phase === "wind") {
          bossFace();
          if (B.pt > 0.42) {
            B.phase = "dash";
            B.pt = 0;
            B.rdir = B.face;
            B.rmoved = 0;
            B.rdist = Math.max(520, Math.abs(bossCombatTarget().x - B.x) + 200);
            B.hitDone = false;
            sfx("bswing");
          }
        } else if (B.phase === "dash") {
          const q = 1550 * dt;
          B.x += B.rdir * q;
          B.rmoved += q;
          addStreak(
            B.x - B.rdir * 110,
            GROUND - 95,
            B.rdir * 150,
            "rgba(255,60,35,.75)",
            0.13,
          );
          if (!B.hitDone && heroType === "wizard") {
            for (const s of skeletons) {
              if (s.hp > 0 && Math.abs(s.x - B.x) < 125) {
                damageSkeleton(s, demonDamage(150));
                B.hitDone = true;
                break;
              }
            }
          }
          if (
            !B.hitDone &&
            Math.abs(P.x - B.x) < 120 &&
            GROUND - P.y < 140 &&
            P.invuln <= 0
          ) {
            hurtPlayer(demonDamage(150), B.x, true);
            B.hitDone = true;
          }
          if (
            B.rmoved >= B.rdist ||
            B.pt > 0.5 ||
            B.x < 85 ||
            B.x > WORLD - 85
          ) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt > 0.16) {
          if (--B.rn > 0) {
            B.phase = "wind";
            B.pt = 0;
          } else {
            B.state = "dair";
            B.phase = "up";
            B.pt = 0;
            B.jx0 = B.x;
            B.jx1 = clamp(bossCombatTarget().x - B.face * 55, 100, WORLD - 100);
          }
        }
        break;
      }
      case "dair":
        B.pt += dt;
        if (B.phase === "up") {
          const k = Math.min(1, B.pt / 0.72);
          B.x = lerp(B.jx0, B.jx1, k);
          B.h = 4 * 270 * k * (1 - k);
          if (k >= 1) {
            B.h = 0;
            demonGroundQuake(200);
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.pt > 0.82) {
          B.state = "idle";
          B.cool = 0.55;
        }
        break;
      case "dquake":
        B.pt += dt;
        if (B.shots > 0 && B.pt >= B.shotNext) {
          B.shots--;
          demonGroundQuake(200);
          if (B.shots > 0) {
            B.pt = 0;
            B.shotNext = 1.5;
            B.phase = "wind";
          } else {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.phase === "rec" && B.pt > 0.8) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "dlaser":
        B.pt += dt;
        if (B.shots > 0 && B.pt >= B.shotNext) {
          B.shotNext += 0.56;
          B.shots--;
          const target = bossCombatTarget(),
            ox = B.x + B.face * 70,
            oy = GROUND - 145,
            tx = target.x,
            ty = target === P ? P.y - 55 : GROUND - 58,
            ang = Math.atan2(ty - oy, tx - ox);
          dHaz(
            "laser",
            ox,
            oy,
            Math.cos(ang) * 390,
            Math.sin(ang) * 390,
            demonDamage(100),
            { r: 11, life: 4 },
          );
          sfx("beam");
          if (B.shots === 0) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.phase === "rec" && B.pt > 0.65) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "djump":
        B.pt += dt;
        if (B.phase === "crouch") {
          bossFace();
          if (B.pt > 0.38) {
            B.phase = "air";
            B.pt = 0;
            B.jx0 = B.x;
            B.jx1 = clamp(bossCombatTarget().x, 100, WORLD - 100);
          }
        } else if (B.phase === "air") {
          const k = Math.min(1, B.pt / 0.55);
          B.x = lerp(B.jx0, B.jx1, k);
          B.h = 4 * 230 * k * (1 - k);
          if (k >= 1) {
            B.h = 0;
            demonImpact(B.x, 200, false);
            if (--B.jn > 0) {
              B.phase = "crouch";
              B.pt = 0;
            } else {
              B.phase = "rec";
              B.pt = 0;
            }
          }
        } else if (B.pt > 0.6) {
          B.state = "idle";
          B.cool = 0.48;
        }
        break;
      case "dsky":
        B.pt += dt;
        if (B.phase === "charge" && B.pt > 0.9) {
          const target = bossCombatTarget();
          for (let i = 0; i < B.shots; i++)
            dHaz(
              "sky",
              clamp(target.x + rnd(-330, 330), 45, WORLD - 45),
              rnd(-180, -30),
              rnd(-30, 30),
              rnd(260, 390),
              demonDamage(60),
              { g: 220, r: 14, life: 4 },
            );
          B.phase = "rec";
          B.pt = 0;
          sfx("demonRoar");
        } else if (B.phase === "rec" && B.pt > 0.8) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "dknives":
        B.pt += dt;
        if (B.shots > 0 && B.pt >= B.shotNext) {
          B.shotNext += 0.13;
          B.shots--;
          const target = bossCombatTarget(),
            ox = B.x + B.face * 65,
            oy = GROUND - 120 + rnd(-45, 45),
            tx = target.x,
            ty = target === P ? P.y - 55 : GROUND - 58,
            ang = Math.atan2(ty + rnd(-35, 35) - oy, tx - ox);
          dHaz(
            "knife",
            ox,
            oy,
            Math.cos(ang) * 720,
            Math.sin(ang) * 720,
            demonDamage(60),
            { r: 9, life: 2.8 },
          );
          sfx("knife");
          if (!B.shots) {
            B.phase = "rec";
            B.pt = 0;
          }
        } else if (B.phase === "rec" && B.pt > 0.62) {
          B.state = "idle";
          B.cool = 0.45;
        }
        break;
      case "dtele":
        B.pt += dt;
        if (B.phase === "vanish" && B.pt > 0.32) {
          const target = bossCombatTarget();
          B.x = clamp(target.x - B.face * 105, 85, WORLD - 85);
          B.face = target.x >= B.x ? 1 : -1;
          B.phase = "slash";
          B.pt = 0;
          doFlash(0.25, "255,45,20");
          sfx("knife");
        } else if (B.phase === "slash" && B.pt > 0.22 && !B.hitDone) {
          B.hitDone = true;
          addArc(
            B.x,
            GROUND - 115,
            160,
            -2.5,
            0.7,
            B.face,
            0.2,
            "rgba(255,80,45,.95)",
            16,
          );
          damageSkeletonsInRange(B.x, 175, demonDamage(200));
          if (Math.abs(P.x - B.x) < 175 && P.invuln <= 0)
            hurtPlayer(demonDamage(200), B.x, true);
        } else if (B.phase === "slash" && B.pt > 0.65) {
          B.state = "idle";
          B.cool = 0.55;
          B.hitDone = false;
        }
        break;
      case "stunned":
        if ((B.stunT -= dt) <= 0) {
          B.state = "idle";
          B.cool = 0.5;
        }
        break;
      case "dead":
        B.dieT += dt;
        if (Math.random() < 0.8)
          parts.push({
            k: "dot",
            x: B.x + rnd(-60, 60),
            y: GROUND - rnd(0, 210),
            vx: rnd(-40, 40),
            vy: rnd(-150, -40),
            life: rnd(0.7, 1.5),
            t: 0,
            col: "255,60,30",
            g: -20,
            drag: 0.5,
            sz: rnd(3, 7),
          });
        break;
    }
  }
  function updateDemonHazards(dt) {
    for (let i = demonHazards.length - 1; i >= 0; i--) {
      const h = demonHazards[i];
      h.t += dt;
      h.vy += h.g * dt;
      h.x += h.vx * dt;
      h.y += h.vy * dt;
      let dead = h.t > h.life || h.x < -50 || h.x > WORLD + 50;
      if (h.kind === "wave") h.y = GROUND - 9;
      if (h.kind === "sky" && h.y >= GROUND - 8) {
        h.y = GROUND - 8;
        demonImpact(h.x, 60, false);
        dead = true;
      }
      if (!dead && !h.hit && heroType === "wizard") {
        for (const s of skeletons) {
          const dx = Math.abs(s.x - h.x),
            dy = Math.abs(GROUND - 58 - h.y);
          let hit = dx < h.r + 15 && dy < h.r + 55;
          if (h.kind === "wave") hit = dx < h.r + 18;
          if (s.hp > 0 && s.state !== "spawn" && hit) {
            damageSkeleton(s, h.dmg);
            h.hit = true;
            dead = true;
            break;
          }
        }
      }
      if (!dead && !h.hit && P.state !== "dead" && P.invuln <= 0) {
        const dy = Math.abs(P.y - 52 - h.y),
          dx = Math.abs(P.x - h.x);
        let hit = dx < h.r + 15 && dy < h.r + 52;
        if (h.kind === "wave") hit = dx < h.r + 18 && GROUND - P.y < 75;
        if (hit) {
          hurtPlayer(h.dmg, h.x, h.kind === "wave" || h.kind === "sky");
          h.hit = true;
          dead = true;
        }
      }
      if (Math.random() < 0.55)
        parts.push({
          k: "dot",
          x: h.x,
          y: h.y,
          vx: -h.vx * 0.04,
          vy: -h.vy * 0.04,
          life: 0.24,
          t: 0,
          col: "255,65,30",
          g: 0,
          drag: 2,
          sz: h.kind === "knife" ? 2 : 5,
        });
      if (dead) {
        spark(h.x, Math.min(h.y, GROUND - 6), 7, "#ff6a3d", 300, 0.32);
        demonHazards.splice(i, 1);
      }
    }
  }
  function drawDemonSmashWarning() {
    if (
      B.type !== "demon" ||
      B.state !== "dquake" ||
      B.phase !== "wind" ||
      B.shots <= 0
    )
      return;
    const k = clamp(B.pt / 1.5, 0, 1),
      remain = Math.max(0, 1.5 - B.pt),
      r = lerp(90, 720, easeOut(k));
    ctx.save();
    ctx.globalAlpha = 0.28 + 0.34 * k + 0.12 * Math.sin(time * 12);
    ctx.fillStyle = "rgba(180,18,8,.18)";
    ctx.fillRect(cam, GROUND - 22, W, 26);
    ctx.strokeStyle = k > 0.72 ? "#ffd080" : "#ff4b28";
    ctx.lineWidth = 3 + 4 * k;
    ctx.setLineDash([18, 12]);
    ctx.lineDashOffset = -time * 70;
    ctx.beginPath();
    ctx.ellipse(B.x, GROUND + 1, r, 16 + r * 0.014, 0, 0, TAU);
    ctx.stroke();
    ctx.setLineDash([]);
    for (let i = -3; i <= 3; i++) {
      const x = B.x + (i * r) / 7;
      ctx.strokeStyle = "rgba(255,72,35," + (0.35 + 0.45 * k) + ")";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, GROUND);
      ctx.lineTo(x + (i % 2 ? 18 : -18) * k, GROUND - 10 - 18 * k);
      ctx.lineTo(x + (i % 2 ? -8 : 8) * k, GROUND - 4);
      ctx.stroke();
    }
    ctx.globalAlpha = 0.9;
    ctx.textAlign = "center";
    ctx.font = "900 14px Cinzel, Georgia, serif";
    ctx.fillStyle = k > 0.72 ? "#ffe2a0" : "#ff9275";
    ctx.shadowColor = "#000";
    ctx.shadowBlur = 5;
    ctx.fillText("JUMP  " + remain.toFixed(1) + "s", P.x, P.y - 132);
    ctx.restore();
  }
  function drawDemonHazards() {
    if (
      B.type === "demon" &&
      B.state === "dair" &&
      B.phase === "up" &&
      B.h > 25
    ) {
      const x = B.x,
        y = GROUND - B.h - 142,
        r = 18 + Math.sin(time * 24) * 3;
      const g = ctx.createRadialGradient(x, y, 2, x, y, r * 2.3);
      g.addColorStop(0, "#fff4d6");
      g.addColorStop(0.28, "#ff5b2b");
      g.addColorStop(1, "rgba(180,0,0,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, r * 2.3, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,180,100,.85)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, TAU);
      ctx.stroke();
    }
    for (const h of demonHazards) {
      ctx.save();
      ctx.translate(h.x, h.y);
      const ang = Math.atan2(h.vy, h.vx);
      ctx.rotate(ang);
      ctx.shadowColor = "#ff2d14";
      ctx.shadowBlur = 16;
      if (h.kind === "wave") {
        ctx.rotate(-ang);
        ctx.fillStyle = "rgba(255,55,25,.78)";
        ctx.beginPath();
        ctx.moveTo(-24, 8);
        ctx.lineTo(0, -42);
        ctx.lineTo(24, 8);
        ctx.closePath();
        ctx.fill();
      } else if (h.kind === "knife") {
        ctx.fillStyle = "#f3c0aa";
        ctx.beginPath();
        ctx.moveTo(-22, -4);
        ctx.lineTo(18, 0);
        ctx.lineTo(-22, 4);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "#ff4b2a";
        ctx.stroke();
      } else if (h.kind === "laser") {
        ctx.fillStyle = "rgba(255,80,40,.9)";
        ctx.fillRect(-30, -5, 60, 10);
        ctx.fillStyle = "#fff0dc";
        ctx.fillRect(-22, -1.5, 44, 3);
      } else {
        const g = ctx.createRadialGradient(0, 0, 1, 0, 0, h.r * 1.8);
        g.addColorStop(0, "#fff4db");
        g.addColorStop(0.3, "#ff5b2b");
        g.addColorStop(1, "rgba(150,0,0,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(0, 0, h.r * 1.8, 0, TAU);
        ctx.fill();
      }
      ctx.restore();
    }
  }
  function drawDemonHammer(c, cx, cy, A, glow) {
    c.save();
    c.translate(cx, cy);
    c.rotate(A);
    c.lineCap = "round";
    // Wrapped, slightly crooked haft — closer to the organic weapons used by the other bosses.
    c.strokeStyle = "#100609";
    c.lineWidth = 9;
    c.beginPath();
    c.moveTo(-48, 3);
    c.quadraticCurveTo(18, -4, 88, 1);
    c.stroke();
    const sg = c.createLinearGradient(-45, -4, 88, 5);
    sg.addColorStop(0, "#241114");
    sg.addColorStop(0.48, "#704137");
    sg.addColorStop(1, "#2a1215");
    c.strokeStyle = sg;
    c.lineWidth = 5.5;
    c.stroke();
    c.strokeStyle = "#c18064";
    c.lineWidth = 1.2;
    for (let x = -38; x < 70; x += 12) {
      c.beginPath();
      c.moveTo(x, -3);
      c.lineTo(x + 5, 4);
      c.stroke();
    }
    if (glow) {
      c.shadowColor = "#ff3b18";
      c.shadowBlur = glow;
    }
    // Asymmetric bone-and-stone head: a hooked upper horn and a heavy striking face.
    const hg = c.createLinearGradient(60, -30, 118, 28);
    hg.addColorStop(0, "#b58b72");
    hg.addColorStop(0.35, "#6d3b34");
    hg.addColorStop(0.72, "#35161a");
    hg.addColorStop(1, "#14080b");
    c.fillStyle = hg;
    c.strokeStyle = "#0e0507";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(61, -11);
    c.lineTo(73, -26);
    c.lineTo(92, -23);
    c.lineTo(108, -34);
    c.lineTo(104, -17);
    c.lineTo(118, -7);
    c.lineTo(112, 16);
    c.lineTo(94, 27);
    c.lineTo(70, 21);
    c.lineTo(58, 8);
    c.closePath();
    c.fill();
    c.stroke();
    poly(
      c,
      [
        [73, -25],
        [79, -43],
        [88, -25],
      ],
      PAL_D.bone,
      "#100507",
      1.3,
    );
    poly(
      c,
      [
        [94, -23],
        [108, -46],
        [105, -16],
      ],
      PAL_D.bone2,
      "#100507",
      1.3,
    );
    poly(
      c,
      [
        [109, 12],
        [124, 20],
        [109, 22],
      ],
      PAL_D.bone2,
      "#100507",
      1.2,
    );
    c.fillStyle = "#ff3517";
    c.shadowColor = "#ff2108";
    c.shadowBlur = 11;
    c.beginPath();
    c.arc(88, 1, 7, 0, TAU);
    c.fill();
    c.shadowBlur = 0;
    c.strokeStyle = "rgba(255,115,70,.8)";
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(68, -7);
    c.lineTo(83, -1);
    c.lineTo(96, -11);
    c.moveTo(85, 7);
    c.lineTo(100, 17);
    c.stroke();
    c.restore();
  }
  function drawDemonBlade(c, hx, hy, A, len, glow) {
    c.save();
    c.translate(hx, hy);
    c.rotate(A);
    if (glow) {
      c.shadowColor = "#ff3b18";
      c.shadowBlur = glow;
    }
    const g = c.createLinearGradient(0, -9, 0, 9);
    g.addColorStop(0, "#381719");
    g.addColorStop(0.5, "#c08175");
    g.addColorStop(1, "#210b0e");
    c.fillStyle = g;
    c.strokeStyle = "#100508";
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(-5, -10);
    c.lineTo(len - 18, -7);
    c.lineTo(len, 0);
    c.lineTo(len - 22, 8);
    c.lineTo(-5, 10);
    for (let x = 55; x > 10; x -= 14) c.lineTo(x, 11 + (x % 3) * 2);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "#ff6a42";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(8, 0);
    c.lineTo(len - 22, 0);
    c.stroke();
    c.shadowBlur = 0;
    c.restore();
  }
  function demonObj() {
    let shown = B.dphase,
      alpha = 1;
    if (B.state === "transform") {
      const k = clamp(B.pt / 2.65, 0, 1);
      shown = k < 0.18 ? B.prevDPhase || Math.max(1, B.dphase - 1) : B.dphase;
      alpha = k < 0.16 ? 1 - k / 0.16 : k > 0.78 ? (k - 0.78) / 0.22 : 0;
    }
    const ph = shown,
      blade = ph === 3,
      wing = ph >= 2;
    const o = {
      x: B.x,
      y: B.y - B.h,
      face: B.face,
      scale: ph === 3 ? 1.67 : 1.62,
      t: time,
      run: B.moving ? 0.72 : 0,
      phase: B.stride,
      air: B.h > 5,
      crouch: 2,
      lean: 0,
      alpha,
      flash: B.flash > 0,
      wing,
      blade,
      hammerA: 0.18,
      bladeA: 0.28,
      bladeB: 0.52,
      glow: ph > 1 ? 8 : 3,
      shownPhase: ph,
      roar: B.state === "intro" || B.state === "transform",
    };
    switch (B.state) {
      case "intro":
        o.lean = -0.1;
        o.hammerA = -1.0;
        o.bladeA = -0.8;
        o.bladeB = 0.2;
        break;
      case "combo": {
        const a = B.atk || { type: "sweep", w: 0.5, a: 0.13, r: 0.3 },
          K = BK[a.type] || BK.sweep;
        let k;
        if (B.phase === "wind") {
          k = clamp(B.pt / (a.w || 0.5), 0, 1);
          o.hammerA = lerp(0.18, K.aw, easeOut(k));
          o.bladeA = lerp(0.25, K.aw, easeOut(k));
          o.bladeB = lerp(0.55, K.aw + 0.45, easeOut(k));
          o.lean = K.wl * k;
          o.crouch = 7 * k;
        } else if (B.phase === "act") {
          k = clamp(B.pt / (a.a || 0.13), 0, 1);
          o.hammerA = lerp(K.aw, K.a1, ease(k));
          o.bladeA = lerp(K.aw, K.a1, ease(k));
          o.bladeB = lerp(K.aw + 0.45, K.a1 - 0.38, ease(k));
          o.lean = lerp(K.wl, K.sl, k);
          o.crouch = 4;
        } else {
          k = clamp(B.pt / (a.r || 0.3), 0, 1);
          o.hammerA = lerp(K.a1, 0.18, k);
          o.bladeA = lerp(K.a1, 0.28, k);
          o.bladeB = lerp(K.a1 - 0.38, 0.52, k);
          o.lean = K.sl * (1 - k);
        }
        o.run = 0;
        break;
      }
      case "dcast":
        o.crouch = 9;
        o.lean = -0.08;
        o.hammerA = B.phase === "charge" ? -1.35 : 0.45;
        o.bladeA = -0.9;
        o.bladeB = 0.15;
        break;
      case "drush":
        o.crouch = B.phase === "dash" ? 18 : 9;
        o.lean = B.phase === "dash" ? 0.48 : -0.18;
        o.hammerA = B.phase === "dash" ? 0.05 : -0.75;
        o.bladeA = 0.02;
        o.bladeB = 0.22;
        o.run = 0;
        break;
      case "dair":
        o.air = B.h > 5;
        o.crouch = B.h > 5 ? 0 : 18;
        o.lean = 0.22;
        o.hammerA = 1.05;
        o.bladeA = 0.72;
        o.bladeB = 1.05;
        o.run = 0;
        break;
      case "dquake": {
        const q = clamp(B.pt / 1.5, 0, 1);
        o.crouch = q > 0.68 ? 17 : 7;
        o.lean = q > 0.68 ? 0.32 : -0.14;
        o.hammerA =
          q < 0.68
            ? lerp(0.18, -1.55, easeOut(q / 0.68))
            : lerp(-1.55, 1.18, ease((q - 0.68) / 0.32));
        o.bladeA = o.hammerA;
        o.bladeB = o.hammerA + 0.25;
        o.run = 0;
        break;
      }
      case "dlaser":
        o.crouch = 6;
        o.lean = -0.12;
        o.hammerA = -1.15;
        o.bladeA = -0.35;
        o.bladeB = 0.18;
        o.run = 0;
        break;
      case "djump":
        o.air = B.h > 5;
        o.crouch = B.phase === "crouch" ? 22 : B.phase === "air" ? 0 : 15;
        o.lean = B.phase === "air" ? 0.25 : -0.15;
        o.hammerA = B.phase === "air" ? 1.0 : -1.4;
        o.bladeA = 0.75;
        o.bladeB = 1.1;
        o.run = 0;
        break;
      case "dsky":
        o.hammerA = -1.45;
        o.bladeA = -1.25;
        o.bladeB = -1.85;
        o.lean = -0.1;
        o.run = 0;
        break;
      case "dknives":
        o.crouch = 5;
        o.lean = 0.18;
        o.bladeA = -0.15;
        o.bladeB = 0.65;
        o.run = 0;
        break;
      case "dtele":
        o.crouch = 10;
        o.lean = 0.38;
        o.bladeA = 0.03;
        o.bladeB = 0.32;
        o.run = 0;
        break;
      case "transform":
        o.crouch = 12;
        o.lean = -0.08;
        o.hammerA = -1.2;
        o.bladeA = -1.0;
        o.bladeB = -2.1;
        o.run = 0;
        break;
      case "stunned":
        o.crouch = 28;
        o.lean = 0.35;
        o.hammerA = 1.65;
        o.bladeA = 1.5;
        o.bladeB = 1.8;
        o.run = 0;
        break;
      case "dead":
        o.crouch = 28;
        o.lean = 0.45;
        o.hammerA = 1.7;
        o.bladeA = 1.45;
        o.bladeB = 1.9;
        o.run = 0;
        o.alpha *= clamp(1 - (B.dieT - 1) / 2.2, 0, 1);
        break;
    }
    return o;
  }
  function drawDemon(c, o) {
    const p = PAL_D,
      t = o.t,
      run = o.run || 0,
      crouch = o.crouch || 0,
      lean = o.lean || 0;
    c.save();
    c.translate(o.x, o.y);
    c.scale(o.face * o.scale, o.scale);
    c.globalAlpha = o.alpha;
    if (o.flash) c.filter = "brightness(2.5) saturate(.4)";
    const hipY = -43 + crouch * 0.85;
    // Fully articulated wings: shoulder joints, folding tips, membrane bones, and state-sensitive flapping.
    if (o.wing) {
      const active = ["djump", "dair", "drush", "transform"].includes(B.state),
        speed = active ? 5.4 : B.moving ? 3.7 : 2.15,
        beat = Math.sin(t * speed + B.stride * 0.12),
        flap = beat * (active ? 12 : 7),
        fold = Math.cos(t * (speed * 0.73)) * 5,
        spread = B.state === "transform" ? 22 : 0;
      c.save();
      c.globalAlpha *= 0.97;
      const left = [
        [-8, -92],
        [-35, -133 - flap - spread],
        [-79 - fold, -156 - flap - spread],
        [-68, -112 - flap * 0.25],
        [-111 - fold, -72 + flap],
        [-58, -82],
        [-20, -55],
      ];
      const right = [
        [8, -92],
        [36, -136 + flap - spread],
        [80 + fold, -157 + flap - spread],
        [67, -111 + flap * 0.25],
        [112 + fold, -72 - flap],
        [57, -82],
        [20, -55],
      ];
      poly(c, left, "#45171d", "#100609", 2);
      poly(c, right, "#592129", "#100609", 2);
      c.strokeStyle = "#b05c4d";
      c.lineWidth = 2.6;
      c.beginPath();
      c.moveTo(-8, -92);
      c.lineTo(-35, -133 - flap - spread);
      c.lineTo(-79 - fold, -156 - flap - spread);
      c.moveTo(8, -92);
      c.lineTo(36, -136 + flap - spread);
      c.lineTo(80 + fold, -157 + flap - spread);
      c.stroke();
      c.strokeStyle = "rgba(168,72,65,.72)";
      c.lineWidth = 1.4;
      c.beginPath();
      c.moveTo(-35, -133 - flap - spread);
      c.lineTo(-68, -112 - flap * 0.25);
      c.lineTo(-111 - fold, -72 + flap);
      c.moveTo(36, -136 + flap - spread);
      c.lineTo(67, -111 + flap * 0.25);
      c.lineTo(112 + fold, -72 - flap);
      c.stroke();
      c.fillStyle = "#7d302e";
      c.strokeStyle = "#120609";
      c.lineWidth = 1.3;
      c.beginPath();
      c.arc(-8, -92, 6, 0, TAU);
      c.arc(8, -92, 6, 0, TAU);
      c.fill();
      c.stroke();
      c.restore();
    }
    // Animated red cape behind the torso, cut like a superhero cape but scarred by the volcanic arena.
    {
      const sway =
          Math.sin(t * 2.4 + B.stride * 0.11) * 5 -
          run * 10 -
          (B.state === "drush" ? 18 : 0),
        lift = (o.air ? 15 : 0) + (B.state === "transform" ? 10 : 0);
      c.save();
      c.globalAlpha = 0.94;
      const cg = c.createLinearGradient(-12, -88, -42, 4);
      cg.addColorStop(0, "#b62f2c");
      cg.addColorStop(0.48, "#741b24");
      cg.addColorStop(1, "#250a12");
      c.fillStyle = cg;
      c.strokeStyle = "#16060b";
      c.lineWidth = 1.8;
      c.beginPath();
      c.moveTo(-11, -91);
      c.lineTo(12, -89);
      c.lineTo(20 + sway, -45 - lift * 0.3);
      c.lineTo(27 + sway, -5 - lift);
      c.lineTo(15 + sway, 7 - lift);
      c.lineTo(7 + sway, -2 - lift);
      c.lineTo(-2 + sway, 10 - lift);
      c.lineTo(-10 + sway, -3 - lift);
      c.lineTo(-19 + sway, 5 - lift);
      c.lineTo(-24 + sway, -39 - lift * 0.25);
      c.closePath();
      c.fill();
      c.stroke();
      c.strokeStyle = "rgba(255,92,75,.38)";
      c.lineWidth = 1.2;
      c.beginPath();
      c.moveTo(-3, -87);
      c.quadraticCurveTo(4 + sway, -42, 7 + sway, -2 - lift);
      c.moveTo(7, -87);
      c.quadraticCurveTo(14 + sway, -45, 16 + sway, -9 - lift);
      c.stroke();
      c.restore();
    }
    let fA, fB;
    if (o.air) {
      fA = { x: -14, y: -18 };
      fB = { x: 18, y: -27 };
    } else {
      const ph = o.phase !== undefined ? o.phase : t * 7,
        rx = 18 * run;
      fA = {
        x: -11 * (1 - run) + Math.sin(ph) * rx,
        y: -Math.max(0, Math.cos(ph)) * 11 * run,
      };
      fB = {
        x: 11 * (1 - run) + Math.sin(ph + Math.PI) * rx,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 11 * run,
      };
    }
    const leg = (hx, f, far) => {
      const k = ik(hx, hipY, f.x, f.y, 25, 26, -1);
      limb(
        c,
        [
          { x: hx, y: hipY },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        13,
        p.dark,
        far ? "#3a1518" : p.flesh,
        p.bone2,
      );
      const ang = Math.atan2(k.ty - k.y, k.tx - k.x);
      c.save();
      c.translate(k.x, k.y);
      c.rotate(ang);
      const lg = c.createLinearGradient(0, -7, 0, 7);
      lg.addColorStop(0, p.bone2);
      lg.addColorStop(0.5, p.flesh2);
      lg.addColorStop(1, p.dark);
      c.fillStyle = lg;
      c.strokeStyle = "#100507";
      c.lineWidth = 1.2;
      c.beginPath();
      c.moveTo(-5, -7);
      c.lineTo(17, -6);
      c.lineTo(23, 0);
      c.lineTo(16, 6);
      c.lineTo(-5, 7);
      c.closePath();
      c.fill();
      c.stroke();
      poly(
        c,
        [
          [5, -7],
          [11, -14],
          [15, -6],
        ],
        p.bone,
        "#100507",
        1,
      );
      c.restore();
      poly(
        c,
        [
          [k.tx - 9, k.ty - 5],
          [k.tx + 12, k.ty - 5],
          [k.tx + 20, k.ty],
          [k.tx + 10, k.ty + 2],
          [k.tx + 19, k.ty + 5],
          [k.tx - 10, k.ty + 2],
        ],
        p.dark,
        "#0b0406",
        1.2,
      );
      c.fillStyle = p.bone2;
      c.beginPath();
      c.arc(k.x, k.y, 4.5, 0, TAU);
      c.fill();
      c.strokeStyle = "#120608";
      c.stroke();
    };
    leg(-7, fA, true);
    leg(7, fB, false);
    c.save();
    c.translate(0, crouch);
    c.translate(0, -45);
    c.rotate(lean);
    c.translate(0, 45);
    const tg = c.createRadialGradient(-7, -78, 3, 0, -70, 48);
    tg.addColorStop(0, p.flesh2);
    tg.addColorStop(0.58, p.flesh);
    tg.addColorStop(1, p.dark);
    c.fillStyle = tg;
    c.strokeStyle = "#100507";
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(-25, -83);
    c.quadraticCurveTo(0, -103, 26, -83);
    c.lineTo(19, -44);
    c.quadraticCurveTo(0, -34, -18, -45);
    c.closePath();
    c.fill();
    c.stroke();
    c.strokeStyle = "rgba(255,76,42,.7)";
    c.lineWidth = 1.5;
    c.beginPath();
    c.moveTo(-12, -80);
    c.lineTo(1, -70);
    c.lineTo(-5, -56);
    c.moveTo(12, -88);
    c.lineTo(4, -72);
    c.lineTo(14, -58);
    c.stroke();
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU;
      c.fillStyle = i % 2 ? p.bone2 : "#6d3933";
      c.beginPath();
      c.moveTo(Math.cos(a) * 22, -69 + Math.sin(a) * 25);
      c.lineTo(Math.cos(a) * 29, -69 + Math.sin(a) * 31);
      c.lineTo(Math.cos(a + 0.25) * 21, -69 + Math.sin(a + 0.25) * 23);
      c.fill();
    }
    // Layered rib armour, collar, belt, and torn waist cloth add the same detail density as the knight bosses.
    c.strokeStyle = "rgba(28,8,10,.85)";
    c.lineWidth = 2;
    for (let i = 0; i < 4; i++) {
      const yy = -79 + i * 9;
      c.beginPath();
      c.moveTo(-20 + i * 1.5, yy);
      c.quadraticCurveTo(0, yy + 7, 20 - i * 1.5, yy);
      c.stroke();
    }
    poly(
      c,
      [
        [-24, -87],
        [-8, -96],
        [0, -89],
        [-13, -78],
      ],
      p.bone2,
      "#100507",
      1.3,
    );
    poly(
      c,
      [
        [24, -87],
        [8, -96],
        [0, -89],
        [13, -78],
      ],
      p.bone,
      "#100507",
      1.3,
    );
    const shoulderPlate = (x, y, far) => {
      const pg = c.createRadialGradient(x - 3, y - 4, 2, x, y, 15);
      pg.addColorStop(0, far ? "#d7a92d" : "#ffe06a");
      pg.addColorStop(0.55, "#c58a20");
      pg.addColorStop(1, "#60400d");
      c.fillStyle = pg;
      c.strokeStyle = "#2c1905";
      c.lineWidth = 1.7;
      c.beginPath();
      c.arc(x, y, 13, 0, TAU);
      c.fill();
      c.stroke();
      c.strokeStyle = "rgba(255,241,150,.7)";
      c.beginPath();
      c.arc(x - 2, y - 2, 8, 0.2, 2.6);
      c.stroke();
      for (let i = 0; i < 3; i++)
        poly(
          c,
          [
            [x - 9 + i * 8, y - 8],
            [x - 5 + i * 8, y - 19 - i * 2],
            [x + i * 8, y - 8],
          ],
          i === 1 ? "#ffd75b" : "#b97818",
          "#2c1905",
          1,
        );
    };
    shoulderPlate(-20, -83, true);
    shoulderPlate(21, -84, false);
    c.fillStyle = "#2b1013";
    c.strokeStyle = "#100507";
    c.lineWidth = 1.2;
    c.fillRect(-18, -48, 36, 6);
    c.strokeRect(-18, -48, 36, 6);
    c.fillStyle = p.bone;
    c.beginPath();
    c.arc(0, -45, 4, 0, TAU);
    c.fill();
    c.stroke();
    poly(
      c,
      [
        [-16, -43],
        [16, -43],
        [14, -15],
        [7, -23],
        [1, -12],
        [-5, -24],
        [-13, -15],
      ],
      "#351216",
      "#100507",
      1.3,
    );
    for (let i = 0; i < 5; i++)
      poly(
        c,
        [
          [-18 + i * 9, -90 - (i % 2) * 2],
          [-15 + i * 9, -108 - i * 3],
          [-10 + i * 9, -91],
        ],
        p.bone2,
        "#100507",
        1,
      );
    // Wind-reactive dark crimson mane, layered behind the skull instead of a rigid hair block.
    {
      const hs =
        Math.sin(t * 3.2 + B.stride * 0.1) * 3 -
        run * 7 -
        (B.state === "drush" ? 10 : 0);
      c.lineCap = "round";
      for (let i = 0; i < 6; i++) {
        const y = -115 + i * 5,
          len = 22 + i * 4;
        c.strokeStyle = i % 2 ? "#3a0d17" : "#651624";
        c.lineWidth = 5 - i * 0.45;
        c.beginPath();
        c.moveTo(-5, y);
        c.bezierCurveTo(
          -13 - len * 0.25,
          y - 5 + Math.sin(t * 2 + i) * 3,
          -18 - len * 0.55 + hs,
          y + 5 + i * 2,
          -18 - len + hs,
          y + 10 + i * 4,
        );
        c.stroke();
      }
      c.lineCap = "butt";
    }
    // Side-facing predatory skull with heavy brow, hooked snout, articulated jaw, and bull-like horns.
    poly(
      c,
      [
        [-7, -96],
        [12, -98],
        [18, -86],
        [-8, -84],
      ],
      "#301317",
      "#100507",
      1.3,
    );
    const hg = c.createLinearGradient(-12, -124, 20, -88);
    hg.addColorStop(0, "#efe0c3");
    hg.addColorStop(0.5, p.bone);
    hg.addColorStop(1, "#6f5b50");
    c.fillStyle = hg;
    c.strokeStyle = "#110607";
    c.lineWidth = 1.7;
    c.beginPath();
    c.moveTo(-11, -111);
    c.quadraticCurveTo(-3, -126, 11, -120);
    c.quadraticCurveTo(19, -116, 18, -105);
    c.lineTo(26, -99);
    c.lineTo(18, -92);
    c.lineTo(5, -93);
    c.lineTo(-8, -99);
    c.closePath();
    c.fill();
    c.stroke();
    // Heavy curved bull/devil horns with dark roots and pale sharpened tips.
    const horn = (side, far) => {
      c.save();
      c.scale(side, 1);
      c.lineCap = "round";
      c.strokeStyle = "#100507";
      c.lineWidth = 11;
      c.beginPath();
      c.moveTo(4, -117);
      c.bezierCurveTo(17, -132, 34, -135, 38, -121);
      c.bezierCurveTo(40, -113, 35, -107, 31, -105);
      c.stroke();
      const hg2 = c.createLinearGradient(5, -118, 38, -108);
      hg2.addColorStop(0, far ? "#5d493f" : "#7c6556");
      hg2.addColorStop(0.65, p.bone2);
      hg2.addColorStop(1, "#ead8b9");
      c.strokeStyle = hg2;
      c.lineWidth = 7;
      c.stroke();
      poly(
        c,
        [
          [31, -109],
          [43, -106],
          [34, -101],
        ],
        "#ead8b9",
        "#100507",
        1,
      );
      c.restore();
    };
    horn(-1, true);
    horn(1, false);
    c.lineCap = "butt";
    // Brow ridge and deep eye socket.
    poly(
      c,
      [
        [5, -113],
        [19, -111],
        [15, -102],
        [4, -104],
      ],
      "#4b3732",
      "#100507",
      1.1,
    );
    c.fillStyle = "#ff2d13";
    c.shadowColor = "#ff1d08";
    c.shadowBlur = 9;
    c.beginPath();
    c.ellipse(12, -107, 3.3, 2.5, -0.15, 0, TAU);
    c.fill();
    c.shadowBlur = 0;
    c.fillStyle = "rgba(120,25,20,.65)";
    c.beginPath();
    c.ellipse(-3, -108, 2, 1.7, 0, 0, TAU);
    c.fill();
    // Separate jaw opens slightly during roars and transformations.
    const jaw = o.roar ? 8 : 2;
    const jy = -94 + jaw;
    c.fillStyle = "#8f7968";
    c.strokeStyle = "#110607";
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(0, jy);
    c.lineTo(21, jy - 2);
    c.lineTo(16, jy + 9);
    c.lineTo(3, jy + 8);
    c.closePath();
    c.fill();
    c.stroke();
    c.fillStyle = "#f0dfbf";
    for (let i = 0; i < 5; i++) {
      const x = 4 + i * 3.2;
      c.beginPath();
      c.moveTo(x, jy);
      c.lineTo(x + 1.2, jy + 5);
      c.lineTo(x + 2.2, jy);
      c.fill();
    }
    c.strokeStyle = "#5b463d";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-5, -103);
    c.lineTo(2, -99);
    c.lineTo(-2, -94);
    c.moveTo(18, -115);
    c.lineTo(12, -117);
    c.stroke();
    const shoulder1 = { x: 18, y: -79 },
      shoulder2 = { x: -17, y: -77 };
    if (o.blade) {
      const arm = (S, A, far) => {
        const hand = { x: S.x + Math.cos(A) * 35, y: S.y + Math.sin(A) * 35 },
          e = ik(S.x, S.y, hand.x, hand.y, 18, 19, 1);
        limb(
          c,
          [S, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
          11,
          p.dark,
          far ? "#4a1b20" : p.flesh2,
          p.bone2,
        );
        drawDemonBlade(c, e.tx, e.ty, A, 82, o.glow);
        c.fillStyle = p.bone2;
        c.beginPath();
        c.arc(e.tx, e.ty, 5, 0, TAU);
        c.fill();
      };
      arm(shoulder2, o.bladeB, true);
      arm(shoulder1, o.bladeA, false);
    } else {
      const A = o.hammerA,
        center = { x: 17 + Math.cos(A) * 28, y: -70 + Math.sin(A) * 28 },
        grip1 = {
          x: center.x - Math.cos(A) * 14,
          y: center.y - Math.sin(A) * 14,
        },
        grip2 = {
          x: center.x - Math.cos(A) * 35,
          y: center.y - Math.sin(A) * 35,
        };
      const arm = (S, T, far) => {
        const e = ik(S.x, S.y, T.x, T.y, 18, 18, 1);
        limb(
          c,
          [S, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
          11,
          p.dark,
          far ? "#43181c" : p.flesh2,
          p.bone2,
        );
        c.fillStyle = p.bone2;
        c.beginPath();
        c.arc(T.x, T.y, 5, 0, TAU);
        c.fill();
      };
      arm(shoulder2, grip2, true);
      drawDemonHammer(c, center.x, center.y, A, o.glow);
      arm(shoulder1, grip1, false);
    }
    c.restore();
    c.restore();
  }
  function drawDemonTransformBeam() {
    if (B.type !== "demon" || B.state !== "transform") return;
    const k = clamp(B.pt / 2.65, 0, 1),
      pulse = 0.78 + 0.22 * Math.sin(time * 38),
      fade = k < 0.08 ? k / 0.08 : k > 0.9 ? (1 - k) / 0.1 : 1,
      w = 105 + 55 * Math.sin(Math.PI * k);
    ctx.save();
    ctx.globalCompositeOperation = "screen";
    ctx.globalAlpha = fade;
    const g = ctx.createLinearGradient(B.x - w, 0, B.x + w, 0);
    g.addColorStop(0, "rgba(255,0,0,0)");
    g.addColorStop(0.28, "rgba(255,25,10,.72)");
    g.addColorStop(0.5, "rgba(255,235,210," + pulse * 0.98 + ")");
    g.addColorStop(0.72, "rgba(255,30,12,.75)");
    g.addColorStop(1, "rgba(255,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(B.x - w, -40, w * 2, GROUND + 45);
    ctx.fillStyle = "rgba(255,245,230,.88)";
    ctx.fillRect(B.x - 22 * pulse, -40, 44 * pulse, GROUND + 45);
    ctx.strokeStyle = "rgba(255,70,35,.95)";
    ctx.lineWidth = 5;
    for (let i = 0; i < 5; i++) {
      let x = B.x + rnd(-w * 0.7, w * 0.7);
      ctx.beginPath();
      ctx.moveTo(x, -20);
      for (let y = 20; y < GROUND; y += 42) {
        x += rnd(-22, 22);
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "rgba(255,55,20,.55)";
    ctx.beginPath();
    ctx.ellipse(B.x, GROUND + 2, w * 1.35, 24, 0, 0, TAU);
    ctx.fill();
    ctx.restore();
  }
  function updateSlashes(dt) {
    for (let i = slashes.length - 1; i >= 0; i--) {
      const p = slashes[i],
        target = projectileTarget(p);
      p.t += dt;
      p.x += p.vx * dt;
      p.rot += dt * 26;
      if (Math.random() < 0.8)
        parts.push({
          k: "dot",
          x: p.x - p.face * 14,
          y: p.y + rnd(-6, 6),
          vx: -p.face * 40,
          vy: rnd(-8, 8),
          life: 0.22,
          t: 0,
          col: "255,224,140",
          g: 0,
          drag: 2,
          sz: rnd(3, 6),
        });
      let dead = p.t > p.life || p.x < -60 || p.x > WORLD + 60;
      if (!p.hit && target.state !== "dead" && target.state !== "intro") {
        const lo = Math.min(p.x - 18, p.x + 18),
          hi = Math.max(p.x - 18, p.x + 18);
        if (
          target.x + target.hw > lo &&
          target.x - target.hw < hi &&
          p.pb + 125 > target.h &&
          p.pb - 20 < target.h + target.hh
        ) {
          p.hit = true;
          dead = true;
          hitProjectileTarget(p, 300, 0.1, true, true);
          spark(p.x, p.y, 26, "#fff3b0", 560, 0.5);
          addRing(p.x, p.y, 6, 70, 0.3, "rgba(255,232,140,.9)", 5);
        }
      }
      if (dead) slashes.splice(i, 1);
    }
  }
  function updateOrbs(dt) {
    for (let i = orbs.length - 1; i >= 0; i--) {
      const o = orbs[i];
      o.t += dt;
      o.vy += o.g * dt;
      o.x += o.vx * dt;
      o.y += o.vy * dt;
      if (Math.random() < 0.6)
        parts.push({
          k: "dot",
          x: o.x,
          y: o.y,
          vx: 0,
          vy: 0,
          life: 0.25,
          t: 0,
          col: "150,195,255",
          g: 0,
          drag: 1,
          sz: 5,
        });
      let dead =
        o.t > o.life ||
        o.x < 0 ||
        o.x > WORLD ||
        (o.g > 0 && o.y >= GROUND - 4 && o.vy > 0);
      if (!dead && heroType === "wizard") {
        for (const s of skeletons) {
          if (
            s.hp > 0 &&
            s.state !== "spawn" &&
            Math.abs(o.x - s.x) < 14 + o.r &&
            o.y > GROUND - 116 &&
            o.y < GROUND + 8
          ) {
            damageSkeleton(s, o.dmg);
            dead = true;
            break;
          }
        }
      }
      if (
        !dead &&
        P.state !== "dead" &&
        P.invuln <= 0 &&
        Math.abs(o.x - P.x) < 14 + o.r &&
        o.y > P.y - 104 &&
        o.y < P.y + 10
      ) {
        if (hurtPlayer(o.dmg, o.x, false)) dead = true;
      }
      if (dead) {
        spark(o.x, Math.min(o.y, GROUND - 4), 6, "#bcd8ff", 260, 0.3);
        orbs.splice(i, 1);
      }
    }
  }
  function drawSlashes() {
    for (const p of slashes) {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot * 0.3);
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, 30);
      g.addColorStop(0, "rgba(255,252,224,1)");
      g.addColorStop(0.4, "rgba(255,224,130,.9)");
      g.addColorStop(1, "rgba(255,180,50,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(0, 0, 30, 15, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,246,200,.95)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.ellipse(0, 0, 20, 9, 0, 0.3, TAU - 0.3);
      ctx.stroke();
      ctx.strokeStyle = "rgba(255,214,110,.8)";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.ellipse(2, 0, 12, 5, 0, 0, TAU);
      ctx.stroke();
      ctx.restore();
    }
  }
  function drawOrbs() {
    for (const o of orbs) {
      const r = 16 + Math.sin(time * 30 + o.x) * 1.5;
      const g = ctx.createRadialGradient(o.x, o.y, 1, o.x, o.y, r * 1.8);
      g.addColorStop(0, "rgba(255,255,255,1)");
      g.addColorStop(0.35, "rgba(160,200,255,.95)");
      g.addColorStop(1, "rgba(60,110,255,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(o.x, o.y, r * 1.8, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#eaf4ff";
      ctx.beginPath();
      ctx.arc(o.x, o.y, o.r * 0.6, 0, TAU);
      ctx.fill();
    }
  }
  function drawGreatsword(c, hx, hy, A, len, glow) {
    c.save();
    c.translate(hx, hy);
    c.rotate(A);
    c.fillStyle = "#23262f";
    c.fillRect(-27, -2.8, 29, 5.6);
    c.strokeStyle = "#4b5166";
    c.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      c.beginPath();
      c.moveTo(-25 + i * 4.6, -2.8);
      c.lineTo(-23 + i * 4.6, 2.8);
      c.stroke();
    }
    poly(
      c,
      [
        [-27, -4.5],
        [-27, 4.5],
        [-42, 0],
      ],
      "#8e94a8",
      "#090a11",
      1,
    );
    c.fillStyle = "#a9b0c6";
    c.strokeStyle = "#090a11";
    c.beginPath();
    c.arc(-28, 0, 3.6, 0, TAU);
    c.fill();
    c.stroke();
    c.fillStyle = "#7d8395";
    c.lineWidth = 1.2;
    c.beginPath();
    c.moveTo(1, -14);
    c.quadraticCurveTo(6, -12, 7, -6);
    c.lineTo(7, 6);
    c.quadraticCurveTo(6, 12, 1, 14);
    c.lineTo(-2, 9);
    c.lineTo(-2, -9);
    c.closePath();
    c.fill();
    c.stroke();
    c.fillStyle = "#2b58cf";
    c.beginPath();
    c.arc(2.5, 0, 2.3, 0, TAU);
    c.fill();
    if (glow) {
      c.shadowColor = "#7fb0ff";
      c.shadowBlur = glow;
    }
    const g = c.createLinearGradient(0, -5, 0, 5);
    g.addColorStop(0, "#5b7099");
    g.addColorStop(0.5, "#cfe2fb");
    g.addColorStop(1, "#5b7099");
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(7, -5);
    c.lineTo(len - 18, -4.4);
    c.lineTo(len, 0);
    c.lineTo(len - 18, 4.4);
    c.lineTo(7, 5);
    c.closePath();
    c.fill();
    c.shadowBlur = 0;
    c.strokeStyle = "#090a11";
    c.lineWidth = 1.2;
    c.stroke();
    c.strokeStyle = "rgba(235,245,255,.75)";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(12, 0);
    c.lineTo(len - 26, 0);
    c.stroke();
    c.fillStyle = "rgba(70,110,200,.7)";
    for (let i = 0; i < 6; i++) c.fillRect(22 + i * 12, -1.4, 4, 2.8);
    c.restore();
  }
  function drawArtorias(c, o) {
    const p = PAL_A,
      t = o.t,
      run = o.run || 0,
      air = o.air,
      crouch = o.crouch || 0,
      lean = o.lean || 0;
    c.save();
    c.translate(o.x, o.y);
    c.scale(o.face * o.scale, o.scale);
    if (o.rot) c.rotate(o.rot);
    c.globalAlpha = o.alpha === undefined ? 1 : o.alpha;
    if (o.flash) c.filter = "brightness(2.6) saturate(.35)";
    const hipY = -44 + crouch * 0.9;
    let fA, fB;
    if (air) {
      fA = { x: -8, y: -16 };
      fB = { x: 12, y: -28 };
    } else if (o.slide) {
      fA = { x: -18, y: -2 };
      fB = { x: 24, y: -1 };
    } else if (o.kneel) {
      fA = { x: -22, y: -2 };
      fB = { x: 12, y: 0 };
    } else {
      const ph = o.phase !== undefined ? o.phase : t * 7,
        rx = 17 * run;
      fA = {
        x: -10 * (1 - run) + Math.sin(ph) * rx,
        y: -Math.max(0, Math.cos(ph)) * 10 * run,
      };
      fB = {
        x: 10 * (1 - run) + Math.sin(ph + Math.PI) * rx,
        y: -Math.max(0, Math.cos(ph + Math.PI)) * 10 * run,
      };
    }
    const drawLeg = (hx, f, far) => {
      const k = ik(hx, hipY, f.x, f.y, 23, 23, -1);
      limb(
        c,
        [
          { x: hx, y: hipY },
          { x: k.x, y: k.y },
          { x: k.tx, y: k.ty },
        ],
        12,
        p.outline,
        far ? p.legFar : p.leg,
        p.light,
      );
      c.fillStyle = p.dark;
      c.strokeStyle = p.outline;
      c.lineWidth = 1;
      c.beginPath();
      c.ellipse(k.tx + 4, k.ty - 2, 10, 5, 0, 0, TAU);
      c.fill();
      c.stroke();
      c.fillStyle = p.trim;
      c.beginPath();
      c.arc(k.x + 2, k.y, 5, 0, TAU);
      c.fill();
      c.stroke();
    };
    drawLeg(-4, fA, true);
    drawLeg(4, fB, false);
    // tattered blue cloth
    const sw = Math.sin(t * 1.7) * 1.8 + run * -7 + (o.clothSway || 0);
    poly(
      c,
      [
        [-9, hipY - 3],
        [-4, hipY - 3],
        [-14 + sw, hipY + 34],
        [-21 + sw, hipY + 30],
        [-24 + sw, hipY + 38],
      ],
      p.cloakDark,
      p.outline,
      1,
    );
    poly(
      c,
      [
        [-8, hipY - 3],
        [12, hipY - 3],
        [16 + sw, hipY + 30],
        [11 + sw, hipY + 26],
        [6 + sw, hipY + 37],
        [sw, hipY + 27],
        [-6 + sw, hipY + 35],
      ],
      p.cloak,
      p.outline,
      1.2,
    );

    c.save();
    c.translate(0, crouch);
    c.translate(0, -44);
    c.rotate(lean);
    c.translate(0, 44);
    const w1 = Math.sin(t * 3) * 3 + run * 9 + (o.capeBack || 0),
      w2 = Math.sin(t * 3 + 1) * 4 + run * 12 + (o.capeBack || 0) * 1.4;
    poly(
      c,
      [
        [-4, -85],
        [-16, -72],
        [-24 - w1, -44],
        [-32 - w2, -8],
        [-26 - w2, -1],
        [-21 - w1, -10],
        [-15 - w2 * 0.7, 0],
        [-9 - w1 * 0.5, -9],
        [-3, -2],
        [1, -44],
      ],
      p.cloak,
      p.outline,
      1.4,
    );
    poly(
      c,
      [
        [-4, -80],
        [-13, -66],
        [-19 - w1 * 0.8, -40],
        [-24 - w2 * 0.8, -14],
        [-9, -10],
        [-2, -44],
      ],
      p.cloakDark,
      null,
    );
    // long dark hair streaming from the helm
    c.lineCap = "round";
    for (let i = 0; i < 4; i++) {
      const ph = t * 3.2 + i * 1.2,
        len = 36 + i * 8 + (o.capeBack || 0) * 1.6 + run * 14;
      c.strokeStyle = p.hair;
      c.lineWidth = 3.4 - i * 0.55;
      c.beginPath();
      c.moveTo(-3, -108 + i * 2.2);
      c.bezierCurveTo(
        -13 - len * 0.3,
        -113 + Math.sin(ph) * 5,
        -21 - len * 0.6,
        -101 + Math.sin(ph + 1) * 9 + i * 4,
        -27 - len,
        -93 + i * 8 + Math.sin(ph + 2) * 7,
      );
      c.stroke();
    }
    // broken off-arm, hanging limp
    {
      const S = { x: -5, y: -78 },
        tgt = {
          x: -9 + Math.sin(t * 1.4) * 1.4 - run * 3,
          y: -47 + Math.sin(t * 2.1) * 0.8,
        };
      const e = ik(S.x, S.y, tgt.x, tgt.y, 16, 16, 1);
      limb(
        c,
        [S, { x: e.x, y: e.y }, { x: e.tx, y: e.ty }],
        9.5,
        p.outline,
        p.legFar,
        p.trim,
      );
      c.fillStyle = p.dark;
      c.beginPath();
      c.arc(e.tx, e.ty, 4.6, 0, TAU);
      c.fill();
      c.strokeStyle = p.cloakDark;
      c.lineWidth = 2.4;
      c.beginPath();
      c.moveTo(e.x - 4, e.y - 3);
      c.lineTo(e.x + 4, e.y + 3);
      c.stroke();
    }
    // torso
    const tg = c.createLinearGradient(-12, 0, 14, 0);
    tg.addColorStop(0, p.dark);
    tg.addColorStop(0.5, p.mid);
    tg.addColorStop(1, p.light);
    c.beginPath();
    c.moveTo(-11, -80);
    c.quadraticCurveTo(1, -90, 12, -80);
    c.quadraticCurveTo(17, -64, 11, -46);
    c.lineTo(-10, -46);
    c.quadraticCurveTo(-15, -64, -11, -80);
    c.closePath();
    c.fillStyle = tg;
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.6;
    c.stroke();
    c.strokeStyle = "rgba(0,0,0,.4)";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-10, -70);
    c.quadraticCurveTo(2, -66, 13, -70);
    c.moveTo(-10, -60);
    c.quadraticCurveTo(2, -56, 12, -60);
    c.moveTo(-9, -52);
    c.quadraticCurveTo(2, -49, 11, -52);
    c.stroke();
    c.fillStyle = p.belt;
    c.fillRect(-11, -50, 23, 5.5);
    c.strokeStyle = p.outline;
    c.lineWidth = 1;
    c.strokeRect(-11, -50, 23, 5.5);
    c.fillStyle = p.gold;
    c.beginPath();
    c.arc(1, -47.3, 3.2, 0, TAU);
    c.fill();
    c.stroke();
    poly(
      c,
      [
        [-11, -85],
        [12, -84],
        [16, -72],
        [4, -63],
        [-10, -72],
      ],
      p.cloak,
      p.outline,
      1.2,
    );
    poly(
      c,
      [
        [9, -72],
        [16, -66],
        [18 + Math.sin(t * 2) * 1.5, -49],
        [10, -55],
      ],
      p.cloakDark,
      p.outline,
      1,
    );
    // head: tall crested helm
    c.fillStyle = p.dark;
    c.fillRect(-3, -88, 8, 8);
    const hg = c.createLinearGradient(-9, -114, 14, -84);
    hg.addColorStop(0, p.light);
    hg.addColorStop(0.55, p.mid);
    hg.addColorStop(1, p.dark);
    c.beginPath();
    c.moveTo(-9, -86);
    c.quadraticCurveTo(-12, -103, -3, -111);
    c.quadraticCurveTo(8, -115, 14, -101);
    c.lineTo(13, -88);
    c.quadraticCurveTo(5, -83, -6, -84);
    c.closePath();
    c.fillStyle = hg;
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.6;
    c.stroke();
    poly(
      c,
      [
        [-6, -108],
        [-1, -115],
        [6, -114],
        [10, -107],
        [3, -110],
      ],
      p.dark,
      p.outline,
      1.2,
    );
    poly(
      c,
      [
        [-1, -114],
        [-4, -128],
        [3, -114],
      ],
      p.trim,
      p.outline,
      1,
    );
    c.fillStyle = "#06070c";
    c.fillRect(4, -100, 10, 2.6);
    c.fillRect(8.5, -104, 2.4, 12);
    c.strokeStyle = "rgba(0,0,0,.5)";
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(-6, -96);
    c.quadraticCurveTo(1, -92, 8, -90);
    c.stroke();
    // pauldron
    const pg = c.createRadialGradient(-2, -84, 1, 2, -78, 16);
    pg.addColorStop(0, p.light);
    pg.addColorStop(0.7, p.mid);
    pg.addColorStop(1, p.dark);
    c.fillStyle = pg;
    c.beginPath();
    c.arc(1, -78, 13.5, 0, TAU);
    c.fill();
    c.strokeStyle = p.outline;
    c.lineWidth = 1.6;
    c.stroke();
    c.strokeStyle = p.cloak;
    c.lineWidth = 2.2;
    c.beginPath();
    c.arc(1, -78, 9.5, 0.3, 2.7);
    c.stroke();
    c.fillStyle = p.trim;
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * TAU;
      c.beginPath();
      c.arc(1 + Math.cos(a) * 12, -78 + Math.sin(a) * 12, 0.9, 0, TAU);
      c.fill();
    }
    // sword arm + greatsword
    const S = { x: 3, y: -79 },
      R = o.handR === undefined ? 26 : o.handR,
      A = o.swordA;
    const hand = { x: S.x + Math.cos(A) * R, y: S.y + Math.sin(A) * R };
    const el = ik(S.x, S.y, hand.x, hand.y, 17, 17, 1);
    limb(
      c,
      [S, { x: el.x, y: el.y }, { x: el.tx, y: el.ty }],
      10.5,
      p.outline,
      p.mid,
      p.light,
    );
    drawGreatsword(c, el.tx, el.ty, A, 104, o.glow || 0);
    c.fillStyle = p.mid;
    c.strokeStyle = p.outline;
    c.lineWidth = 1.2;
    c.beginPath();
    c.arc(el.tx, el.ty, 5.4, 0, TAU);
    c.fill();
    c.stroke();
    c.restore();
    c.restore();
  }
  const ART_IDLE = 0.68;
  function artObj() {
    const rage = B.rage;
    const o = {
      kind: "art",
      scale: 1.5,
      x: B.x,
      y: B.y - B.h,
      face: B.face,
      t: time,
      run: B.moving ? 0.55 : 0,
      air: false,
      swordA: ART_IDLE + Math.sin(time * 1.6) * 0.03,
      handR: 26,
      crouch: 8,
      lean: 0.07,
      flash: B.flash > 0,
      alpha: 1,
      glow: rage ? 14 : 4,
      phase: B.stride,
      capeBack: rage ? 6 : 0,
    };
    switch (B.state) {
      case "intro": {
        const k =
          clamp((phaseT - 0.4) / 0.5, 0, 1) *
          (1 - clamp((phaseT - 1.9) / 0.6, 0, 1));
        o.swordA = lerp(ART_IDLE, -1.8, k);
        o.lean = -0.15 * k;
        o.crouch = 8 * (1 - k);
        o.glow = 6 + 16 * k;
        o.capeBack = 8 * k;
        break;
      }
      case "combo": {
        const a = B.atk,
          K = BK[a.type],
          wS = a.w * (rage ? 0.86 : 1);
        let ang;
        o.crouch = 4;
        if (B.phase === "wind") {
          const k = Math.min(1, B.pt / wS);
          ang = lerp(ART_IDLE, K.aw, easeOut(k));
          o.lean = K.wl * k;
          o.handR = lerp(26, K.rw, k);
          o.glow = 8 + k * 12;
          o.capeBack = 5 * k;
        } else if (B.phase === "act") {
          const k = Math.min(1, B.pt / a.a);
          ang = lerp(K.aw, K.a1, ease(k));
          o.lean = lerp(K.wl, K.sl, k);
          o.handR = lerp(K.rw, K.rs, k);
          o.glow = 24;
          o.capeBack = 12;
        } else {
          const k = Math.min(1, B.pt / a.r);
          ang = lerp(K.a1, ART_IDLE, k * k);
          o.lean = K.sl * (1 - k);
          o.handR = lerp(K.rs, 26, k);
        }
        o.swordA = ang;
        o.run = 0;
        break;
      }
      case "jump": {
        if (B.phase === "crouch") {
          const durC = B.jfirst ? (rage ? 0.45 : 0.55) : 0.26,
            k = Math.min(1, B.pt / durC);
          o.crouch = lerp(8, 34, k);
          o.lean = -0.25 * k;
          o.swordA = lerp(ART_IDLE, -2.0, easeOut(k));
          o.glow = 8 + 12 * k;
        } else if (B.phase === "air") {
          const T = rage ? 0.52 : 0.62,
            k = Math.min(1, B.pt / T);
          o.air = true;
          o.crouch = 0;
          o.lean = lerp(-0.1, 0.3, k);
          o.swordA =
            k < 0.6
              ? lerp(-2.0, -1.5, k / 0.6)
              : lerp(-1.5, 1.1, (k - 0.6) / 0.4);
          o.glow = 18;
          o.capeBack = 14;
        } else if (B.phase === "slam") {
          const k = Math.min(1, B.pt / 0.22);
          o.crouch = lerp(16, 8, k);
          o.lean = 0.32 * (1 - k * 0.5);
          o.swordA = 1.05;
          o.glow = 26;
        } else {
          const k = Math.min(1, B.pt / 0.85);
          o.crouch = lerp(12, 8, k);
          o.lean = 0.2 * (1 - k);
          o.swordA = lerp(1.05, ART_IDLE, k);
        }
        o.run = 0;
        break;
      }
      case "rush": {
        if (B.phase === "wind") {
          const windT = B.rfirst ? (rage ? 0.42 : 0.55) : 0.24,
            k = Math.min(1, B.pt / windT);
          o.crouch = lerp(8, 26, k);
          o.lean = -0.3 * k;
          o.swordA = lerp(ART_IDLE, -0.05, easeOut(k));
          o.handR = lerp(26, 8, k);
          o.glow = 10 + 14 * k;
          o.capeBack = 6 * k;
        } else if (B.phase === "dash") {
          o.slide = true;
          o.crouch = 20;
          o.lean = 0.58;
          o.swordA = 0.02;
          o.handR = 44;
          o.glow = 26;
          o.capeBack = 28;
        } else {
          const k = Math.min(1, B.pt / 0.6);
          o.crouch = lerp(18, 8, k);
          o.lean = 0.3 * (1 - k);
          o.swordA = lerp(0.2, ART_IDLE, k);
          o.handR = lerp(36, 26, k);
        }
        o.run = 0;
        break;
      }
      case "explode": {
        const charge = rage ? 0.95 : 1.15;
        if (B.phase === "charge") {
          const k = Math.min(1, B.pt / charge);
          o.swordA = lerp(ART_IDLE, -1.75, easeOut(Math.min(1, k * 2)));
          o.crouch = 8 + 6 * k;
          o.lean = -0.12;
          o.glow = 8 + 18 * k;
          o.capeBack = 12 * k;
          o.shakeX = Math.sin(time * 70) * 1.2 * k;
        } else {
          const k = Math.min(1, B.pt / 0.5);
          o.swordA = lerp(-1.75, 0.5, easeOut(Math.min(1, k * 4)));
          o.lean = 0.25 * (1 - k);
          o.crouch = 4;
          o.glow = 24;
          o.capeBack = 16;
        }
        o.run = 0;
        break;
      }
      case "stunned":
        o.kneel = true;
        o.crouch = 26;
        o.lean = 0.32;
        o.swordA = 1.75;
        o.handR = 26;
        o.glow = 0;
        o.run = 0;
        o.shakeX = Math.sin(time * 40) * 0.8;
        break;
      case "dead": {
        const k = Math.min(1, B.dieT / 1.2);
        o.kneel = k < 1;
        o.crouch = 26 * Math.min(1, k * 3);
        o.lean = 0.32 + k * 0.3;
        o.swordA = 1.75;
        o.glow = 0;
        o.run = 0;
        o.alpha = clamp(1 - (B.dieT - 1.2) / 2.4, 0, 1);
        if (B.dieT > 1.2) o.flash = Math.floor(time * 20) % 2 === 0;
        break;
      }
    }
    if (o.shakeX) o.x += o.shakeX;
    return o;
  }
  function pickHero(type) {
    heroType = type;
    profile.hero = type;
    saveProfile();
    if ($("pickKnight")) {
      $("pickKnight").classList.toggle("selected", type === "knight");
      $("pickShadow").classList.toggle("selected", type === "shadow");
      $("pickRonin").classList.toggle("selected", type === "ronin");
      $("pickRegal").classList.toggle("selected", type === "regal");
      $("pickWizard").classList.toggle("selected", type === "wizard");
    }
    renderTitleKeys();
    relabelTouch();
  }
  function relabelTouch() {
    const shadow = heroType === "shadow",
      ronin = heroType === "ronin",
      regal = heroType === "regal",
      wizard = heroType === "wizard";
    if ($("ba"))
      $("ba").textContent = shadow
        ? "SHOOT"
        : regal
          ? "SWORD"
          : wizard
            ? "MISSILE"
            : "ATTACK";
    if ($("bp"))
      $("bp").textContent = shadow
        ? "DASH"
        : ronin
          ? "DEFLECT"
          : regal
            ? "GUN"
            : wizard
              ? "MAGIC SWORD"
              : "PARRY";
    if ($("bs1"))
      $("bs1").textContent = shadow
        ? "DIVE"
        : ronin
          ? "LUNGE"
          : regal
            ? "STAR"
            : wizard
              ? "SUMMON"
              : "SLASH";
    if ($("bs2"))
      $("bs2").textContent = shadow
        ? "RAIN"
        : ronin
          ? "FLAME"
          : regal
            ? "ABYSS"
            : wizard
              ? "COMET"
              : "BOMB";
  }
  function startGame(type) {
    if (typeof type === "string") bossType = type;
    ac();
    reset();
    phase = "intro";
    phaseT = 0;
    paused = false;
    clearInputState();
    hideFrontScreens();
    $("end").className = "ov hide";
    $("pause").classList.add("hide");
    $("pauseBtn").classList.remove("hide");
    musicStop(1.4);
  }
  function toTitle() {
    reset();
    phase = "title";
    phaseT = 0;
    paused = false;
    clearInputState();
    $("end").className = "ov hide";
    $("pause").classList.add("hide");
    $("pauseBtn").classList.add("hide");
    showFrontScreen("title");
    musicPlay("title");
  }

  /* ================= BACKGROUND LAYERS ================= */
  const LAY = {};
  function makeLayer(w, h, fn) {
    const c = document.createElement("canvas");
    c.width = Math.ceil(w * layerScale);
    c.height = Math.ceil(h * layerScale);
    const g = c.getContext("2d");
    g.scale(layerScale, layerScale);
    fn(g, w, h);
    return c;
  }
  function drawFar(g, w, h) {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#05040a");
    gr.addColorStop(0.5, "#0e0a1c");
    gr.addColorStop(1, "#1b1228");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    const mx = w * 0.56,
      my = 150;
    let rg = g.createRadialGradient(mx, my, 20, mx, my, 260);
    rg.addColorStop(0, "rgba(160,110,230,.5)");
    rg.addColorStop(1, "rgba(160,110,230,0)");
    g.fillStyle = rg;
    g.fillRect(0, 0, w, h);
    g.fillStyle = "#b48be6";
    g.beginPath();
    g.arc(mx, my, 62, 0, TAU);
    g.fill();
    g.fillStyle = "rgba(90,50,150,.28)";
    [
      [-18, -14, 14],
      [16, 8, 20],
      [-10, 26, 9],
      [22, -22, 8],
    ].forEach((c) => {
      g.beginPath();
      g.arc(mx + c[0], my + c[1], c[2], 0, TAU);
      g.fill();
    });
    for (let i = 0; i < 70; i++) {
      g.fillStyle = "rgba(220,210,255," + rnd(0.15, 0.55) + ")";
      g.fillRect(rnd(0, w), rnd(0, 250), 1.2, 1.2);
    }
    g.strokeStyle = "rgba(120,110,175,.13)";
    g.lineWidth = 3;
    for (let x = -60; x < w + 260; x += 230) {
      g.beginPath();
      g.moveTo(x, 440);
      g.lineTo(x, 300);
      g.quadraticCurveTo(x, 210, x + 115, 170);
      g.quadraticCurveTo(x + 230, 210, x + 230, 300);
      g.lineTo(x + 230, 440);
      g.stroke();
    }
  }
  function drawMid(g, w, h) {
    g.fillStyle = "#090b18";
    g.fillRect(0, 0, w, h);
    const step = 290;
    const words = ["AHURA", "KYRIE", "MISERE", "PENITENS"];
    let wi = 0;
    for (let x = -40; x < w + step; x += step) {
      const a = x + 58,
        b = x + step - 20,
        m = (a + b) / 2;
      const gr = g.createLinearGradient(0, 64, 0, 440);
      gr.addColorStop(0, "#2c4a80");
      gr.addColorStop(0.5, "#172a50");
      gr.addColorStop(1, "#0a1224");
      g.beginPath();
      g.moveTo(a, 440);
      g.lineTo(a, 240);
      g.quadraticCurveTo(a, 130, m, 64);
      g.quadraticCurveTo(b, 130, b, 240);
      g.lineTo(b, 440);
      g.closePath();
      g.fillStyle = gr;
      g.fill();
      g.save();
      g.clip();
      g.fillStyle = "rgba(150,80,200,.12)";
      g.fillRect(a, 150, (b - a) / 2, 150);
      g.fillStyle = "rgba(230,150,70,.08)";
      g.fillRect(m, 200, (b - a) / 2, 150);
      let lg = g.createLinearGradient(0, 300, 0, 440);
      lg.addColorStop(0, "rgba(120,170,200,0)");
      lg.addColorStop(1, "rgba(120,170,200,.16)");
      g.fillStyle = lg;
      g.fillRect(a, 300, b - a, 140);
      g.strokeStyle = "rgba(170,190,230,.22)";
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(m, 70);
      g.lineTo(m, 440);
      g.moveTo(a, 300);
      g.lineTo(b, 300);
      g.moveTo(a + (m - a) / 2, 140);
      g.lineTo(a + (m - a) / 2, 440);
      g.moveTo(m + (b - m) / 2, 140);
      g.lineTo(m + (b - m) / 2, 440);
      g.moveTo(m + 24, 190);
      g.arc(m, 190, 24, 0, TAU);
      g.stroke();
      g.restore();
      g.strokeStyle = "#04050d";
      g.lineWidth = 7;
      g.beginPath();
      g.moveTo(a, 440);
      g.lineTo(a, 240);
      g.quadraticCurveTo(a, 130, m, 64);
      g.quadraticCurveTo(b, 130, b, 240);
      g.lineTo(b, 440);
      g.stroke();
      // pillar
      const pg = g.createLinearGradient(x - 40, 0, x + 58, 0);
      pg.addColorStop(0, "#0b0e1f");
      pg.addColorStop(0.45, "#171d38");
      pg.addColorStop(1, "#0a0d1b");
      g.fillStyle = pg;
      g.fillRect(x - 40, 0, 98, 440);
      g.fillStyle = "#1d2444";
      g.fillRect(x - 46, 232, 110, 8);
      g.fillRect(x - 46, 424, 110, 16);
      g.strokeStyle = "rgba(130,150,200,.14)";
      g.lineWidth = 1.5;
      g.beginPath();
      g.moveTo(x - 10, 0);
      g.lineTo(x - 10, 440);
      g.moveTo(x + 28, 0);
      g.lineTo(x + 28, 440);
      g.stroke();
      // banner
      if (Math.floor((x + 40) / step) % 2 === 0) {
        const bx = x - 12;
        g.fillStyle = "rgba(184,172,140,.55)";
        g.beginPath();
        g.moveTo(bx, 40);
        g.lineTo(bx + 42, 40);
        g.lineTo(bx + 42, 236);
        g.lineTo(bx + 21, 250);
        g.lineTo(bx, 236);
        g.closePath();
        g.fill();
        g.strokeStyle = "rgba(60,50,30,.6)";
        g.lineWidth = 1;
        g.stroke();
        g.fillStyle = "rgba(28,22,12,.85)";
        g.font = "700 17px Cinzel, Georgia, serif";
        g.textAlign = "center";
        const word = words[wi++ % words.length];
        for (let i = 0; i < word.length; i++)
          g.fillText(word[i], bx + 21, 66 + i * 24);
      }
    }
  }
  function drawNear(g, w, h) {
    for (let x = 120; x < w + 500; x += 640) {
      const pg = g.createLinearGradient(x - 55, 0, x + 55, 0);
      pg.addColorStop(0, "#04050b");
      pg.addColorStop(0.5, "#0d1122");
      pg.addColorStop(1, "#03040a");
      g.fillStyle = pg;
      g.fillRect(x - 55, 0, 110, 452);
      g.fillStyle = "#131933";
      g.fillRect(x - 64, 60, 128, 10);
      g.fillRect(x - 64, 430, 128, 22);
      g.strokeStyle = "rgba(140,160,210,.12)";
      g.lineWidth = 2;
      g.beginPath();
      g.moveTo(x - 20, 70);
      g.lineTo(x - 20, 430);
      g.moveTo(x + 22, 70);
      g.lineTo(x + 22, 430);
      g.stroke();
      g.strokeStyle = "rgba(120,120,150,.25)";
      g.lineWidth = 1.6;
      g.setLineDash([3, 4]);
      g.beginPath();
      g.moveTo(x + 90, 0);
      g.lineTo(x + 90 + 4, 210);
      g.stroke();
      g.setLineDash([]);
    }
    const fg = g.createLinearGradient(0, 300, 0, 450);
    fg.addColorStop(0, "rgba(60,50,90,0)");
    fg.addColorStop(1, "rgba(60,50,90,.28)");
    g.fillStyle = fg;
    g.fillRect(0, 300, w, 150);
  }
  function drawGround(g, w, h) {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#262034");
    gr.addColorStop(0.25, "#171221");
    gr.addColorStop(1, "#08060d");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "rgba(0,0,0,.55)";
    g.lineWidth = 1.5;
    [10, 26, 48, 78].forEach((y) => {
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(w, y);
      g.stroke();
    });
    for (let x = 0; x < w; x += 150) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x + (x - w / 2) * 0.18, h);
      g.stroke();
    }
    g.strokeStyle = "rgba(230,190,110,.22)";
    g.lineWidth = 2;
    [
      [430, 40],
      [320, 30],
      [190, 18],
    ].forEach((r) => {
      g.beginPath();
      g.ellipse(w / 2, 46, r[0], r[1], 0, 0, TAU);
      g.stroke();
    });
    for (let i = 0; i < 32; i++) {
      const a = (i / 32) * TAU;
      g.beginPath();
      g.moveTo(w / 2 + Math.cos(a) * 320, 46 + Math.sin(a) * 30);
      g.lineTo(w / 2 + Math.cos(a) * 430, 46 + Math.sin(a) * 40);
      g.stroke();
    }
    g.fillStyle = "rgba(230,190,110,.3)";
    g.font = "600 11px Cinzel, Georgia, serif";
    g.textAlign = "center";
    "MISERERE  NOBIS  DOMINE".split("").forEach((ch, i, arr) => {
      const a = -Math.PI / 2 + (i / arr.length) * TAU + 0.1;
      g.save();
      g.translate(w / 2 + Math.cos(a) * 375, 46 + Math.sin(a) * 35);
      g.rotate(a + Math.PI / 2);
      g.scale(1, 0.18);
      g.fillText(ch, 0, 0);
      g.restore();
    });
    const rg = g.createRadialGradient(w / 2, 40, 10, w / 2, 40, 520);
    rg.addColorStop(0, "rgba(170,120,230,.16)");
    rg.addColorStop(1, "rgba(170,120,230,0)");
    g.fillStyle = rg;
    g.fillRect(0, 0, w, h);
    g.fillStyle = "#3a3050";
    g.fillRect(0, 0, w, 1.5);
  }
  function drawVig(g, w, h) {
    const rg = g.createRadialGradient(
      w / 2,
      h / 2,
      h * 0.32,
      w / 2,
      h / 2,
      h * 0.95,
    );
    rg.addColorStop(0, "rgba(0,0,0,0)");
    rg.addColorStop(1, "rgba(2,1,6,.78)");
    g.fillStyle = rg;
    g.fillRect(0, 0, w, h);
  }
  function drawFog(g, w, h) {
    for (let i = 0; i < 16; i++) {
      const x = rnd(0, w),
        y = rnd(40, h - 30),
        r = rnd(110, 200),
        rg = g.createRadialGradient(x, y, 0, x, y, r);
      rg.addColorStop(0, "rgba(150,140,190,.10)");
      rg.addColorStop(1, "rgba(150,140,190,0)");
      g.fillStyle = rg;
      g.fillRect(x - r, y - r, r * 2, r * 2);
    }
  }
  function drawDemonFar(g, w, h) {
    const sky = g.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#090407");
    sky.addColorStop(0.45, "#38100d");
    sky.addColorStop(1, "#a12a12");
    g.fillStyle = sky;
    g.fillRect(0, 0, w, h);
    const sun = g.createRadialGradient(w * 0.55, 110, 10, w * 0.55, 110, 260);
    sun.addColorStop(0, "rgba(255,170,55,.9)");
    sun.addColorStop(0.35, "rgba(255,55,20,.35)");
    sun.addColorStop(1, "rgba(255,30,10,0)");
    g.fillStyle = sun;
    g.fillRect(0, 0, w, h);
    g.fillStyle = "#18080a";
    g.beginPath();
    g.moveTo(0, 360);
    for (let x = 0; x <= w; x += 90) g.lineTo(x, 210 - rnd(0, 150));
    g.lineTo(w, 440);
    g.lineTo(0, 440);
    g.fill();
    for (let i = 0; i < 5; i++) {
      const x = w * (0.12 + i * 0.2),
        top = 110 + rnd(-25, 35);
      g.fillStyle = "#260b0c";
      g.beginPath();
      g.moveTo(x - 90, 420);
      g.lineTo(x, top);
      g.lineTo(x + 100, 420);
      g.fill();
      g.strokeStyle = "#ff3b18";
      g.lineWidth = 4;
      g.beginPath();
      g.moveTo(x, top + 18);
      g.bezierCurveTo(x - 12, 220, x + 18, 285, x - 4, 420);
      g.stroke();
    }
  }
  function drawDemonMid(g, w, h) {
    g.clearRect(0, 0, w, h);
    g.fillStyle = "rgba(18,5,7,.94)";
    for (let x = -30; x < w; x += 235) {
      g.fillRect(x, 260, 58, 185);
      g.fillRect(x - 18, 250, 94, 16);
      g.strokeStyle = "#6b2118";
      g.lineWidth = 5;
      g.beginPath();
      g.moveTo(x + 29, 260);
      g.lineTo(x + 29, 80);
      g.stroke();
      g.fillStyle = "#311013";
      g.beginPath();
      g.arc(x + 29, 75, 28, 0, TAU);
      g.fill();
    }
    g.strokeStyle = "rgba(255,60,25,.45)";
    g.lineWidth = 3;
    for (let x = 0; x < w; x += 180) {
      g.beginPath();
      g.moveTo(x, 390);
      g.lineTo(x + 70, 315);
      g.lineTo(x + 125, 390);
      g.stroke();
    }
  }
  function drawDemonNear(g, w, h) {
    g.clearRect(0, 0, w, h);
    for (let x = 150; x < w; x += 520) {
      g.fillStyle = "#0d0507";
      g.fillRect(x - 32, 0, 64, 445);
      g.strokeStyle = "#421217";
      g.lineWidth = 6;
      g.strokeRect(x - 32, 0, 64, 445);
      g.strokeStyle = "#8c2a1b";
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(x - 58, 0);
      g.lineTo(x - 52, 180);
      g.moveTo(x + 58, 0);
      g.lineTo(x + 52, 180);
      g.stroke();
    }
  }
  function drawDemonGround(g, w, h) {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#3a1a17");
    gr.addColorStop(1, "#090506");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    g.strokeStyle = "#170707";
    g.lineWidth = 2;
    for (let x = 0; x < w; x += 70) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x + rnd(-20, 20), h);
      g.stroke();
    }
    g.shadowColor = "#ff2d14";
    g.shadowBlur = 8;
    g.strokeStyle = "#ff4a1e";
    g.lineWidth = 2;
    for (let x = 30; x < w; x += 145) {
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x + 25, 24);
      g.lineTo(x - 8, 48);
      g.lineTo(x + 32, 78);
      g.lineTo(x + 12, h);
      g.stroke();
    }
    g.shadowBlur = 0;
  }

  function drawShogunFar(g, w, h) {
    const sky = g.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, "#080d16");
    sky.addColorStop(0.52, "#142230");
    sky.addColorStop(1, "#354451");
    g.fillStyle = sky;
    g.fillRect(0, 0, w, h);
    const mx = w * 0.26, my = 86;
    const halo = g.createRadialGradient(mx, my, 8, mx, my, 125);
    halo.addColorStop(0, "rgba(255,255,235,.65)");
    halo.addColorStop(0.18, "rgba(220,232,222,.24)");
    halo.addColorStop(1, "rgba(190,215,225,0)");
    g.fillStyle = halo;
    g.fillRect(mx - 140, my - 140, 280, 280);
    g.fillStyle = "#eef1df";
    g.beginPath();
    g.arc(mx, my, 34, 0, TAU);
    g.fill();
    g.fillStyle = "rgba(115,128,120,.28)";
    for (let i = 0; i < 8; i++) {
      g.beginPath();
      g.arc(mx + rnd(-22, 22), my + rnd(-19, 19), rnd(3, 8), 0, TAU);
      g.fill();
    }
    g.fillStyle = "#0b1119";
    g.beginPath();
    g.moveTo(0, 375);
    for (let x = 0; x <= w; x += 100) g.lineTo(x, 250 + Math.sin(x * 0.011) * 28 + rnd(-25, 18));
    g.lineTo(w, 440);
    g.lineTo(0, 440);
    g.fill();
  }
  function drawShogunMid(g, w, h) {
    g.clearRect(0, 0, w, h);
    g.fillStyle = "rgba(16,23,31,.88)";
    for (let x = 80; x < w; x += 310) {
      const bh = 80 + ((x / 37) % 70);
      g.beginPath();
      g.moveTo(x - 75, 430);
      g.quadraticCurveTo(x - 45, 350 - bh * .4, x, 310 - bh);
      g.quadraticCurveTo(x + 45, 345 - bh * .3, x + 86, 430);
      g.fill();
    }
    g.strokeStyle = "rgba(170,190,200,.24)";
    g.lineWidth = 2;
    for (let x = 40; x < w; x += 220) {
      g.beginPath();
      g.moveTo(x, 430);
      g.lineTo(x + rnd(-16,16), 325);
      g.stroke();
    }
  }
  function drawShogunNear(g, w, h) {
    g.clearRect(0, 0, w, h);
    g.fillStyle = "rgba(3,7,12,.92)";
    for (let x = 170; x < w; x += 620) {
      g.beginPath();
      g.moveTo(x - 54, 445);
      g.quadraticCurveTo(x - 38, 315, x - 12, 278);
      g.quadraticCurveTo(x + 12, 300, x + 46, 445);
      g.fill();
    }
  }
  function drawShogunGround(g, w, h) {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#52605d");
    gr.addColorStop(0.24, "#303c3b");
    gr.addColorStop(1, "#080d12");
    g.fillStyle = gr;
    g.fillRect(0, 0, w, h);
    for (let x = -10; x < w + 20; x += 8) {
      const height = 20 + ((x * 17) % 34 + 34) % 34;
      const sway = Math.sin(x * .09) * 5;
      g.strokeStyle = x % 24 === 0 ? "rgba(242,244,225,.88)" : "rgba(198,208,194,.65)";
      g.lineWidth = x % 24 === 0 ? 1.8 : 1;
      g.beginPath();
      g.moveTo(x, h);
      g.quadraticCurveTo(x + sway, h - height * .55, x + sway * 1.45, h - height);
      g.stroke();
      if (x % 24 === 0) {
        g.fillStyle = "rgba(244,242,220,.8)";
        for (let j = 0; j < 4; j++) {
          const yy = h - height + j * 5;
          g.beginPath();
          g.ellipse(x + sway * 1.45 + (j % 2 ? 3 : -3), yy, 4, 1.2, j % 2 ? .5 : -.5, 0, TAU);
          g.fill();
        }
      }
    }
  }
  function buildBG() {
    LAY.far = makeLayer(W + (WORLD - W) * 0.12, H, drawFar);
    LAY.mid = makeLayer(W + (WORLD - W) * 0.35, H, drawMid);
    LAY.near = makeLayer(W + (WORLD - W) * 0.8, H, drawNear);
    LAY.ground = makeLayer(WORLD, H - 430, drawGround);
    LAY.vig = makeLayer(W, H, drawVig);
    LAY.fog = makeLayer(1400, 220, drawFog);
    LAY.dfar = makeLayer(W + (WORLD - W) * 0.12, H, drawDemonFar);
    LAY.dmid = makeLayer(W + (WORLD - W) * 0.35, H, drawDemonMid);
    LAY.dnear = makeLayer(W + (WORLD - W) * 0.8, H, drawDemonNear);
    LAY.dground = makeLayer(WORLD, H - 430, drawDemonGround);
    LAY.sfar = makeLayer(W + (WORLD - W) * 0.12, H, drawShogunFar);
    LAY.smid = makeLayer(W + (WORLD - W) * 0.35, H, drawShogunMid);
    LAY.snear = makeLayer(W + (WORLD - W) * 0.8, H, drawShogunNear);
    LAY.sground = makeLayer(WORLD, H - 430, drawShogunGround);
  }
  const flowers = [],
    blades = [];
  (function () {
    for (let i = 0; i < 190; i++) {
      const y = 438 + Math.pow(Math.random(), 0.8) * 98;
      flowers.push({
        x: rnd(0, WORLD),
        y,
        s: 0.6 + ((y - 438) / 100) * 0.95,
        h: rnd(10, 30),
        ph: rnd(0, 7),
        n: Math.random() < 0.5 ? 5 : 6,
      });
    }
    flowers.sort((a, b) => a.y - b.y);
    for (let i = 0; i < 420; i++)
      blades.push({
        x: rnd(0, WORLD),
        y: 436 + Math.random() * 100,
        h: rnd(6, 20),
        ph: rnd(0, 7),
      });
  })();
  function drawBlades(y0, y1) {
    ctx.strokeStyle = "rgba(30,58,42,.9)";
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    for (const b of blades) {
      if (b.y < y0 || b.y >= y1 || b.x < cam - 20 || b.x > cam + W + 20)
        continue;
      const sw = Math.sin(time * 1.5 + b.ph) * 2.2;
      ctx.moveTo(b.x, b.y);
      ctx.quadraticCurveTo(
        b.x + sw * 0.4,
        b.y - b.h * 0.5,
        b.x + sw,
        b.y - b.h,
      );
    }
    ctx.stroke();
  }
  function drawFlowers(y0, y1) {
    for (const f of flowers) {
      if (f.y < y0 || f.y >= y1 || f.x < cam - 30 || f.x > cam + W + 30)
        continue;
      const sw = Math.sin(time * 1.4 + f.ph) * 3 * f.s,
        h = f.h * f.s + 8 * f.s,
        cx = f.x + sw,
        cy = f.y - h;
      ctx.strokeStyle = "#1f3d2c";
      ctx.lineWidth = 1.5 * f.s;
      ctx.beginPath();
      ctx.moveTo(f.x, f.y);
      ctx.quadraticCurveTo(f.x + sw * 0.4, f.y - h * 0.5, cx, cy);
      ctx.stroke();
      ctx.fillStyle = "rgba(240,235,255,.11)";
      ctx.beginPath();
      ctx.arc(cx, cy, 10 * f.s, 0, TAU);
      ctx.fill();
      ctx.fillStyle = "#f2eee2";
      ctx.strokeStyle = "rgba(80,70,90,.55)";
      ctx.lineWidth = 0.6;
      ctx.beginPath();
      for (let i = 0; i < f.n; i++) {
        const a = (i / f.n) * TAU + f.ph;
        ctx.moveTo(
          cx + Math.cos(a) * 3.6 * f.s + 2.6 * f.s,
          cy + Math.sin(a) * 3.2 * f.s,
        );
        ctx.arc(
          cx + Math.cos(a) * 3.6 * f.s,
          cy + Math.sin(a) * 3.2 * f.s,
          2.6 * f.s,
          0,
          TAU,
        );
      }
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#e8c15e";
      ctx.beginPath();
      ctx.arc(cx, cy, 1.7 * f.s, 0, TAU);
      ctx.fill();
    }
  }

  /* ================= RENDER ================= */
  function drawShadow(x, y, w, air) {
    ctx.fillStyle = "rgba(0,0,0," + (0.38 - air * 0.2) + ")";
    ctx.beginPath();
    ctx.ellipse(x, GROUND + 4, w * (1 - air * 0.4), 6, 0, 0, TAU);
    ctx.fill();
  }
  function drawBeam() {
    if (B.state !== "kame") return;
    const f = B.face;
    if (B.phase === "charge") {
      const charge = B.rage ? 0.95 : 1.15,
        k = B.pt / charge,
        hx = B.x + f * 51,
        hy = GROUND - 51;
      const r = 8 + 34 * k;
      let g = ctx.createRadialGradient(hx, hy, 1, hx, hy, r * 1.8);
      g.addColorStop(0, "rgba(255,255,255,1)");
      g.addColorStop(0.3, "rgba(210,170,255,.95)");
      g.addColorStop(1, "rgba(110,50,255,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(hx, hy, r * 1.8, 0, TAU);
      ctx.fill();
      // warning lane
      const a = 0.08 + 0.22 * k * (0.6 + 0.4 * Math.sin(time * 26)),
        x0 = B.x + f * 40;
      ctx.fillStyle = "rgba(190,120,255," + a + ")";
      ctx.fillRect(f > 0 ? x0 : x0 - WORLD, GROUND - BEAM_H, WORLD, BEAM_H);
      ctx.strokeStyle = "rgba(230,200,255," + a * 2 + ")";
      ctx.lineWidth = 2;
      ctx.setLineDash([12, 10]);
      ctx.beginPath();
      const yy = GROUND - BEAM_H;
      ctx.moveTo(x0, yy);
      ctx.lineTo(x0 + f * WORLD, yy);
      ctx.stroke();
      ctx.setLineDash([]);
    } else if (B.phase === "fire") {
      const reach = Math.min(WORLD * 1.2, 4200 * B.pt + 40),
        x0 = B.x + f * 40,
        x1 = x0 + f * reach;
      const lo = Math.min(x0, x1),
        wd = Math.abs(reach),
        pulse = 1 + Math.sin(time * 90) * 0.06,
        fade = B.pt > 0.26 ? 1 - (B.pt - 0.26) / 0.1 : 1;
      ctx.save();
      ctx.globalAlpha = clamp(fade, 0, 1);
      const cy = GROUND - BEAM_H / 2;
      const layers = [
        [BEAM_H + 22, "rgba(110,50,255,.35)"],
        [BEAM_H, "rgba(160,100,255,.75)"],
        [BEAM_H * 0.62, "rgba(225,200,255,.95)"],
        [BEAM_H * 0.3, "rgba(255,255,255,1)"],
      ];
      for (const L of layers) {
        const hh = L[0] * pulse;
        ctx.fillStyle = L[1];
        ctx.beginPath();
        ctx.roundRect(lo, cy - hh / 2, wd, hh, hh / 2);
        ctx.fill();
      }
      let g = ctx.createRadialGradient(x0, cy, 2, x0, cy, 90);
      g.addColorStop(0, "rgba(255,255,255,1)");
      g.addColorStop(1, "rgba(150,80,255,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x0, cy, 90, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }
  function drawExplosion() {
    if (B.state !== "explode") return;
    const art = B.type === "art",
      cx = B.x,
      cy = GROUND - 70;
    const C1 = art ? "190,215,255" : "230,200,255",
      C2 = art ? "70,120,255" : "140,70,255",
      C3 = art ? "40,80,230" : "120,50,255",
      C4 = art ? "150,190,255" : "210,150,255",
      C5 = art ? "170,210,255" : "210,160,255";
    if (B.phase === "charge") {
      const chargeT = art ? (B.rage ? 0.95 : 1.15) : B.rage ? 1.0 : 1.2,
        k = Math.min(1, B.pt / chargeT),
        R = 250;
      ctx.save();
      ctx.beginPath();
      ctx.rect(cx - R - 20, 0, R * 2 + 40, GROUND + 6);
      ctx.clip();
      const g = ctx.createRadialGradient(cx, cy, 4, cx, cy, R);
      g.addColorStop(0, "rgba(" + C1 + "," + (0.25 + 0.45 * k) + ")");
      g.addColorStop(0.6, "rgba(" + C2 + "," + (0.1 + 0.15 * k) + ")");
      g.addColorStop(1, "rgba(" + C3 + ",0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, R * (0.35 + 0.65 * k), 0, TAU);
      ctx.fill();
      ctx.restore();
      ctx.strokeStyle =
        "rgba(" +
        C4 +
        "," +
        (0.35 + 0.4 * Math.sin(time * 18) * 0.5 + 0.2) +
        ")";
      ctx.lineWidth = 3;
      ctx.setLineDash([16, 12]);
      ctx.lineDashOffset = -time * 60;
      ctx.beginPath();
      ctx.ellipse(cx, GROUND + 2, R, 22, 0, 0, TAU);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.strokeStyle = "rgba(255,255,255," + (0.2 + 0.5 * k) + ")";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(cx, GROUND + 2, R * k, 22 * k, 0, 0, TAU);
      ctx.stroke();
    } else if (B.phase === "burst") {
      const k = Math.min(1, B.pt / (art ? 0.5 : 0.55)),
        R = 270 * easeOut(Math.min(1, k * 1.6));
      ctx.save();
      ctx.globalAlpha = 1 - k * k;
      const g = ctx.createRadialGradient(cx, cy, 4, cx, cy, R);
      g.addColorStop(0, "rgba(255,255,255,1)");
      g.addColorStop(0.35, "rgba(" + C5 + ",.85)");
      g.addColorStop(1, "rgba(" + C3 + ",0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, TAU);
      ctx.fill();
      ctx.restore();
    }
  }
  function drawParts() {
    for (const p of parts) {
      const k = p.t / p.life;
      if (p.k === "spark") {
        ctx.strokeStyle = p.col;
        ctx.globalAlpha = 1 - k;
        ctx.lineWidth = p.sz * (1 - k * 0.5);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.vx * 0.035, p.y - p.vy * 0.035);
        ctx.stroke();
        ctx.globalAlpha = 1;
      } else if (p.k === "dot") {
        ctx.fillStyle = "rgba(" + p.col + "," + 0.8 * (1 - k) + ")";
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.sz * (1 - k * 0.4), 0, TAU);
        ctx.fill();
      } else if (p.k === "petal") {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.globalAlpha = Math.min(1, (1 - k) * 2);
        ctx.fillStyle = "#f4f0e6";
        ctx.beginPath();
        ctx.ellipse(0, 0, p.sz, p.sz * 0.5, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
      } else if (p.k === "gather") {
        const e = k * k,
          x = lerp(p.sx, p.tx, e),
          y = lerp(p.sy, p.ty, e);
        ctx.fillStyle =
          "rgba(" + (p.gc || "220,180,255") + "," + (0.3 + 0.7 * k) + ")";
        ctx.beginPath();
        ctx.arc(x, y, 2.2 * (1 - k * 0.5), 0, TAU);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }
  function drawFx() {
    for (const f of fx) {
      const k = f.t / f.life;
      if (f.k === "arc") {
        ctx.save();
        ctx.translate(f.x, f.y);
        ctx.scale(f.face, 1);
        ctx.globalAlpha = 1 - k;
        ctx.lineCap = "round";
        ctx.strokeStyle = f.col;
        ctx.lineWidth = f.w * (1 - k * 0.5);
        ctx.beginPath();
        ctx.arc(0, 0, f.r, f.a0, f.a1, f.a1 < f.a0);
        ctx.stroke();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = f.w * 0.3 * (1 - k);
        ctx.beginPath();
        ctx.arc(0, 0, f.r, f.a0, f.a1, f.a1 < f.a0);
        ctx.stroke();
        ctx.restore();
      } else if (f.k === "streak") {
        ctx.save();
        ctx.globalAlpha = 1 - k;
        ctx.lineCap = "round";
        ctx.strokeStyle = f.col;
        ctx.lineWidth = 10 * (1 - k);
        ctx.beginPath();
        ctx.moveTo(f.x, f.y);
        ctx.lineTo(f.x + f.len, f.y);
        ctx.stroke();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 3 * (1 - k);
        ctx.stroke();
        ctx.restore();
      } else if (f.k === "ring") {
        const r = lerp(f.r0, f.r1, easeOut(k));
        ctx.save();
        ctx.globalAlpha = 1 - k;
        ctx.strokeStyle = f.col;
        ctx.lineWidth = f.w * (1 - k);
        ctx.beginPath();
        ctx.ellipse(f.x, f.y, r, r * (f.r1 > 150 ? 0.55 : 1), 0, 0, TAU);
        ctx.stroke();
        ctx.restore();
      } else if (f.k === "groundburst") {
        const r = lerp(18, f.r1, easeOut(k)),
          fade = Math.pow(1 - k, 1.4);
        ctx.save();
        ctx.translate(f.x, f.y);
        ctx.globalAlpha = fade;
        const glow = ctx.createLinearGradient(0, -75, 0, 14);
        glow.addColorStop(0, "rgba(255,40,10,0)");
        glow.addColorStop(0.55, "rgba(255,72,18,.48)");
        glow.addColorStop(1, "rgba(255,210,90,.92)");
        ctx.fillStyle = glow;
        ctx.fillRect(-r, -72, r * 2, 84);
        ctx.strokeStyle = "#ffbd66";
        ctx.lineWidth = 7 * (1 - k) + 2;
        ctx.beginPath();
        ctx.ellipse(0, 2, r, 10 + r * 0.018, 0, 0, TAU);
        ctx.stroke();
        ctx.strokeStyle = "#ff3b18";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.ellipse(0, 3, r * 0.78, 7 + r * 0.014, 0, 0, TAU);
        ctx.stroke();
        const spikes = Math.max(8, Math.floor(r / 55));
        for (let i = 0; i < spikes; i++) {
          const x = -r + ((i + 0.5) * r * 2) / spikes,
            hh = (22 + Math.sin(i * 12.7) * 13) * (1 - k);
          ctx.fillStyle = i % 2 ? "#ff4b1d" : "#ff9a3d";
          ctx.beginPath();
          ctx.moveTo(x - 9, 4);
          ctx.lineTo(x, -hh - 8);
          ctx.lineTo(x + 10, 4);
          ctx.closePath();
          ctx.fill();
        }
        ctx.strokeStyle = "rgba(255,60,20,.9)";
        ctx.lineWidth = 3;
        for (let i = 0; i < 7; i++) {
          const x = ((i - 3) * r) / 7;
          ctx.beginPath();
          ctx.moveTo(x, 4);
          ctx.lineTo(x + (i % 2 ? 18 : -18), 16);
          ctx.lineTo(x + (i % 2 ? -12 : 12), 26);
          ctx.stroke();
        }
        ctx.restore();
      } else if (f.k === "text") {
        ctx.save();
        ctx.globalAlpha = k < 0.7 ? 1 : 1 - (k - 0.7) / 0.3;
        ctx.font = "900 " + f.size + "px Cinzel, Georgia, serif";
        ctx.textAlign = "center";
        ctx.lineWidth = 4;
        ctx.strokeStyle = "rgba(0,0,0,.8)";
        ctx.strokeText(f.txt, f.x, f.y - k * 34);
        ctx.fillStyle = f.col;
        ctx.fillText(f.txt, f.x, f.y - k * 34);
        ctx.restore();
      }
    }
  }
  function render(alpha) {
    if (alpha === undefined) alpha = 1;
    alpha = clamp(alpha, 0, 1);
    const sv = [P.x, P.y, B.x, cam, P.t, B.pt, time, P.stride, B.stride, B.h];
    P.x = lerp(prev.px, P.x, alpha);
    P.y = lerp(prev.py, P.y, alpha);
    B.x = lerp(prev.bx, B.x, alpha);
    cam = lerp(prev.cam, cam, alpha);
    P.stride = lerp(prev.pst, P.stride, alpha);
    B.stride = lerp(prev.bst, B.stride, alpha);
    B.h = lerp(prev.bh, B.h, alpha);
    if (P.state === prev.ps) P.t = lerp(prev.pt, P.t, alpha);
    if (B.state === prev.bs && B.phase === prev.bph)
      B.pt = lerp(prev.bpt, B.pt, alpha);
    time = time - DT * (1 - alpha);
    try {
      renderFrame();
    } finally {
      P.x = sv[0];
      P.y = sv[1];
      B.x = sv[2];
      cam = sv[3];
      P.t = sv[4];
      B.pt = sv[5];
      time = sv[6];
      P.stride = sv[7];
      B.stride = sv[8];
      B.h = sv[9];
    }
  }
  function renderFrame() {
    const rw = cv.width,
      rh = cv.height,
      ds = Math.min(rw / W, rh / H),
      ox = (rw - W * ds) / 2,
      oy = (rh - H * ds) / 2;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#020205";
    ctx.fillRect(0, 0, rw, rh);
    ctx.setTransform(ds, 0, 0, ds, ox, oy);
    ctx.fillStyle = "#05040a";
    ctx.fillRect(0, 0, W, H);
    if (!LAY.far) return;
    const snap = (v) => Math.round(v * RS) / RS;
    const sx = shake ? (Math.random() - 0.5) * shake : 0,
      sy = shake ? (Math.random() - 0.5) * shake * 0.7 : 0;
    const demonArena = B.type === "demon",
      shogunArena = B.type === "shogun",
      specialArena = demonArena || shogunArena;
    ctx.drawImage(
      demonArena ? LAY.dfar : shogunArena ? LAY.sfar : LAY.far,
      snap(-cam * 0.12 + sx * 0.2),
      snap(sy * 0.2),
      W + (WORLD - W) * 0.12,
      H,
    );
    ctx.drawImage(
      demonArena ? LAY.dmid : shogunArena ? LAY.smid : LAY.mid,
      snap(-cam * 0.35 + sx * 0.5),
      snap(sy * 0.5),
      W + (WORLD - W) * 0.35,
      H,
    );
    ctx.drawImage(
      demonArena ? LAY.dnear : shogunArena ? LAY.snear : LAY.near,
      snap(-cam * 0.8 + sx * 0.8),
      snap(sy * 0.8),
      W + (WORLD - W) * 0.8,
      H,
    );
    ctx.save();
    ctx.translate(snap(-cam + sx), snap(sy));
    ctx.drawImage(
      demonArena ? LAY.dground : shogunArena ? LAY.sground : LAY.ground,
      0,
      430,
      WORLD,
      H - 430,
    );
    // fog behind
    const fo = Math.round((time * 9) % 1400);
    if (profile.graphics !== "low") {
      ctx.globalAlpha = profile.graphics === "medium" ? 0.55 : 0.9;
      ctx.drawImage(LAY.fog, Math.round(cam) - fo, 330, 1400, 220);
      ctx.drawImage(LAY.fog, Math.round(cam) - fo + 1400, 330, 1400, 220);
      ctx.globalAlpha = 1;
    }
    if (!specialArena) {
      drawBlades(430, GROUND + 6);
      drawFlowers(0, GROUND);
    }
    drawExplosion();
    drawDemonSmashWarning();
    // boss then hero
    const isPvp = gameMode === "pvp",
      isArt = B.type === "art",
      isDemon = B.type === "demon",
      isShogun = B.type === "shogun",
      isRanger = heroType === "shadow",
      isRonin = heroType === "ronin",
      isRegal = heroType === "regal",
      isWizard = heroType === "wizard",
      isKillnux = heroType === "killnux",
      bo = isPvp
        ? { alpha: 0 }
        : isDemon
        ? demonObj()
        : isArt
          ? artObj()
          : isShogun
            ? shogunObj()
            : bossObj(),
      ho = isRanger ? rangerObj() : isRonin ? roninObj() : heroObj();
    if (!isPvp)
      drawShadow(
        B.x,
        0,
        isDemon ? 82 : isArt || isShogun ? 54 : 46,
        clamp(B.h / 220, 0, 1),
      );
    drawShadow(P.x, 0, 22, clamp((GROUND - P.y) / 170, 0, 1));
    if (isPvp) {
      /* no boss in local versus */
    } else if (B.state === "dead" && bo.alpha <= 0) {
      /* gone */
    } else if (isDemon) drawDemon(ctx, bo);
    else if (isArt) drawArtorias(ctx, bo);
    else if (isShogun) drawShogun(ctx, bo);
    else drawKnight(ctx, bo);
    if (isShogun && shogunMinion) drawShogunMinion(ctx, shogunMinion);
    drawDemonTransformBeam();
    if (isRanger) drawRanger(ctx, ho);
    else if (isRonin) drawRonin(ctx, ho);
    else if (isRegal) drawRegal(ctx, regalObj());
    else if (isWizard) drawWizard(ctx);
    else if (isKillnux) drawKillnux(ctx, killnuxObj());
    else drawKnight(ctx, ho);
    if (gameMode !== "solo" && players[1]) {
      withPlayer(1, () => {
        drawShadow(P.x, 0, 22, clamp((GROUND - P.y) / 170, 0, 1));
        if (heroType === "shadow") drawRanger(ctx, rangerObj());
        else if (heroType === "ronin") drawRonin(ctx, roninObj());
        else if (heroType === "regal") drawRegal(ctx, regalObj());
        else if (heroType === "wizard") drawWizard(ctx);
        else if (heroType === "killnux") drawKillnux(ctx, killnuxObj());
        else drawKnight(ctx, heroObj());
      });
    }
    drawExecMark();
    if (B.state === "stunned") {
      for (let i = 0; i < 3; i++) {
        const a = time * 5 + i * 2.1;
        ctx.fillStyle = "#ffe28a";
        ctx.beginPath();
        ctx.arc(
          B.x + Math.cos(a) * 30,
          GROUND - (B.type === "art" ? 195 : 175) + Math.sin(a) * 7,
          3.5,
          0,
          TAU,
        );
        ctx.fill();
      }
    }
    drawBeam();
    drawDemonHazards();
    drawShogunHazards();
    drawOrbs();
    drawSlashes();
    drawKillWaves();
    drawArrows();
    drawRain();
    drawRegalProjectiles();
    drawWizardSystems();
    drawParts();
    drawFx();
    if (!specialArena) {
      drawBlades(GROUND + 6, 600);
      drawFlowers(GROUND, 600);
    }
    // motes
    const moteStep =
      profile.graphics === "low" ? 4 : profile.graphics === "medium" ? 2 : 1;
    for (let mi = 0; mi < motes.length; mi += moteStep) {
      const m = motes[mi];
      if (m.x < cam - 10 || m.x > cam + W + 10) continue;
      const a = 0.25 + 0.3 * Math.sin(time * 2 + m.ph);
      ctx.fillStyle = "rgba(240,235,255," + a + ")";
      if (m.petal) {
        ctx.save();
        ctx.translate(m.x, m.y);
        ctx.rotate(time + m.ph);
        ctx.beginPath();
        ctx.ellipse(0, 0, m.s * 1.6, m.s * 0.8, 0, 0, TAU);
        ctx.fill();
        ctx.restore();
      } else {
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.s * 0.6, 0, TAU);
        ctx.fill();
      }
    }
    if (profile.graphics === "high") {
      const f2 = Math.round(fo * 1.4) % 1400;
      ctx.globalAlpha = 0.55;
      ctx.drawImage(LAY.fog, Math.round(cam) - f2, 400, 1400, 220);
      ctx.drawImage(LAY.fog, Math.round(cam) - f2 + 1400, 400, 1400, 220);
      ctx.globalAlpha = 1;
    }
    ctx.restore();
    if (profile.graphics !== "low") ctx.drawImage(LAY.vig, 0, 0, W, H);
    if (profile.graphics !== "low" && screenFlash > 0) {
      ctx.fillStyle =
        "rgba(" + screenFlashCol + "," + Math.min(0.7, screenFlash) + ")";
      ctx.fillRect(0, 0, W, H);
    }
    if (P && P.hp < 120 && P.state !== "dead") {
      const a = 0.12 + 0.08 * Math.sin(time * 6);
      const g = ctx.createRadialGradient(
        W / 2,
        H / 2,
        H * 0.35,
        W / 2,
        H / 2,
        H * 0.8,
      );
      g.addColorStop(0, "rgba(120,0,10,0)");
      g.addColorStop(1, "rgba(160,0,20," + a * 2.5 + ")");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
    if (phase !== "title") drawHUD();
    if (phase === "intro") drawIntro();
    if (phase === "won" || phase === "wonUI") {
      const k = clamp(phaseT / 1.5, 0, 1);
      ctx.fillStyle = "rgba(0,0,0," + 0.35 * k + ")";
      ctx.fillRect(0, 0, W, H);
      if (phase === "won" && phaseT > 1) {
        ctx.save();
        ctx.globalAlpha = clamp((phaseT - 1) / 1, 0, 1);
        ctx.textAlign = "center";
        ctx.font = "900 44px Cinzel, Georgia, serif";
        ctx.fillStyle = "#f2dc9c";
        ctx.shadowColor = "#000";
        ctx.shadowBlur = 12;
        ctx.fillText("BOSS DEFEATED", W / 2, 270);
        ctx.restore();
      }
    }
    if (phase === "lost" || phase === "lostUI") {
      const k = clamp(phaseT / 1.6, 0, 1);
      ctx.fillStyle = "rgba(30,0,4," + 0.55 * k + ")";
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* ================= HUD ================= */
  function cropSmooth(img, fx, fy, fw, fh, x, y, s) {
    if (img.complete && img.naturalWidth) {
      const w = img.naturalWidth,
        h = img.naturalHeight;
      ctx.drawImage(img, fx * w, fy * h, fw * w, fh * h, x, y, s, s);
    } else {
      ctx.fillStyle = "#221a2a";
      ctx.fillRect(x, y, s, s);
    }
  }
  function cropPortrait(img, sx, sy, sw, sh, x, y, s) {
    if (img.complete && img.naturalWidth) {
      const r = img.naturalWidth / 736;
      ctx.drawImage(img, sx * r, sy * r, sw * r, sh * r, x, y, s, s);
    } else {
      ctx.fillStyle = "#221a2a";
      ctx.fillRect(x, y, s, s);
    }
  }
  function drawBar(x, y, w, h, frac, ghost, c1, c2) {
    ctx.fillStyle = "#07050a";
    ctx.fillRect(x - 2, y - 2, w + 4, h + 4);
    if (ghost > frac) {
      ctx.fillStyle = "#d9cfae";
      ctx.fillRect(x, y, w * ghost, h);
    }
    const g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, c1);
    g.addColorStop(1, c2);
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w * frac, h);
    ctx.fillStyle = "rgba(255,255,255,.14)";
    ctx.fillRect(x, y, w * frac, h * 0.38);
    ctx.strokeStyle = "#b9975a";
    ctx.lineWidth = 1.6;
    ctx.strokeRect(x - 2.5, y - 2.5, w + 5, h + 5);
    ctx.fillStyle = "#d8b56a";
    [
      [x - 3, y - 3],
      [x + w + 3, y - 3],
      [x - 3, y + h + 3],
      [x + w + 3, y + h + 3],
    ].forEach((c) => {
      ctx.beginPath();
      ctx.moveTo(c[0], c[1] - 3.4);
      ctx.lineTo(c[0] + 3.4, c[1]);
      ctx.lineTo(c[0], c[1] + 3.4);
      ctx.lineTo(c[0] - 3.4, c[1]);
      ctx.fill();
    });
  }
  function drawFlask(x, y, full) {
    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = "#b9975a";
    ctx.lineWidth = 1.6;
    ctx.fillStyle = full ? "#7fe36c" : "rgba(20,16,24,.85)";
    ctx.beginPath();
    ctx.ellipse(0, 5, 8, 9, 0, 0, TAU);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = full ? "#e5dcc2" : "#3a3244";
    ctx.fillRect(-3, -8, 6, 7);
    ctx.strokeRect(-3, -8, 6, 7);
    ctx.fillStyle = full ? "#8a5a2c" : "#2a2430";
    ctx.fillRect(-3.6, -12, 7.2, 4.6);
    if (full) {
      ctx.fillStyle = "rgba(255,255,255,.5)";
      ctx.beginPath();
      ctx.ellipse(-3, 3, 1.6, 3.4, 0.3, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }
  function drawSkillIcon(x, y, r, cd, maxCd, key, kind) {
    const ready = cd <= 0,
      frac = clamp(cd / maxCd, 0, 1);
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = "#0c0910";
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.fill();
    if (kind === "slash") {
      const g = ctx.createRadialGradient(0, 0, 1, 0, 0, r);
      g.addColorStop(0, "rgba(255,244,190,.95)");
      g.addColorStop(1, "rgba(230,170,60,.15)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 0.68, r * 0.3, -0.5, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,240,190,.9)";
      ctx.lineWidth = 1.3;
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 0.68, r * 0.3, -0.5, 0, TAU);
      ctx.stroke();
    } else if (kind === "pierce") {
      ctx.strokeStyle = "rgba(140,240,235,.95)";
      ctx.lineWidth = 2;
      ctx.shadowColor = "#7ff0e6";
      ctx.shadowBlur = 5;
      ctx.beginPath();
      ctx.moveTo(-r * 0.6, 0);
      ctx.lineTo(r * 0.45, 0);
      ctx.stroke();
      ctx.fillStyle = "rgba(200,250,247,.95)";
      ctx.beginPath();
      ctx.moveTo(r * 0.45, -4);
      ctx.lineTo(r * 0.78, 0);
      ctx.lineTo(r * 0.45, 4);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
    } else if (kind === "rain") {
      ctx.strokeStyle = "rgba(140,240,235,.9)";
      ctx.lineWidth = 1.6;
      ctx.shadowColor = "#7ff0e6";
      ctx.shadowBlur = 4;
      for (const dx of [-5, 0, 5]) {
        ctx.beginPath();
        ctx.moveTo(dx, -r * 0.55);
        ctx.lineTo(dx - 2, r * 0.5);
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
    } else if (kind === "scarlet") {
      ctx.strokeStyle = "#ff3557";
      ctx.shadowColor = "#ff244c";
      ctx.shadowBlur = 8;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-r * 0.72, r * 0.38);
      ctx.lineTo(r * 0.72, -r * 0.38);
      ctx.stroke();
      ctx.shadowBlur = 0;
    } else if (kind === "starfall") {
      ctx.fillStyle = "#6d319e";
      ctx.shadowColor = "#a566e8";
      ctx.shadowBlur = 7;
      ctx.beginPath();
      ctx.arc(0, -3, r * 0.42, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "#ddb9ff";
      ctx.lineWidth = 1.5;
      for (const dx of [-6, -2, 2, 6]) {
        ctx.beginPath();
        ctx.moveTo(dx, -1);
        ctx.lineTo(dx - 2, r * 0.65);
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
    } else if (kind === "abyss") {
      ctx.fillStyle = "#1a0628";
      ctx.shadowColor = "#8b42c2";
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 0.72, r * 0.3, 0, 0, TAU);
      ctx.fill();
      ctx.strokeStyle = "#e0b9ff";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-r * 0.65, 0);
      ctx.lineTo(r * 0.7, 0);
      ctx.stroke();
      ctx.shadowBlur = 0;
    } else if (kind === "blood") {
      const g = ctx.createRadialGradient(0, 3, 1, 0, 1, r);
      g.addColorStop(0, "#ffd0a8");
      g.addColorStop(0.38, "#ff405e");
      g.addColorStop(1, "rgba(110,0,20,.25)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(0, -r * 0.8);
      ctx.quadraticCurveTo(r * 0.8, -1, r * 0.35, r * 0.72);
      ctx.quadraticCurveTo(0, r * 0.35, -r * 0.35, r * 0.72);
      ctx.quadraticCurveTo(-r * 0.8, -1, 0, -r * 0.8);
      ctx.fill();
    } else if (kind === "summon") {
      ctx.strokeStyle = "#a8e8ff";
      ctx.fillStyle = "#dff8ff";
      ctx.shadowColor = "#4cbcff";
      ctx.shadowBlur = 7;
      ctx.lineWidth = 1.5;
      for (const dx of [-6, 0, 6]) {
        ctx.beginPath();
        ctx.arc(dx, -2, 3.5, 0, TAU);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(dx, 2);
        ctx.lineTo(dx, 9);
        ctx.moveTo(dx - 4, 5);
        ctx.lineTo(dx + 4, 5);
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
    } else if (kind === "comet") {
      ctx.strokeStyle = "#d9fbff";
      ctx.shadowColor = "#5ad6ff";
      ctx.shadowBlur = 9;
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(-r * 0.72, r * 0.25);
      ctx.lineTo(r * 0.74, -r * 0.25);
      ctx.stroke();
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(-r * 0.1, 0, r * 0.65, 0, TAU);
      ctx.stroke();
      ctx.shadowBlur = 0;
    } else {
      const g = ctx.createRadialGradient(0, 1, 1, 0, 1, r);
      g.addColorStop(0, "rgba(255,224,150,1)");
      g.addColorStop(0.5, "rgba(255,110,40,.9)");
      g.addColorStop(1, "rgba(160,30,10,.2)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(0, 1, r * 0.62, 0, TAU);
      ctx.fill();
    }
    ctx.strokeStyle = ready ? "#f2d48f" : "#5a4a30";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, TAU);
    ctx.stroke();
    if (!ready) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, r, -Math.PI / 2, -Math.PI / 2 + frac * TAU);
      ctx.closePath();
      ctx.fillStyle = "rgba(4,3,6,.74)";
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = "#f2e6c8";
      ctx.font = "700 11px Cinzel, Georgia, serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(Math.ceil(cd), 0, 1);
      ctx.textBaseline = "alphabetic";
    }
    ctx.fillStyle = "rgba(240,230,200,.85)";
    ctx.font = "700 10px Cinzel, Georgia, serif";
    ctx.textAlign = "center";
    ctx.fillText(key, 0, r + 12);
    ctx.restore();
  }
  function drawHUD() {
    ctx.save();
    const px = 16,
      py = 14,
      pr = 36;
    ctx.fillStyle = "#07050a";
    ctx.beginPath();
    ctx.arc(px + pr, py + pr, pr + 4, 0, TAU);
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.arc(px + pr, py + pr, pr, 0, TAU);
    ctx.clip();
    if (heroType === "shadow")
      cropSmooth(imgShadowHero, 0.2, 0.02, 0.6, 0.66, px, py, pr * 2);
    else if (heroType === "ronin")
      cropSmooth(imgRoninHero, 0.14, 0.26, 0.72, 0.42, px, py, pr * 2);
    else if (heroType === "regal")
      cropSmooth(imgRegalHero, 0.22, 0.04, 0.56, 0.42, px, py, pr * 2);
    else if (heroType === "wizard")
      cropSmooth(imgWizardHero, 0.22, 0.0, 0.56, 0.48, px, py, pr * 2);
    else if (heroType === "killnux")
      cropSmooth(imgKillnuxHero, 0.12, 0.02, 0.76, 0.72, px, py, pr * 2);
    else cropPortrait(imgHero, 226, 0, 268, 268, px, py, pr * 2);
    ctx.restore();
    if (P.flash > 0) {
      ctx.fillStyle = "rgba(200,20,30,.45)";
      ctx.beginPath();
      ctx.arc(px + pr, py + pr, pr, 0, TAU);
      ctx.fill();
    }
    ctx.strokeStyle = "#c9a45a";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(px + pr, py + pr, pr + 2, 0, TAU);
    ctx.stroke();
    ctx.strokeStyle = "#4b3714";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(px + pr, py + pr, pr + 5, 0, TAU);
    ctx.stroke();
    const bx = 106;
    drawBar(
      bx,
      24,
      270,
      17,
      P.hp / P.maxhp,
      P.ghost / P.maxhp,
      "#e0403c",
      "#8a1414",
    );
    ctx.font = "700 12px Cinzel, Georgia, serif";
    ctx.textAlign = "left";
    ctx.fillStyle = "#f2e6c8";
    ctx.shadowColor = "#000";
    ctx.shadowBlur = 4;
    ctx.fillText(Math.ceil(P.hp) + " / " + P.maxhp, bx + 6, 37);
    ctx.shadowBlur = 0;
    drawBar(
      bx,
      50,
      200,
      9,
      P.st / P.maxst,
      0,
      P.st < 15 ? "#e0a040" : "#5fd6a0",
      P.st < 15 ? "#8a5a14" : "#1f8a68",
    );
    for (let i = 0; i < P.maxFlasks; i++)
      drawFlask(bx + 8 + i * 15, 80, i < P.flasks);
    if (heroType === "shadow") {
      drawSkillIcon(
        bx + 168,
        82,
        15,
        P.skill1CD,
        skill1MaxCD(),
        primaryKey("skill1"),
        "pierce",
      );
      drawSkillIcon(
        bx + 210,
        82,
        15,
        P.skill2CD,
        skill2MaxCD(),
        primaryKey("skill2"),
        "rain",
      );
    } else if (heroType === "ronin") {
      drawSkillIcon(
        bx + 168,
        82,
        15,
        P.skill1CD,
        skill1MaxCD(),
        primaryKey("skill1"),
        "scarlet",
      );
      drawSkillIcon(
        bx + 210,
        82,
        15,
        P.skill2CD,
        skill2MaxCD(),
        primaryKey("skill2"),
        "blood",
      );
      ctx.font = "700 10px Cinzel, Georgia, serif";
      ctx.fillStyle = "#ff7b90";
      ctx.textAlign = "left";
      ctx.fillText("DEFLECT " + P.deflects + "/15", bx + 244, 77);
      if (P.flameT > 0) {
        ctx.fillStyle = "#ff405e";
        ctx.fillText("BLOODFLAME " + P.flameT.toFixed(1) + "s", bx + 244, 92);
      }
    } else if (heroType === "regal") {
      drawSkillIcon(
        bx + 168,
        82,
        15,
        P.skill1CD,
        skill1MaxCD(),
        primaryKey("skill1"),
        "starfall",
      );
      drawSkillIcon(
        bx + 210,
        82,
        15,
        P.skill2CD,
        skill2MaxCD(),
        primaryKey("skill2"),
        "abyss",
      );
    } else if (heroType === "wizard") {
      drawSkillIcon(
        bx + 168,
        82,
        15,
        P.skill1CD,
        skill1MaxCD(),
        primaryKey("skill1"),
        "summon",
      );
      drawSkillIcon(
        bx + 210,
        82,
        15,
        P.skill2CD,
        skill2MaxCD(),
        primaryKey("skill2"),
        "comet",
      );
      ctx.font = "700 10px Cinzel, Georgia, serif";
      ctx.fillStyle = "#86d8ff";
      ctx.textAlign = "left";
      ctx.fillText(
        "GRAVEGUARD " + skeletons.filter((s) => s.hp > 0).length + "/3",
        bx + 244,
        84,
      );
    } else if (heroType === "killnux") {
      drawSkillIcon(bx + 168,82,15,P.skill1CD,skill1MaxCD(),primaryKey("skill1"),"quake");
      drawSkillIcon(bx + 210,82,15,P.skill2CD,skill2MaxCD(),primaryKey("skill2"),"armor");
      ctx.font = "700 9px Cinzel, Georgia, serif";
      ctx.fillStyle = P.killArmorT > 0 ? "#b998cc" : "#d9e0e7";
      ctx.textAlign = "left";
      ctx.fillText(P.killArmorT > 0 ? "BLACK ARMOUR " + P.killArmorT.toFixed(1) + "s" : "SWORD 200", bx + 244, 84);
    } else {
      drawSkillIcon(
        bx + 168,
        82,
        15,
        P.skill1CD,
        skill1MaxCD(),
        primaryKey("skill1"),
        "slash",
      );
      drawSkillIcon(
        bx + 210,
        82,
        15,
        P.skill2CD,
        skill2MaxCD(),
        primaryKey("skill2"),
        "bomb",
      );
    }
    if (gameMode !== "solo" && players[1]) {
      const p2 = players[1],
        x2 = W - 292;
      ctx.textAlign = "left";
      ctx.font = "800 12px Cinzel, Georgia, serif";
      ctx.fillStyle = "#8fc5ff";
      ctx.fillText(
        "P2 · " +
          (playerHeroes[1] === "killnux"
            ? "KILLNUX"
            : playerHeroes[1].toUpperCase()),
        x2,
        18,
      );
      drawBar(x2, 25, 270, 16, p2.hp / p2.maxhp, p2.ghost / p2.maxhp, "#4e9fe8", "#174e86");
      ctx.fillStyle = "#eef7ff";
      ctx.font = "700 11px Cinzel, Georgia, serif";
      ctx.fillText(Math.ceil(p2.hp) + " / " + p2.maxhp, x2 + 6, 37);
      drawBar(
        x2,
        49,
        200,
        8,
        p2.st / p2.maxst,
        0,
        p2.st < 15 ? "#e0a040" : "#6dd7d0",
        p2.st < 15 ? "#8a5a14" : "#246f7a",
      );
      for (let i = 0; i < p2.maxFlasks; i++)
        drawFlask(x2 + 8 + i * 15, 76, i < p2.flasks);
      withPlayer(1, () => {
        const kinds =
          heroType === "shadow"
            ? ["pierce", "rain"]
            : heroType === "ronin"
              ? ["scarlet", "blood"]
              : heroType === "regal"
                ? ["starfall", "abyss"]
                : heroType === "wizard"
                  ? ["summon", "comet"]
                  : heroType === "killnux"
                    ? ["quake", "armor"]
                    : ["slash", "bomb"];
        drawSkillIcon(
          x2 + 218,
          77,
          13,
          P.skill1CD,
          skill1MaxCD(),
          primaryKey2("skill1"),
          kinds[0],
        );
        drawSkillIcon(
          x2 + 258,
          77,
          13,
          P.skill2CD,
          skill2MaxCD(),
          primaryKey2("skill2"),
          kinds[1],
        );
      });
      ctx.font = "600 8px Cinzel, Georgia, serif";
      ctx.fillStyle = "#9fb4ca";
      ctx.fillText(
        primaryKey2("left") +
          "/" +
          primaryKey2("right") +
          " MOVE · " +
          primaryKey2("attack") +
          " ATTACK · " +
          primaryKey2("dodge") +
          " DODGE · " +
          primaryKey2("heal") +
          " FLASK",
        x2,
        116,
      );
    }
    // boss bar
    if (gameMode !== "pvp" && phase !== "title" && (B.state !== "dead" || B.dieT < 2)) {
      const fill = phase === "intro" ? B.introFill : 1,
        bw = 640,
        bxx = (W - bw) / 2,
        byy = 498;
      ctx.textAlign = "center";
      ctx.font = "700 17px Cinzel, Georgia, serif";
      ctx.fillStyle = "#efdcae";
      ctx.shadowColor = "#000";
      ctx.shadowBlur = 6;
      ctx.fillText(
        B.type === "demon"
          ? "SHATTERED DEMON"
          : B.type === "shogun"
            ? "THE INFERNAL SHOGUN"
            : B.type === "art"
              ? "ARTORIAS THE ABYSSWALKER"
              : "THE VIOLET SENTINEL",
        W / 2,
        byy - 10,
      );
      ctx.shadowBlur = 0;
      const sw = 30;
      ctx.save();
      ctx.beginPath();
      ctx.arc(bxx - 30, byy + 6, sw / 2, 0, TAU);
      ctx.clip();
      if (B.type === "demon") {
        if (imgDemonFace.complete && imgDemonFace.naturalWidth) {
          const sm = ctx.imageSmoothingEnabled;
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(imgDemonFace, bxx - 45, byy - 9, sw, sw);
          ctx.imageSmoothingEnabled = sm;
        } else {
          ctx.fillStyle = "#5b1514";
          ctx.fillRect(bxx - 45, byy - 9, sw, sw);
        }
      } else if (B.type === "shogun")
        cropFrac(
          B.sphase === 2 ? imgShogunP2 : imgShogun,
          0.18,
          0.05,
          0.64,
          0.42,
          bxx - 45,
          byy - 9,
          sw,
        );
      else if (B.type === "art")
        cropFrac(imgArt, 0.367, 0.164, 0.309, 0.309, bxx - 45, byy - 9, sw);
      else cropPortrait(imgBoss, 232, 92, 250, 250, bxx - 45, byy - 9, sw);
      ctx.restore();
      ctx.strokeStyle = "#c9a45a";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(bxx - 30, byy + 6, sw / 2 + 1, 0, TAU);
      ctx.stroke();
      drawBar(
        bxx,
        byy,
        bw,
        13,
        (B.hp / B.maxhp) * fill,
        (B.ghost / B.maxhp) * fill,
        B.type === "demon"
          ? B.dphase === 3
            ? "#ff3a1f"
            : B.dphase === 2
              ? "#d93126"
              : "#b52822"
          : B.type === "shogun"
            ? B.sphase === 2
              ? "#6f2c91"
              : "#e04a24"
            : B.rage
              ? B.type === "art"
                ? "#5a9bff"
                : "#b04cff"
              : "#c93a3a",
        B.type === "demon"
          ? "#5a0907"
          : B.type === "shogun"
            ? B.sphase === 2
              ? "#24102f"
              : "#68180d"
            : B.rage
              ? B.type === "art"
                ? "#1f3f9a"
                : "#4a1a90"
              : "#7a1212",
      );
      if (B.type === "demon") {
        ctx.font = "600 10px Cinzel, Georgia, serif";
        ctx.fillStyle = "#ffb09c";
        ctx.fillText(
          "PHASE " +
            B.dphase +
            (B.dphase === 3 ? "  —  +30% DAMAGE / 10% RANGED PARRY" : ""),
          W / 2,
          byy + 30,
        );
      } else if (B.type === "shogun") {
        ctx.font = "600 10px Cinzel, Georgia, serif";
        ctx.fillStyle = B.sphase === 2 ? "#d6a6ec" : "#ffb27b";
        ctx.fillText(
          B.sphase === 2
            ? "PHASE TWO  —  BLACK FLAME / +20% DAMAGE / 10% DEFLECT"
            : "PHASE ONE  —  10% ATTACK DEFLECT",
          W / 2,
          byy + 30,
        );
      } else if (B.rage) {
        ctx.font = "600 10px Cinzel, Georgia, serif";
        ctx.fillStyle = B.type === "art" ? "#bcd8ff" : "#d9b3ff";
        ctx.fillText(
          B.type === "art" ? "PHASE TWO  -  +40% DAMAGE" : "ENRAGED",
          W / 2,
          byy + 30,
        );
      }
    }
    ctx.restore();
    if (gameMode === "solo" && phase === "fight" && phaseT < 12) {
      ctx.save();
      ctx.globalAlpha = clamp(1 - (phaseT - 8) / 4, 0, 0.8);
      ctx.font = "600 12px Cinzel, Georgia, serif";
      ctx.textAlign = "right";
      ctx.fillStyle = "#f0e2c0";
      ctx.shadowColor = "#000";
      ctx.shadowBlur = 4;
      (heroType === "killnux"
        ? [
            primaryKey("left") + " / " + primaryKey("right") + " move   " + primaryKey("jump") + " jump   " + primaryKey("attack") + " greatsword (200)",
            primaryKey("dodge") + " super dodge (50% farther, 20 stamina)",
            primaryKey("skill1") + " Abyss Quake (400)   " + primaryKey("skill2") + " Black Armour (+50% ATK / +20% DEF)",
            primaryKey("heal") + " flask   Hold " + primaryKey("block") + " to block",
          ]
        : heroType === "shadow"
        ? [
            primaryKey("left") +
              " / " +
              primaryKey("right") +
              " move   " +
              primaryKey("jump") +
              " jump   " +
              primaryKey("attack") +
              " shoot",
            primaryKey("dodge") +
              " dodge (also in the air)   " +
              primaryKey("parry") +
              " Umbral Dash",
            "Hold " +
              primaryKey("block") +
              " to block (-25% damage)   " +
              primaryKey("heal") +
              " flask   Esc pause",
            primaryKey("skill1") +
              " Piercing Dive   " +
              primaryKey("skill2") +
              " Arrow Rain",
          ]
        : heroType === "ronin"
          ? [
              primaryKey("left") +
                " / " +
                primaryKey("right") +
                " move   " +
                primaryKey("attack") +
                " twin katana (100)",
              primaryKey("dodge") +
                " teleport dodge (20 stamina)   " +
                primaryKey("parry") +
                " deflect",
              primaryKey("heal") +
                " flask   15 deflects = 600 damage + stagger",
              primaryKey("skill1") +
                " Scarlet Lunge   " +
                primaryKey("skill2") +
                " Bloodflame",
            ]
          : heroType === "regal"
            ? [
                primaryKey("left") +
                  " / " +
                  primaryKey("right") +
                  " move   " +
                  primaryKey("attack") +
                  " sword (90, 20 stamina)",
                primaryKey("parry") +
                  " pistol (70, 20 stamina)   " +
                  primaryKey("dodge") +
                  " dodge",
                primaryKey("heal") +
                  " flask   Hold " +
                  primaryKey("block") +
                  " to block",
                primaryKey("skill1") +
                  " Black Starfall   " +
                  primaryKey("skill2") +
                  " Abyss Cannon",
              ]
            : heroType === "wizard"
              ? [
                  primaryKey("left") +
                    " / " +
                    primaryKey("right") +
                    " move   " +
                    primaryKey("attack") +
                    " Arcane Missile (100)",
                  primaryKey("parry") +
                    " magic sword (70)   " +
                    primaryKey("dodge") +
                    " blue teleport (20 stamina)",
                  primaryKey("heal") +
                    " flask   Hold " +
                    primaryKey("block") +
                    " for arcane guard",
                  primaryKey("skill1") +
                    " Graveguard Trio   " +
                    primaryKey("skill2") +
                    " Astral Comet",
                ]
              : [
                  primaryKey("left") +
                    " / " +
                    primaryKey("right") +
                    " move   " +
                    primaryKey("jump") +
                    " jump   " +
                    primaryKey("attack") +
                    " attack",
                  primaryKey("dodge") +
                    " dodge (also in the air)   " +
                    primaryKey("parry") +
                    " parry",
                  "Hold " +
                    primaryKey("block") +
                    " to block (-25% damage)   " +
                    primaryKey("heal") +
                    " flask   Esc pause",
                  primaryKey("skill1") +
                    " Sunray Slash   " +
                    primaryKey("skill2") +
                    " Cinder Bomb",
                ]
      ).forEach((s, i) => ctx.fillText(s, W - 16, 26 + i * 17));
      ctx.restore();
    }
  }
  function drawIntro() {
    const t = phaseT,
      a = t < 0.5 ? t / 0.5 : t > 2.2 ? clamp(1 - (t - 2.2) / 0.6, 0, 1) : 1;
    ctx.save();
    ctx.globalAlpha = a;
    ctx.textAlign = "center";
    const g = ctx.createLinearGradient(0, 0, W, 0);
    g.addColorStop(0, "rgba(0,0,0,0)");
    g.addColorStop(0.5, "rgba(0,0,0,.72)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 205, W, 130);
    ctx.font = "900 40px Cinzel, Georgia, serif";
    ctx.fillStyle = "#e9d6a4";
    ctx.shadowColor =
      gameMode === "pvp"
        ? "#5aa7ff"
        : B.type === "demon"
        ? "#ff2a14"
        : B.type === "shogun"
          ? "#ff5a24"
          : B.type === "art"
            ? "#4a7dff"
            : "#7a3cff";
    ctx.shadowBlur = 20;
    ctx.fillText(
      gameMode === "pvp"
        ? "PLAYER 1  VS  PLAYER 2"
        : B.type === "demon"
        ? "SHATTERED DEMON"
        : B.type === "shogun"
          ? "THE INFERNAL SHOGUN"
          : B.type === "art"
            ? "ARTORIAS"
            : "THE VIOLET SENTINEL",
      W / 2,
      262,
    );
    ctx.shadowBlur = 0;
    ctx.font = "600 15px Cinzel, Georgia, serif";
    ctx.fillStyle = "#b9a4d8";
    ctx.fillText(
      gameMode === "pvp"
        ? "Local Duel · Four Flasks Each"
        : gameMode === "coop"
          ? "Two Heroes Stand Together"
          : B.type === "demon"
        ? "The Ruin Beneath the Volcano"
        : B.type === "shogun"
          ? "The Moon-Winged Bowmaster"
          : B.type === "art"
            ? "The Abysswalker"
            : "Warden of the Moonlit Nave",
      W / 2,
      292,
    );
    ctx.strokeStyle = "rgba(201,164,90,.7)";
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(W / 2 - 170, 306);
    ctx.lineTo(W / 2 + 170, 306);
    ctx.stroke();
    ctx.restore();
  }

  /* ================= LOOP ================= */
  let last = performance.now(),
    acc = 0,
    fpsFrames = 0,
    fpsStamp = last;
  function frame(now) {
    pollGamepads();
    fpsFrames++;
    if (now - fpsStamp >= 500) {
      const fps = Math.round((fpsFrames * 1000) / (now - fpsStamp));
      if ($("fpsCounter")) {
        $("fpsCounter").textContent = "FPS " + fps;
        $("fpsCounter").style.color =
          fps >= 55 ? "#9de3b5" : fps >= 40 ? "#f0d17d" : "#ff8a7d";
      }
      fpsFrames = 0;
      fpsStamp = now;
    }
    let d = (now - last) / 1000;
    last = now;
    if (d > 0.1) d = 0.1;
    acc += d;
    while (acc >= DT) {
      step(DT);
      acc -= DT;
    }
    render(acc / DT);
    requestAnimationFrame(frame);
  }
  reset();
  applyVideoSettings();
  buildBG();
  pickHero(heroType);
  updateCoinLabels();
  if (document.fonts && document.fonts.load) {
    Promise.all([
      document.fonts.load("700 16px Cinzel"),
      document.fonts.load("900 16px Cinzel"),
    ])
      .then(() => {
        buildBG();
      })
      .catch(() => {});
  }
  function openMultiplayerLobby(mode) {
    gameMode = mode;
    $("multiKicker").textContent =
      mode === "coop" ? "LOCAL CO-OP" : "LOCAL PVP";
    $("multiTitle").textContent =
      mode === "coop" ? "Two Heroes, One Boss" : "Choose Both Fighters";
    $("multiBossWrap").classList.toggle("hide", mode === "pvp");
    $("startMultiplayer").textContent =
      mode === "coop" ? "BEGIN CO-OP HUNT" : "BEGIN LOCAL DUEL";
    $("multiHero1").value = heroType;
    $("multiHero2").value = heroType2;
    $("p1ControlSummary").innerHTML =
      primaryKey("left") +
      "/" +
      primaryKey("right") +
      " move · " +
      primaryKey("jump") +
      " jump · " +
      primaryKey("attack") +
      " attack · " +
      primaryKey("parry") +
      " parry · " +
      primaryKey("dodge") +
      " dodge<br>" +
      primaryKey("block") +
      " block · " +
      primaryKey("heal") +
      " flask · " +
      primaryKey("skill1") +
      "/" +
      primaryKey("skill2") +
      " skills";
    $("p2ControlSummary").innerHTML =
      primaryKey2("left") +
      "/" +
      primaryKey2("right") +
      " move · " +
      primaryKey2("jump") +
      " jump · " +
      primaryKey2("attack") +
      " attack · " +
      primaryKey2("parry") +
      " parry · " +
      primaryKey2("dodge") +
      " dodge<br>" +
      primaryKey2("block") +
      " block · " +
      primaryKey2("heal") +
      " flask · " +
      primaryKey2("skill1") +
      "/" +
      primaryKey2("skill2") +
      " skills";
    showFrontScreen("multiplayerLobby");
  }
  $("singlePlayer").addEventListener("click", () => {
    gameMode = "solo";
    showFrontScreen("bossSelect");
  });
  $("openCoop").addEventListener("click", () => openMultiplayerLobby("coop"));
  $("openPvp").addEventListener("click", () => openMultiplayerLobby("pvp"));
  $("startMultiplayer").addEventListener("click", () => {
    heroType = $("multiHero1").value;
    heroType2 = $("multiHero2").value;
    if (profile) {
      profile.hero = heroType;
      saveProfile();
    }
    startGame(
      gameMode === "coop" ? $("multiBoss").value : "sentinel",
    );
  });
  $("openLoadout").addEventListener("click", () => showFrontScreen("loadout"));
  $("openShop").addEventListener("click", () => showFrontScreen("shop"));
  document
    .querySelectorAll('[data-back="menu"]')
    .forEach((b) =>
      b.addEventListener("click", () => showFrontScreen("title")),
    );
  $("spinRelic").addEventListener("click", spinRelic);
  $("archiveUp").addEventListener("click", () =>
    $("shopRelicList").scrollBy({
      top:
        -170 * parseFloat(getComputedStyle(stage).getPropertyValue("--u") || 1),
      behavior: "smooth",
    }),
  );
  $("archiveDown").addEventListener("click", () =>
    $("shopRelicList").scrollBy({
      top:
        170 * parseFloat(getComputedStyle(stage).getPropertyValue("--u") || 1),
      behavior: "smooth",
    }),
  );
  $("pickKnight").addEventListener("click", () => {
    pickHero("knight");
    renderLoadout();
  });
  $("pickShadow").addEventListener("click", () => {
    pickHero("shadow");
    renderLoadout();
  });
  $("pickRonin").addEventListener("click", () => {
    pickHero("ronin");
    renderLoadout();
  });
  $("pickRegal").addEventListener("click", () => {
    pickHero("regal");
    renderLoadout();
  });
  $("pickWizard").addEventListener("click", () => {
    pickHero("wizard");
    renderLoadout();
  });
  $("pickKillnux").addEventListener("click", () => {
    pickHero("killnux");
    renderLoadout();
  });
  $("pickSent").addEventListener("click", () => startGame("sentinel"));
  $("pickArt").addEventListener("click", () => startGame("art"));
  $("pickDemon").addEventListener("click", () => startGame("demon"));
  $("pickShogun").addEventListener("click", () => startGame("shogun"));
  $("endBtn").addEventListener("click", () => startGame());
  $("menuBtn").addEventListener("click", toTitle);
  if (window.__TEST__)
    window.__G = {
      step,
      render,
      press,
      release,
      startGame,
      get P() {
        return P;
      },
      get P2() {
        return players[1] || null;
      },
      get B() {
        return B;
      },
      get skeletons() {
        return skeletons;
      },
      get wizardMissiles() {
        return wizardMissiles;
      },
      get shogunHazards() {
        return shogunHazards;
      },
      get shogunMinion() {
        return shogunMinion;
      },
      shogunChoose,
      beginShogunPhase2,
      get phase() {
        return phase;
      },
      set phase(v) {
        phase = v;
      },
      hurtPlayer,
      bossCombatTarget,
      bossStrike,
      COMBOS,
      COMBOS_A,
      renderTrackOffline,
      TRACKS,
      get music() {
        return Music;
      },
      get paused() {
        return paused;
      },
      get binds() {
        return binds;
      },
      openPause,
      closePause,
      toTitle,
      get orbs() {
        return orbs;
      },
      get slashes() {
        return slashes;
      },
      get arrows() {
        return arrows;
      },
      get rain() {
        return rain;
      },
      get regalShots() {
        return regalShots;
      },
      get regalMeteors() {
        return regalMeteors;
      },
      get regalBeams() {
        return regalBeams;
      },
      get bossType() {
        return bossType;
      },
      get heroType() {
        return heroType;
      },
      pickHero,
      buildBonuses,
      renderLoadout,
      renderShop,
      spinRelic,
      rollRelic,
      sellRelic,
      RELICS,
      RARITIES,
      get profile() {
        return profile;
      },
      saveProfile,
      awardCoins,
      SKILL1_CD,
      SKILL2_CD,
      SHADOW_SKILL1_CD,
      SHADOW_SKILL2_CD,
      RONIN_SKILL1_CD,
      RONIN_SKILL2_CD,
      REGAL_SKILL1_CD,
      REGAL_SKILL2_CD,
      KILLNUX_SKILL1_CD,
      KILLNUX_SKILL2_CD,
    };
  requestAnimationFrame((t) => {
    last = t;
    requestAnimationFrame(frame);
  });
})();
