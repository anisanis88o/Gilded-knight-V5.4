GILDED KNIGHT V5.3 — MULTIPLAYER BALANCE

- Reinstalled the supplied hooded-archer artwork as Shadow's portrait.
- All player damage in local PvP is reduced by exactly 50%.
- Every boss has exactly double health in local co-op.
  Violet Sentinel: 8,000 HP
  Artorias: 24,000 HP
  Shattered Demon: 32,000 HP
  Infernal Shogun: 30,000 HP

GILDED KNIGHT V5.2 — CONTROLLER & SMOOTH COMBAT UPDATE

NEW
- Replaced Shadow's selection and HUD portrait with the supplied hooded archer artwork.
- Added two-controller local play through the standard Gamepad API. Controller 1 controls Player 1; Controller 2 controls Player 2.
- Supports standard Xbox 360, Xbox One, Xbox Series S/X, PS4, and PS5 controller layouts.
- Every controller action is independently remappable for Player 1 and Player 2 in Options and through the multiplayer-lobby control buttons.
- Added a remappable command-console activation key (default: `).
- Console command allrelic grants three copies of every relic.
- Console command moneyall sets coins to 99,999.
- Removed Killnux's Lion Claw/parry attack completely; greatsword combo, dodge, Abyss Quake, and Black Armour remain.

PERFORMANCE
- Removed camera shake, full-screen flashes, hit-stop pauses, white character flashes, invulnerability blinking, and hit-particle bursts from damage exchanges.
- Players and bosses still recoil and show damage values, but combat no longer pauses or flickers when hits connect.

GILDED KNIGHT V5.1 — PERFORMANCE & TWO-PLAYER CONTROLS

NEW
- Live FPS counter during menus and gameplay.
- Real resolution/aspect handling for 4:3, 5:4, 16:10, and 16:9 display choices.
- Real graphics presets: Low renders at 50%, Medium at 75%, and High at 100% of the selected resolution.
- Low and Medium also reduce offscreen background resolution, particles, motes, fog, glow overlays, and other expensive effects.
- Player hit reactions remain, but hit-stop, camera jiggle, and impact-particle bursts were removed from damage reactions.
- Player 1 and Player 2 controls are independently remappable from Options or directly from the multiplayer lobby.
- Player 2 now has visible Skill 1 and Skill 2 icons, keys, and cooldown timers in the co-op/PvP HUD.

GILDED KNIGHT V5.0 — LOCAL MULTIPLAYER UPDATE

NEW
- Local Co-op: two heroes fight any boss together; each player receives 5 flasks.
- Local PvP: two players choose any hero and duel; each player receives 4 flasks.
- Shared camera follows both heroes and the boss in co-op, or both fighters in PvP.
- Shattered Demon remains fully restored from V3.2 with its original arena and phases.
- Killnux now has a refined face, shorter hair, smoother pose blending, breathing motion, and the slimmer 20%-reduced silhouette.

PLAYER 2 CONTROLS
- Move: Left / Right arrows
- Jump / Down: Up / Down arrows
- Attack: Numpad 1
- Parry / alternate attack: Numpad 2
- Dodge: Numpad 3
- Flask: Numpad 4
- Skill 1 / Skill 2: Numpad 5 / Numpad 6
- Block: Numpad 0

------------------------------------------------------------

GILDED KNIGHT - BOSS DUELS
==========================

Choose your hero from CHAMPION & BUILD on the title screen:
  The Gilded Knight - sword and shield, health 500, stamina 140
  Shadow - a bow, health 400, stamina 200
  Crimson Ronin - twin red katanas, health 500, stamina 300
  Metal Regal - ornate pistol and sword, health 450, stamina 250
  The Arcane Wizard - sorcery and summons, health 300, stamina 200
  Killnux - colossal greatsword berserker, health 600, stamina 300

Choose your opponent (click a card, or press 1 / 2 / 3 / 5):
  1. The Violet Sentinel  - 4000 health
  2. Artorias the Abysswalker - 12000 health, second phase at 6000 health (+40% damage)
  4. The Infernal Shogun - 15000 health, black-flame phase at 7500 health
     (+20% damage). Rebuilt as a moon-winged bowmaster in a moonlit white-reed
     arena. He now favors readable draw-and-release bow strings, predictive
     arrows, airborne volleys, measured close combos, lunges and teleports.
     His locomotion uses acceleration, deceleration, spacing and body lean for
     a weightier duel rhythm. His deflection chance is 10%. Melee strings are
     limited to 2, 3, or 4 hits with slower boss-3-style windups and recovery.
     Phase two adds faster aerial pressure, dark waves, lightning and a
     500-health katana minion.
  5. Shattered Demon - 16000 health, wings at 11200 health (70%), twin arm-blades at 4800 health (30%)
     Fully code-drawn articulated 2D form slightly taller than Artorias, with a side-facing skull, crooked bone warhammer, animated torn wings, red cape, gold shoulder armor, a moving crimson mane, and curved bull horns. Phase 3 gains +30%
     damage and a 10% chance to parry ranged attacks.

HOW TO PLAY (no install needed)
-------------------------------
Windows : double-click  Play.bat
Mac     : double-click  Play.command   (first time: right-click > Open)
Linux   : run           ./play.sh

The game opens in its own window with no address bar. It needs Google Chrome
or Microsoft Edge (Windows already has Edge). If neither is found, it opens in
your normal browser instead. Everything runs offline.

CONTROLS  (all rebindable: press Esc in a fight, or use the Controls & Music button on the title screen)
--------
Move A/D or arrows      Jump W or Space
Block (hold) B or I     Dodge slide L or Shift
Air dodge: jump, then L or Shift
Healing flask Q or H
F fullscreen    M mute    Esc pause

The Gilded Knight:
  Attack J, Z or click        Parry K, X or right click
  Plunge strike: S + J in the air
  Sunray Slash R               Cinder Bomb E

Crimson Ronin:
  Twin-katana attack J, Z or click - 100 damage per hit
  Deflect K, X or right click - forgiving timing; 15 successful deflects deal 600 damage and stagger the boss
  Teleport dodge L or Shift - costs 20 stamina
  Scarlet Lunge R - 300 damage, 30 second cooldown
  Bloodflame E - +50 attack damage for 20 seconds, 60 second cooldown

Shadow:
  Shoot J, Z or click (works in mid-air too)
  Umbral Dash K, X or right click - a short teleport, only Shadow has this
  Piercing Dive R               Arrow Rain E

Metal Regal:
  Sword J, Z or click - 90 damage, 20 stamina
  Pistol K, X or right click - 70 damage, 20 stamina (replaces parry)
  Black Starfall R              Abyss Cannon E

The Arcane Wizard:
  Arcane Missile J, Z or click - 100 damage, 20 stamina
  Conjured Sword K, X or right click - 70 damage, 10 stamina (replaces parry)
  Blue Teleport L or Shift - 20 stamina
  Graveguard Trio R - summons 3 skeleton swordsmen, 300 health each,
    50 damage per hit, unlimited stamina, 40 second cooldown
  Astral Comet E - charged blue sorcery beam, 1000 damage, 99 second cooldown


KILLNUX — COLOSSAL-SWORD BERSERKER
------------------------------------
Killnux is a fully code-drawn articulated hero based on the supplied black-armored
warrior references. His model includes IK-driven arms and legs, spiked hair, facial
scar, layered black armor, a large wind-reactive cloak, two-handed sword grips,
weighted walking, landing, hurt, healing, defeat and attack animations.

  Colossal Sword (Attack) - 200 damage per hit, 30 stamina.
    Three heavy, chainable swings with anticipation, impact, recoil and recovery.
  Super Dodge (Dodge) - 20 stamina. Travels exactly 50% farther than the standard
    grounded hero dodge, with longer invulnerability and a low forward slide.
  Lion Claw (Parry binding) - 300 damage, 30 stamina. Killnux flips forward with
    the greatsword and slams it down; the full airborne rotation and impact are
    animated.
  Abyss Quake (R / Skill 1) - animated overhead ground slam that releases a large
    travelling black wave for 400 damage. 30 second cooldown.
  Black Armour (E / Skill 2) - transforms Killnux into plated beast armour for
    20 seconds, granting +50% attack and 20% damage reduction. His greatsword
    gains animated black-violet magic. 60 second cooldown.

HERO STATS
----------
The Gilded Knight: health 500, stamina 140 (sword swings and dodges cost 20)
  Sword damage 120 per hit. 7 healing flasks, each heals 70% of max health.
Crimson Ronin: health 500, stamina 300. Twin-katana attacks deal 100 damage per hit.
  Teleport dodge costs 20 stamina. 6 healing flasks.
Shadow: health 400, stamina 200. Umbral Dash costs 50 stamina; each arrow
  shot costs 20 stamina, same as the Knight's sword swings. Bow damage 60
  per arrow, fired fast and in a straight line, works on the ground or
  airborne.
  6 healing flasks, same 70%-of-max-health heal and the same recovery speed
  as the Knight.

METAL REGAL — ORNATE GUNBLADE DUELIST
----------------------------------------
Metal Regal: health 450, stamina 250. The supplied Steam-Metal Regal artwork is
used for his selection card and HUD portrait, while his animated in-game model
matches its black, crimson, and gold coat, mask, bicorne hat, sword, and pistol.

  Sword (J / left click / Z) - animated sweeping slash, 90 damage, 20 stamina.
  Pistol (K / right click / X, the normal Parry binding) - fast straight shot,
    70 damage, 20 stamina. Metal Regal uses this button to shoot instead of parry.
  Black Starfall (R) - throws a large dark orb overhead; it bursts into exactly
    8 falling orbs, each dealing 80 damage. 30 second cooldown, no stamina cost.
  Abyss Cannon (E) - quickly launches a black hand-beam at normal projectile
    speed for 800 damage. 80 second cooldown, no stamina cost.

All four actions have bespoke poses, trails, impacts, sound, cooldown displays,
and rebindable keyboard/mouse/touch controls. Metal Regal also has a full walk
cycle, dodge, block, healing, hurt, and defeat animation set.

SKILLS
------
The Gilded Knight:
  Sunray Slash (R) - a fast golden sword-beam thrown straight ahead.
    300 damage, 30 second cooldown, no stamina cost.
  Cinder Bomb (E) - charge fire in your off-hand and detonate it at close
    range. 800 damage and staggers the boss if you're close enough when it
    goes off. 80 second cooldown, no stamina cost, melee range only.

Shadow:
  Piercing Dive (R) - teleport-dash straight to the boss for 100 damage,
    then fire a 20-arrow barrage (20 damage each, 400 total) while a white
    X above the boss's head turns red as the barrage lands, then drop the
    boss into a stagger. 500 damage total, 30 second cooldown, no stamina.
  Arrow Rain (E) - fire a signal arrow and call down 15-20 arrows on the
    boss's location, 60 damage each. The boss can walk out of the falling
    arrows, so it works best when the boss is stationary or cornered.
    45 second cooldown, no stamina cost.

Both show a cooldown ring with a countdown next to your flasks, and both
can be rebound to any key or mouse button in Controls & Music.

SHATTERED DEMON TIMING
------------------------
Its three-hit arena-smash special now gives a full 1.5-second warning before
every impact. A ground ring and JUMP countdown show exactly when to evade.

FOLDER
------
game/index.html  the page
game/style.css   look of menus
game/game.js     all game code (movement, combat, boss AI, drawing, sound)
game/assets/     hero references and compact menu portraits

TO MAKE A REAL .EXE / .DMG / APPIMAGE (optional)
------------------------------------------------
1. Install Node.js from https://nodejs.org
2. Open a terminal in this folder and run:
     npm install
     npm start            (runs the game as a desktop app)
     npm run build-win    (makes a portable .exe in the dist folder)
   Use build-mac on a Mac, build-linux on Linux. Each system builds its own.
Note: this Electron part was written but not test-built (it needs internet).

REBINDING KEYS AND MUSIC
------------------------
Title screen > CONTROLS & MUSIC (or Esc during a fight > Controls & music).
Click a key box, then press the new key (or click the dashed box with a mouse
button to use Left / Middle / Right click). Every action has up to 3 boxes.
Esc cancels, Backspace clears a box. Esc, Enter, F, M, 1, 2 and 5 are reserved
for menus. Your choices are saved in the browser, so they stay next time.

All music is original solo piano generated inside the game (no audio files):
a slow title theme, battle themes that intensify during later phases, and a short victory piece. Music and Effects have volume sliders.
The browser starts sound only after your first click or key press.

MAIN MENU, BUILDS & RELIC SHOP
------------------------------
The game now opens on an atmospheric main menu:
  SINGLE PLAYER      Choose one of the three bosses and begin the duel.
  CHAMPION & BUILD   Choose a hero and equip up to three relics.
  RELIC SHOP         Spend coins to spin for relics, inspect the collection, or sell relics.
  OPTIONS            Rebind controls and change sound, resolution scale, and graphics quality.

Each defeated boss awards 200 coins. A relic spin costs 100 coins. Common relics
can be sold for 40 coins, but an equipped copy must be removed from its case first.
Coins, owned relics, equipped relics, the selected hero, controls, and settings
are saved locally.

RELIC RARITIES AND DROP CHANCES
-------------------------------
Every rarity contains eight relic families: Attack, Defense, Skill Recovery,
Health, Stamina, Skill Attack Power, Stamina Recovery, and Flask Healing.
The rarity chance is rolled first; each of its eight relics is equally likely.

  COMMON (grey)      50% total / 6.25% per relic
    +5% attack/defense/skill recovery/skill power/stamina recovery/flask healing,
    +20 health, +10 stamina
  RARE (blue)        30% total / 3.75% per relic
    +15% attack/defense/skill recovery/skill power/stamina recovery/flask healing,
    +40 health, +30 stamina
  MYTHIC (purple)    15% total / 1.875% per relic
    +30% attack/defense/skill recovery/skill power/stamina recovery/flask healing,
    +80 health, +70 stamina
  LEGENDARY (yellow) 4% total / 0.5% per relic
    +50% attack/defense/skill recovery/skill power/stamina recovery/flask healing,
    +120 health, +100 stamina
  ANIS (red)         1% total / 0.125% per standard relic
    +100% attack/defense/skill recovery/skill power/stamina recovery/flask healing,
    +200 health, +150 stamina

  HARDY RELIC (black Anis) 0.01% exact independent chance
    Combines all eight Anis powers in one relic: +100% attack, defense, skill
    recovery, skill power, stamina recovery and flask healing, plus +200 health
    and +150 stamina.

Skill Attack Power applies only to active skills, not basic attacks. Stamina
Recovery speeds passive stamina regeneration. Flask Healing increases the amount
restored by each bottle. Common relics sell for 40 coins; higher rarities are kept.
The eight relic families now use distinct shard, shield, heart, hourglass, current,
sigil, coil, and chalice silhouettes while retaining their rarity colors.

SHOP AND PORTRAIT POLISH
------------------------
The Relic Archive and collection now have dark themed scrollbars, fixed row sizes,
sticky rarity headers, smooth up/down buttons, keyboard focus, and preserved scroll
position after a spin or sale. Shadow's selection portrait now breathes and shimmers.
Artorias uses the supplied blue-cloak artwork on the boss-selection screen.

DISPLAY RESOLUTIONS & MENU FEEDBACK
-----------------------------------
Options now applies a real render-buffer resolution and matching display aspect:
  800x600 (4:3), 1152x864 (4:3), 1280x1024 (5:4), 1280x720 (16:9), 1600x900 (16:9),
  1680x1050 (16:10), 1280x800 (16:10), and 1920x1080 (16:9).
Non-16:9 modes use clean black letterboxing so gameplay and HUD art are not
stretched. The selected resolution is saved and restored on the next launch.
Buttons now include hover movement, pressed depth, glow, animated click ripples,
and subtle UI tones. Reduced-motion system settings disable extra animation.


V4.1 MOON-WINGED SHOGUN UPDATE
-------------------------------
- Rebuilt boss 4 face/body silhouette while preserving the red-and-gold outfit.
- Added articulated feathered wings and a fully drawn black/silver war bow.
- Added longer draw tells, predictive arrows and aerial arrow rain.
- Replaced sliding idle motion with weighted acceleration, braking and spacing.
- Added moonlit white-reed battlefield inspired by the supplied references.
- Added subtle weight shift and grounded body motion to Heroes 3 and 4.
- Added the black Hardy Relic at exactly 0.01% per spin.

V4.3 ARTICULATED SHOGUN MODEL REBUILD
--------------------------------------
- Removed the moving PNG model completely.
- Rebuilt boss 4 in the same code-drawn articulated 2D system as Heroes 3 and 4.
- Separate IK-driven legs and arms now control walking, bow drawing, sword
  windups, contact poses, recoil, recovery, flight, stun and defeat states.
- Redesigned the body with black lacquer lamellar armor, red lacing, gold trim,
  plated shoulders, hakama, greaves, torn scarf, black mane and a silver-gold
  oni mask based on the supplied references.
- Added folded grounded wings and expanded airborne feather-wing mechanics.
- Reduced attack deflection from 30% to 10%.
- Slowed melee windup, contact and recovery to match boss 3 pacing.
- Melee combos remain readable 2-, 3-, and 4-hit strings.

V4.4 KILLNUX HERO UPDATE
-------------------------
- Added Killnux as the sixth playable hero.
- Added 600 base health, 300 stamina and six healing flasks.
- Added a code-drawn colossal sword matching the supplied reference proportions.
- Added 200-damage heavy attacks costing 30 stamina per hit.
- Added a 50%-farther super dodge costing 20 stamina.
- Replaced Killnux's parry action with a 300-damage Lion Claw flip slam costing
  30 stamina.
- Added custom selection portrait, HUD portrait, control labels and help text.

V4.5 KILLNUX ABYSS SKILLS
--------------------------
- Added Abyss Quake: animated overhead ground slam and travelling black wave,
  400 base damage, 30-second cooldown.
- Added Black Armour: beast helmet and layered armor transformation, animated
  aura and black-magic sword, +50% attack, 20% damage reduction, 20-second
  duration and 60-second cooldown.
- Added R/E key bindings, touch labels, HUD cooldowns and transformation timer.
